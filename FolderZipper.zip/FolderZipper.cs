// FolderZipper.cs
// Compresses every file in a folder into its own ZIP archive (name.ext -> name.ext.zip).
// Language level: C# 5. Target: .NET Framework 4.5+ (built into Windows 8/10/11).
// Build with build.bat, which uses the csc.exe that ships with Windows.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

[assembly: AssemblyTitle("Folder Zipper")]
[assembly: AssemblyDescription("Compresses each file in a folder into its own ZIP archive.")]
[assembly: AssemblyProduct("Folder Zipper")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

namespace FolderZipper
{
    // ------------------------------------------------------------------
    // Entry point
    // ------------------------------------------------------------------
    public static class Program
    {
        [DllImport("user32.dll")]
        private static extern bool SetProcessDPIAware();

        [STAThread]
        public static void Main()
        {
            // Crisp text on high-DPI screens. Harmless if unavailable.
            try { SetProcessDPIAware(); }
            catch (Exception) { }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new WizardForm());
        }
    }

    // ------------------------------------------------------------------
    // Scanning the input folder (top level only)
    // ------------------------------------------------------------------
    public class ScanResult
    {
        public string Folder;
        public List<FileInfo> ToCompress = new List<FileInfo>();
        public List<FileInfo> SkippedArchives = new List<FileInfo>();
        public List<FileInfo> SkippedHiddenSystem = new List<FileInfo>();
        public int SubfolderCount;

        // Archive file name for each file in ToCompress, keyed by the file's name.
        public Dictionary<string, string> ArchiveNames =
            new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        // How many files use the long name.ext.zip form to avoid a name clash.
        public int ConflictCount;

        public long TotalBytes
        {
            get { long t = 0; foreach (FileInfo f in ToCompress) t += f.Length; return t; }
        }
    }

    public static class Scanner
    {
        // Files with these extensions are treated as already-compressed archives and skipped.
        public static readonly string[] ArchiveExtensions = new string[]
        {
            ".zip", ".zipx", ".rar", ".7z", ".gz", ".tgz", ".bz2", ".tbz", ".tbz2", ".xz", ".txz",
            ".lz", ".lzma", ".tlz", ".zst", ".z", ".tar", ".cab", ".arj", ".lzh", ".lha", ".ace"
        };

        public static bool IsArchive(string fileName)
        {
            string ext = Path.GetExtension(fileName);
            if (string.IsNullOrEmpty(ext)) return false;
            foreach (string a in ArchiveExtensions)
                if (string.Equals(a, ext, StringComparison.OrdinalIgnoreCase)) return true;
            return false;
        }

        // Looks only at files directly inside the folder. Subfolders are counted
        // (for the report) but never opened.
        public static ScanResult Scan(string folder)
        {
            DirectoryInfo dir = new DirectoryInfo(folder);
            ScanResult r = new ScanResult();
            r.Folder = dir.FullName;

            foreach (FileInfo f in dir.GetFiles("*", SearchOption.TopDirectoryOnly))
            {
                if ((f.Attributes & (FileAttributes.Hidden | FileAttributes.System)) != 0)
                    r.SkippedHiddenSystem.Add(f);
                else if (IsArchive(f.Name))
                    r.SkippedArchives.Add(f);
                else
                    r.ToCompress.Add(f);
            }
            r.SubfolderCount = dir.GetDirectories("*", SearchOption.TopDirectoryOnly).Length;

            Comparison<FileInfo> byName = delegate(FileInfo a, FileInfo b)
            { return StringComparer.OrdinalIgnoreCase.Compare(a.Name, b.Name); };
            r.ToCompress.Sort(byName);
            r.SkippedArchives.Sort(byName);
            r.SkippedHiddenSystem.Sort(byName);
            AssignArchiveNames(r);
            return r;
        }

        // Normally 1.txt -> 1.zip. When two or more files would get the same
        // archive name (report.txt and report.pdf -> report.zip), every file
        // in that clash gets the long form instead: report.txt.zip, report.pdf.zip.
        // Repeats until no name is used twice (a long name can, rarely, clash
        // with someone else's short name, e.g. "a.b" vs "a.b.txt").
        public static void AssignArchiveNames(ScanResult r)
        {
            HashSet<string> useLong = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            Dictionary<string, string> names = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

            while (true)
            {
                names.Clear();
                Dictionary<string, List<string>> byArchive =
                    new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);

                foreach (FileInfo f in r.ToCompress)
                {
                    string archive = useLong.Contains(f.Name) ? LongName(f.Name) : ShortName(f.Name);
                    names[f.Name] = archive;
                    List<string> owners;
                    if (!byArchive.TryGetValue(archive, out owners))
                    {
                        owners = new List<string>();
                        byArchive[archive] = owners;
                    }
                    owners.Add(f.Name);
                }

                bool changed = false;
                foreach (List<string> owners in byArchive.Values)
                {
                    if (owners.Count < 2) continue;
                    foreach (string n in owners)
                        if (useLong.Add(n)) changed = true;
                }
                if (!changed) break; // long names are always unique, so this ends
            }

            r.ArchiveNames = names;
            r.ConflictCount = useLong.Count;
        }

        public static string ShortName(string fileName)
        {
            string stem = Path.GetFileNameWithoutExtension(fileName);
            if (string.IsNullOrEmpty(stem)) stem = fileName; // e.g. ".config"
            return stem + ".zip";
        }

        public static string LongName(string fileName)
        {
            return fileName + ".zip";
        }
    }

    // ------------------------------------------------------------------
    // Compression
    // ------------------------------------------------------------------
    public class FileResult
    {
        public string Name;
        public string ArchiveName;
        public long OriginalSize;
        public long ArchiveSize;
        public bool Success;
        public string Error;
    }

    public class RunResult
    {
        public string InputFolder;
        public string OutputFolder;
        public ScanResult Scan;
        public DateTime Started;
        public DateTime Finished;
        public bool Cancelled;
        public string FatalError;
        public List<FileResult> Results = new List<FileResult>();
        public List<string> NotProcessed = new List<string>();

        public int SuccessCount { get { return Results.Count(x => x.Success); } }
        public int FailedCount { get { return Results.Count(x => !x.Success); } }
    }

    public class ProgressInfo
    {
        public int FileNumber;
        public int FileCount;
        public string FileName;
        public long BytesDone;
        public long BytesTotal;
    }

    public static class Compressor
    {
        // Fills 'run' as it goes, so partial results survive a cancel or crash.
        public static void Run(RunResult run, IProgress<ProgressInfo> progress, CancellationToken ct)
        {
            List<FileInfo> files = run.Scan.ToCompress;
            long total = run.Scan.TotalBytes;
            long done = 0;
            byte[] buffer = new byte[81920];
            Stopwatch tick = Stopwatch.StartNew();

            for (int i = 0; i < files.Count; i++)
            {
                FileInfo src = files[i];

                if (ct.IsCancellationRequested)
                {
                    run.Cancelled = true;
                    for (int j = i; j < files.Count; j++) run.NotProcessed.Add(files[j].Name);
                    break;
                }

                FileResult fr = new FileResult();
                fr.Name = src.Name;
                fr.ArchiveName = run.Scan.ArchiveNames[src.Name];
                fr.OriginalSize = src.Length;
                string dest = Path.Combine(run.OutputFolder, fr.ArchiveName);
                long doneAtFileStart = done;
                bool created = false;
                bool cancelledHere = false;

                Report(progress, i + 1, files.Count, src.Name, done, total);

                try
                {
                    long read = 0;
                    using (FileStream input = new FileStream(src.FullName, FileMode.Open, FileAccess.Read,
                                                             FileShare.Read, 65536, FileOptions.SequentialScan))
                    using (FileStream output = new FileStream(dest, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                    {
                        created = true;
                        using (ZipArchive zip = new ZipArchive(output, ZipArchiveMode.Create))
                        {
                            ZipArchiveEntry entry = zip.CreateEntry(src.Name, CompressionLevel.Optimal);
                            try { entry.LastWriteTime = src.LastWriteTime; }
                            catch (ArgumentOutOfRangeException) { } // ZIP dates must be 1980-2107

                            using (Stream es = entry.Open())
                            {
                                int n;
                                while ((n = input.Read(buffer, 0, buffer.Length)) > 0)
                                {
                                    ct.ThrowIfCancellationRequested();
                                    es.Write(buffer, 0, n);
                                    read += n;
                                    done += n;
                                    if (tick.ElapsedMilliseconds >= 100)
                                    {
                                        tick.Restart();
                                        Report(progress, i + 1, files.Count, src.Name, done, total);
                                    }
                                }
                            }
                        }
                    }
                    fr.OriginalSize = read;
                    fr.ArchiveSize = new FileInfo(dest).Length;
                    fr.Success = true;
                }
                catch (OperationCanceledException)
                {
                    cancelledHere = true;
                }
                catch (Exception ex)
                {
                    fr.Success = false;
                    fr.Error = ex.Message;
                }

                if (!fr.Success && created)
                {
                    // Remove the incomplete archive we created (never touch a file we did not create).
                    try { File.Delete(dest); }
                    catch (Exception) { }
                }

                if (cancelledHere)
                {
                    run.Cancelled = true;
                    for (int j = i; j < files.Count; j++) run.NotProcessed.Add(files[j].Name);
                    break;
                }

                run.Results.Add(fr);
                done = doneAtFileStart + src.Length;
                Report(progress, i + 1, files.Count, src.Name, done, total);
            }
        }

        private static void Report(IProgress<ProgressInfo> progress, int number, int count, string name, long done, long total)
        {
            if (progress == null) return;
            ProgressInfo p = new ProgressInfo();
            p.FileNumber = number;
            p.FileCount = count;
            p.FileName = name;
            p.BytesDone = done;
            p.BytesTotal = total;
            progress.Report(p);
        }
    }

    // ------------------------------------------------------------------
    // Text helpers: review description and final report / log
    // ------------------------------------------------------------------
    public static class Fmt
    {
        public static string Size(long bytes)
        {
            if (bytes < 1024) return bytes.ToString("N0") + (bytes == 1 ? " byte" : " bytes");
            double v = bytes;
            string[] units = { "KB", "MB", "GB", "TB" };
            int u = -1;
            while (v >= 1024 && u < units.Length - 1) { v /= 1024; u++; }
            return v.ToString("0.0") + " " + units[u];
        }

        public static string Plural(int n, string one, string many)
        {
            return n.ToString("N0") + " " + (n == 1 ? one : many);
        }

        public static string Ratio(long part, long whole)
        {
            if (whole <= 0) return "n/a";
            return (100.0 * part / whole).ToString("0.0") + "%";
        }

        public static string Review(string input, string output, ScanResult s)
        {
            StringBuilder b = new StringBuilder();
            b.AppendLine("When you click Start, Folder Zipper will:");
            b.AppendLine();
            b.AppendLine("  Read files from:    " + input);
            b.AppendLine("  Write archives to:  " + output);
            b.AppendLine();
            b.AppendLine("  Create " + Plural(s.ToCompress.Count, "ZIP archive", "ZIP archives") +
                         ", one for each file, using normal compression.");
            b.AppendLine("  Each archive holds a single file and is named after it, with its");
            b.AppendLine("  extension replaced by .zip (1.txt -> 1.zip).");
            if (s.ConflictCount > 0)
            {
                b.AppendLine("  " + Plural(s.ConflictCount, "file shares", "files share") +
                             " a name with another file (e.g. report.txt and report.pdf),");
                b.AppendLine("  so those keep their extension to stay unique (report.txt.zip, report.pdf.zip).");
            }
            b.AppendLine("  Total data to compress: " + Size(s.TotalBytes));
            b.AppendLine();

            bool skipped = s.SkippedArchives.Count > 0 || s.SkippedHiddenSystem.Count > 0 || s.SubfolderCount > 0;
            if (skipped)
            {
                b.AppendLine("It will leave out:");
                if (s.SkippedArchives.Count > 0)
                    b.AppendLine("  " + Plural(s.SkippedArchives.Count, "file that is", "files that are") +
                                 " already compressed (listed in the log)");
                if (s.SkippedHiddenSystem.Count > 0)
                    b.AppendLine("  " + Plural(s.SkippedHiddenSystem.Count, "hidden or system file", "hidden or system files"));
                if (s.SubfolderCount > 0)
                    b.AppendLine("  " + Plural(s.SubfolderCount, "subfolder", "subfolders") + " (not opened, nothing inside is compressed)");
                b.AppendLine();
            }

            b.AppendLine("The original files are not changed, moved or deleted.");
            b.AppendLine();
            b.AppendLine("Files to compress:");
            foreach (FileInfo f in s.ToCompress)
                b.AppendLine("  " + f.Name + "  ->  " + s.ArchiveNames[f.Name] + "  (" + Size(f.Length) + ")");
            return b.ToString();
        }

        public static string Outcome(RunResult r)
        {
            if (r.FatalError != null) return "Stopped by an unexpected error";
            if (r.Cancelled) return "Cancelled by the user";
            if (r.FailedCount > 0) return "Completed with " + Plural(r.FailedCount, "error", "errors");
            return "Completed successfully";
        }

        public static string Report(RunResult r)
        {
            const string dt = "yyyy-MM-dd HH:mm:ss";
            StringBuilder b = new StringBuilder();
            b.AppendLine("Folder Zipper report");
            b.AppendLine("====================");
            b.AppendLine("Started:        " + r.Started.ToString(dt));
            b.AppendLine("Finished:       " + r.Finished.ToString(dt) +
                         "  (" + (r.Finished - r.Started).TotalSeconds.ToString("0.0") + " s)");
            b.AppendLine("Result:         " + Outcome(r));
            if (r.FatalError != null) b.AppendLine("Error:          " + r.FatalError);
            b.AppendLine();
            b.AppendLine("Input folder:   " + r.InputFolder);
            b.AppendLine("Output folder:  " + r.OutputFolder);
            b.AppendLine("Format:         ZIP, normal compression, one archive per file");
            b.AppendLine();

            long orig = 0, zipped = 0;
            foreach (FileResult f in r.Results)
                if (f.Success) { orig += f.OriginalSize; zipped += f.ArchiveSize; }

            b.AppendLine("Summary");
            b.AppendLine("-------");
            b.AppendLine("Files compressed:                " + r.SuccessCount.ToString("N0") +
                         " of " + r.Scan.ToCompress.Count.ToString("N0"));
            b.AppendLine("Failed:                          " + r.FailedCount.ToString("N0"));
            if (r.NotProcessed.Count > 0)
                b.AppendLine("Not processed (cancelled):       " + r.NotProcessed.Count.ToString("N0"));
            b.AppendLine("Skipped, already compressed:     " + r.Scan.SkippedArchives.Count.ToString("N0"));
            b.AppendLine("Skipped, hidden or system:       " + r.Scan.SkippedHiddenSystem.Count.ToString("N0"));
            b.AppendLine("Subfolders ignored:              " + r.Scan.SubfolderCount.ToString("N0"));
            if (r.Scan.ConflictCount > 0)
                b.AppendLine("Named name.ext.zip (name clash): " + r.Scan.ConflictCount.ToString("N0"));
            b.AppendLine("Original size of compressed files: " + Size(orig) + " (" + orig.ToString("N0") + " bytes)");
            b.AppendLine("Total size of archives:            " + Size(zipped) + " (" + zipped.ToString("N0") + " bytes)");
            b.AppendLine("Archives are " + Ratio(zipped, orig) + " of the original size.");
            b.AppendLine();

            List<FileResult> ok = r.Results.Where(x => x.Success).ToList();
            if (ok.Count > 0)
            {
                b.AppendLine("Compressed files");
                b.AppendLine("----------------");
                foreach (FileResult f in ok)
                    b.AppendLine("  " + f.Name + "  ->  " + f.ArchiveName + "    " +
                                 Size(f.OriginalSize) + " -> " + Size(f.ArchiveSize) +
                                 " (" + Ratio(f.ArchiveSize, f.OriginalSize) + ")");
                b.AppendLine();
            }

            List<FileResult> bad = r.Results.Where(x => !x.Success).ToList();
            if (bad.Count > 0)
            {
                b.AppendLine("Failed files (no archive was created for these)");
                b.AppendLine("-----------------------------------------------");
                foreach (FileResult f in bad)
                    b.AppendLine("  " + f.Name + ": " + f.Error);
                b.AppendLine();
            }

            if (r.NotProcessed.Count > 0)
            {
                b.AppendLine("Not processed because the operation was cancelled");
                b.AppendLine("-------------------------------------------------");
                foreach (string n in r.NotProcessed) b.AppendLine("  " + n);
                b.AppendLine();
            }

            if (r.Scan.SkippedArchives.Count > 0)
            {
                b.AppendLine("Skipped - already compressed files found in the input folder");
                b.AppendLine("------------------------------------------------------------");
                foreach (FileInfo f in r.Scan.SkippedArchives) b.AppendLine("  " + f.Name);
                b.AppendLine();
            }

            if (r.Scan.SkippedHiddenSystem.Count > 0)
            {
                b.AppendLine("Skipped - hidden or system files");
                b.AppendLine("--------------------------------");
                foreach (FileInfo f in r.Scan.SkippedHiddenSystem) b.AppendLine("  " + f.Name);
                b.AppendLine();
            }

            b.AppendLine("The original files were not changed, moved or deleted.");
            return b.ToString();
        }
    }

    // ------------------------------------------------------------------
    // The wizard window
    // ------------------------------------------------------------------
    public class WizardForm : Form
    {
        private const int PageInput = 0, PageOutput = 1, PageReview = 2, PageProgress = 3, PageSummary = 4;

        private Label lblTitle, lblSubtitle;
        private Button btnBack, btnNext, btnCancel;
        private Panel[] pages = new Panel[5];
        private int page = -1;

        // Input page
        private TextBox txtInput;
        private Label lblInputInfo;
        // Output page
        private TextBox txtOutput;
        // Review page
        private TextBox txtReview;
        // Progress page
        private Label lblProgCount, lblProgFile, lblProgBytes;
        private ProgressBar progressBar;
        // Summary page
        private TextBox txtSummary;

        private string inputFolder, outputFolder;
        private ScanResult scan;
        private RunResult lastRun;
        private string reportText;
        private CancellationTokenSource cts;
        private bool busy, closeWhenDone;

        public WizardForm()
        {
            SuspendLayout();
            AutoScaleDimensions = new SizeF(96F, 96F);
            AutoScaleMode = AutoScaleMode.Dpi;
            Font = SystemFonts.MessageBoxFont;
            Text = "Folder Zipper";
            ClientSize = new Size(600, 420);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); }
            catch (Exception) { }

            // Header
            Panel header = new Panel();
            header.Dock = DockStyle.Top;
            header.Height = 64;
            header.BackColor = SystemColors.Window;
            lblTitle = new Label();
            lblTitle.AutoSize = false;
            lblTitle.Location = new Point(16, 12);
            lblTitle.Size = new Size(568, 22);
            lblTitle.Font = new Font(Font.FontFamily, 10.5F, FontStyle.Bold);
            lblTitle.ForeColor = SystemColors.WindowText;
            lblSubtitle = new Label();
            lblSubtitle.AutoSize = false;
            lblSubtitle.Location = new Point(28, 36);
            lblSubtitle.Size = new Size(556, 20);
            lblSubtitle.ForeColor = SystemColors.WindowText;
            header.Controls.Add(lblTitle);
            header.Controls.Add(lblSubtitle);

            Label headerLine = Separator(DockStyle.Top);
            Label footerLine = Separator(DockStyle.Bottom);

            // Footer with buttons
            Panel footer = new Panel();
            footer.Dock = DockStyle.Bottom;
            footer.Height = 48;
            btnBack = MakeButton("< Back", 308, 11);
            btnNext = MakeButton("Next >", 398, 11);
            btnCancel = MakeButton("Cancel", 500, 11);
            btnBack.Click += delegate { GoBack(); };
            btnNext.Click += delegate { GoNext(); };
            btnCancel.Click += delegate { CancelPressed(); };
            footer.Controls.Add(btnBack);
            footer.Controls.Add(btnNext);
            footer.Controls.Add(btnCancel);

            // Content
            Panel content = new Panel();
            content.Dock = DockStyle.Fill;
            pages[PageInput] = BuildInputPage();
            pages[PageOutput] = BuildOutputPage();
            pages[PageReview] = BuildReviewPage();
            pages[PageProgress] = BuildProgressPage();
            pages[PageSummary] = BuildSummaryPage();
            foreach (Panel p in pages)
            {
                p.Dock = DockStyle.Fill;
                p.Visible = false;
                content.Controls.Add(p);
            }

            // Order matters for docking: the last added docks first.
            Controls.Add(content);
            Controls.Add(footerLine);
            Controls.Add(footer);
            Controls.Add(headerLine);
            Controls.Add(header);

            AcceptButton = btnNext;
            ResumeLayout(false);
            PerformLayout();

            ShowPage(PageInput);
        }

        private static Label Separator(DockStyle dock)
        {
            Label l = new Label();
            l.AutoSize = false;
            l.Height = 2;
            l.BorderStyle = BorderStyle.Fixed3D;
            l.Dock = dock;
            return l;
        }

        private static Button MakeButton(string text, int x, int y)
        {
            Button b = new Button();
            b.Text = text;
            b.Location = new Point(x, y);
            b.Size = new Size(88, 26);
            b.UseVisualStyleBackColor = true;
            return b;
        }

        private static Label MakeLabel(string text, int x, int y, int w, int h)
        {
            Label l = new Label();
            l.AutoSize = false;
            l.Text = text;
            l.Location = new Point(x, y);
            l.Size = new Size(w, h);
            return l;
        }

        private static TextBox MakeReportBox(int x, int y, int w, int h)
        {
            TextBox t = new TextBox();
            t.Multiline = true;
            t.ReadOnly = true;
            t.WordWrap = false;
            t.ScrollBars = ScrollBars.Both;
            t.BackColor = SystemColors.Window;
            t.Font = new Font(FontFamily.GenericMonospace, 9F);
            try { t.Font = new Font("Consolas", 9F); }
            catch (Exception) { }
            t.Location = new Point(x, y);
            t.Size = new Size(w, h);
            return t;
        }

        // ---------------- Pages ----------------

        private Panel BuildInputPage()
        {
            Panel p = new Panel();
            p.Controls.Add(MakeLabel("&Input folder:", 24, 20, 300, 18));
            txtInput = new TextBox();
            txtInput.Location = new Point(24, 42);
            txtInput.Size = new Size(456, 23);
            txtInput.Leave += delegate { UpdateInputInfo(); };
            p.Controls.Add(txtInput);
            Button browse = MakeButton("Br&owse...", 488, 41);
            browse.Click += delegate
            {
                string chosen = PickFolder("Choose the folder that contains the files to compress.", txtInput.Text, false);
                if (chosen != null) { txtInput.Text = chosen; UpdateInputInfo(); }
            };
            p.Controls.Add(browse);

            lblInputInfo = MakeLabel("", 24, 80, 552, 70);
            p.Controls.Add(lblInputInfo);

            Label note = MakeLabel(
                "Only files directly inside this folder are compressed. Subfolders are ignored " +
                "completely: they are not opened and nothing inside them is compressed.\r\n\r\n" +
                "Files that are already compressed archives (.zip, .rar, .7z and similar) and " +
                "hidden or system files are skipped and listed in the log.",
                24, 166, 552, 110);
            note.ForeColor = SystemColors.GrayText;
            p.Controls.Add(note);
            return p;
        }

        private Panel BuildOutputPage()
        {
            Panel p = new Panel();
            p.Controls.Add(MakeLabel("&Output folder:", 24, 20, 300, 18));
            txtOutput = new TextBox();
            txtOutput.Location = new Point(24, 42);
            txtOutput.Size = new Size(456, 23);
            p.Controls.Add(txtOutput);
            Button browse = MakeButton("Br&owse...", 488, 41);
            browse.Click += delegate
            {
                string chosen = PickFolder("Choose an EMPTY folder for the ZIP archives. You can create a new one here.",
                                           txtOutput.Text, true);
                if (chosen != null) txtOutput.Text = chosen;
            };
            p.Controls.Add(browse);

            Label note = MakeLabel(
                "The output folder must be empty. A folder that already contains files or " +
                "subfolders will not be accepted.\r\n\r\n" +
                "If you type the path of a folder that does not exist yet, you will be offered " +
                "to create it.\r\n\r\n" +
                "Each file gets its own archive named after it, for example 1.txt becomes 1.zip. " +
                "If two files share a name (report.txt and report.pdf), both keep their extension: " +
                "report.txt.zip and report.pdf.zip.",
                24, 86, 552, 190);
            note.ForeColor = SystemColors.GrayText;
            p.Controls.Add(note);
            return p;
        }

        private Panel BuildReviewPage()
        {
            Panel p = new Panel();
            txtReview = MakeReportBox(24, 16, 552, 272);
            p.Controls.Add(txtReview);
            return p;
        }

        private Panel BuildProgressPage()
        {
            Panel p = new Panel();
            lblProgCount = MakeLabel("", 24, 40, 552, 20);
            lblProgFile = MakeLabel("", 24, 62, 552, 20);
            lblProgFile.AutoEllipsis = true;
            progressBar = new ProgressBar();
            progressBar.Location = new Point(24, 96);
            progressBar.Size = new Size(552, 22);
            progressBar.Minimum = 0;
            progressBar.Maximum = 1000;
            lblProgBytes = MakeLabel("", 24, 126, 552, 20);
            p.Controls.Add(lblProgCount);
            p.Controls.Add(lblProgFile);
            p.Controls.Add(progressBar);
            p.Controls.Add(lblProgBytes);
            return p;
        }

        private Panel BuildSummaryPage()
        {
            Panel p = new Panel();
            txtSummary = MakeReportBox(24, 16, 552, 236);
            p.Controls.Add(txtSummary);
            Button save = MakeButton("&Save Log...", 24, 262);
            save.Width = 110;
            save.Click += delegate { SaveLog(); };
            p.Controls.Add(save);
            return p;
        }

        // ---------------- Navigation ----------------

        private void ShowPage(int index)
        {
            for (int i = 0; i < pages.Length; i++) pages[i].Visible = (i == index);
            page = index;

            btnBack.Visible = true;
            btnNext.Visible = true;
            btnCancel.Visible = true;
            btnBack.Enabled = true;
            btnNext.Enabled = true;
            btnCancel.Enabled = true;
            btnNext.Text = "Next >";
            btnCancel.Text = "Cancel";

            switch (index)
            {
                case PageInput:
                    lblTitle.Text = "Step 1 of 3: Input folder";
                    lblSubtitle.Text = "Choose the folder that contains the files you want to compress.";
                    btnBack.Visible = false;
                    txtInput.Focus();
                    break;
                case PageOutput:
                    lblTitle.Text = "Step 2 of 3: Output folder";
                    lblSubtitle.Text = "Choose an empty folder where the ZIP archives will be created.";
                    txtOutput.Focus();
                    break;
                case PageReview:
                    lblTitle.Text = "Step 3 of 3: Review";
                    lblSubtitle.Text = "Check what will happen, then click Start.";
                    btnNext.Text = "Start";
                    btnNext.Focus();
                    break;
                case PageProgress:
                    lblTitle.Text = "Compressing...";
                    lblSubtitle.Text = "Please wait. You can click Cancel to stop after the current file.";
                    btnBack.Enabled = false;
                    btnNext.Enabled = false;
                    break;
                case PageSummary:
                    lblTitle.Text = Fmt.Outcome(lastRun);
                    lblSubtitle.Text = Fmt.Plural(lastRun.SuccessCount, "file", "files") + " compressed, " +
                                       Fmt.Plural(lastRun.FailedCount, "failure", "failures") +
                                       ". You can save this report as a log.";
                    btnBack.Visible = false;
                    btnCancel.Visible = false;
                    btnNext.Text = "Finish";
                    btnNext.Focus();
                    break;
            }
        }

        private void GoBack()
        {
            if (page == PageOutput) ShowPage(PageInput);
            else if (page == PageReview) ShowPage(PageOutput);
        }

        private void GoNext()
        {
            switch (page)
            {
                case PageInput:
                    if (ValidateInput()) ShowPage(PageOutput);
                    break;
                case PageOutput:
                    if (ValidateOutput()) EnterReview();
                    break;
                case PageReview:
                    // Re-check right before starting: things may have changed while the wizard was open.
                    if (!ValidateInput()) { ShowPage(PageInput); return; }
                    if (!ValidateOutput()) { ShowPage(PageOutput); return; }
                    StartWork();
                    break;
                case PageSummary:
                    Close();
                    break;
            }
        }

        private void CancelPressed()
        {
            if (page == PageProgress)
            {
                AskToStop();
                return;
            }
            Close();
        }

        private bool AskToStop()
        {
            if (cts == null || cts.IsCancellationRequested) return true;
            DialogResult r = MessageBox.Show(this,
                "Stop compressing?\r\n\r\nArchives already created are kept. The file being compressed " +
                "right now is abandoned and its incomplete archive is removed.",
                "Folder Zipper", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
            if (r != DialogResult.Yes) return false;
            cts.Cancel();
            btnCancel.Enabled = false;
            lblSubtitle.Text = "Stopping...";
            return true;
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (busy)
            {
                if (AskToStop()) closeWhenDone = true;
                e.Cancel = true; // close happens once the worker has stopped
            }
            base.OnFormClosing(e);
        }

        // ---------------- Validation ----------------

        private static string NormalizePath(string text, out string error)
        {
            error = null;
            text = (text ?? "").Trim().Trim('"');
            if (text.Length == 0) return null;
            try
            {
                string full = Path.GetFullPath(text);
                string root = Path.GetPathRoot(full);
                if (full.Length > root.Length) full = full.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                return full;
            }
            catch (Exception ex)
            {
                error = "The path is not valid: " + ex.Message;
                return null;
            }
        }

        private void Error(string message)
        {
            MessageBox.Show(this, message, "Folder Zipper", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void UpdateInputInfo()
        {
            string err;
            string path = NormalizePath(txtInput.Text, out err);
            if (path == null || !Directory.Exists(path)) { lblInputInfo.Text = ""; return; }
            try
            {
                ScanResult s = Scanner.Scan(path);
                StringBuilder b = new StringBuilder();
                b.Append(Fmt.Plural(s.ToCompress.Count, "file", "files") + " will be compressed (" +
                         Fmt.Size(s.TotalBytes) + ").");
                List<string> extra = new List<string>();
                if (s.SkippedArchives.Count > 0)
                    extra.Add(Fmt.Plural(s.SkippedArchives.Count, "compressed file", "compressed files") + " skipped");
                if (s.SkippedHiddenSystem.Count > 0)
                    extra.Add(Fmt.Plural(s.SkippedHiddenSystem.Count, "hidden/system file", "hidden/system files") + " skipped");
                if (s.SubfolderCount > 0)
                    extra.Add(Fmt.Plural(s.SubfolderCount, "subfolder", "subfolders") + " ignored");
                if (extra.Count > 0) b.Append("\r\n" + string.Join(", ", extra) + ".");
                lblInputInfo.Text = b.ToString();
            }
            catch (Exception ex)
            {
                lblInputInfo.Text = "The folder cannot be read: " + ex.Message;
            }
        }

        private bool ValidateInput()
        {
            string err;
            string path = NormalizePath(txtInput.Text, out err);
            if (err != null) { Error(err); return false; }
            if (path == null) { Error("Please choose an input folder."); return false; }
            if (!Directory.Exists(path)) { Error("The input folder does not exist:\r\n" + path); return false; }

            ScanResult s;
            try { s = Scanner.Scan(path); }
            catch (Exception ex) { Error("The input folder cannot be read:\r\n" + ex.Message); return false; }

            if (s.ToCompress.Count == 0)
            {
                Error("There are no files to compress in this folder.\r\n\r\n" +
                      "Already compressed files skipped: " + s.SkippedArchives.Count + "\r\n" +
                      "Hidden or system files skipped: " + s.SkippedHiddenSystem.Count + "\r\n" +
                      "Subfolders ignored: " + s.SubfolderCount);
                return false;
            }

            inputFolder = path;
            scan = s;
            txtInput.Text = path;
            UpdateInputInfo();
            return true;
        }

        private bool ValidateOutput()
        {
            string err;
            string path = NormalizePath(txtOutput.Text, out err);
            if (err != null) { Error(err); return false; }
            if (path == null) { Error("Please choose an output folder."); return false; }

            if (string.Equals(path, inputFolder, StringComparison.OrdinalIgnoreCase))
            {
                Error("The output folder cannot be the same as the input folder.");
                return false;
            }

            if (File.Exists(path))
            {
                Error("This path points to a file, not a folder:\r\n" + path);
                return false;
            }

            if (!Directory.Exists(path))
            {
                DialogResult r = MessageBox.Show(this, "The folder does not exist:\r\n" + path +
                                                 "\r\n\r\nCreate it?", "Folder Zipper",
                                                 MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (r != DialogResult.Yes) return false;
                try { Directory.CreateDirectory(path); }
                catch (Exception ex) { Error("The folder could not be created:\r\n" + ex.Message); return false; }
            }

            try
            {
                if (Directory.EnumerateFileSystemEntries(path).Any())
                {
                    Error("The output folder is not empty:\r\n" + path +
                          "\r\n\r\nPlease choose an empty folder.");
                    return false;
                }
            }
            catch (Exception ex)
            {
                Error("The output folder cannot be read:\r\n" + ex.Message);
                return false;
            }

            // Make sure we can actually write there.
            string probe = Path.Combine(path, "~folderzipper_" + Guid.NewGuid().ToString("N") + ".tmp");
            try
            {
                File.WriteAllBytes(probe, new byte[0]);
                File.Delete(probe);
            }
            catch (Exception ex)
            {
                Error("Files cannot be created in the output folder:\r\n" + ex.Message);
                try { File.Delete(probe); }
                catch (Exception) { }
                return false;
            }

            outputFolder = path;
            txtOutput.Text = path;
            return true;
        }

        private void EnterReview()
        {
            txtReview.Text = Fmt.Review(inputFolder, outputFolder, scan);
            txtReview.Select(0, 0);
            ShowPage(PageReview);
        }

        // ---------------- Work ----------------

        private async void StartWork()
        {
            busy = true;
            cts = new CancellationTokenSource();
            progressBar.Value = 0;
            lblProgCount.Text = "";
            lblProgFile.Text = "";
            lblProgBytes.Text = "";
            ShowPage(PageProgress);

            RunResult run = new RunResult();
            run.InputFolder = inputFolder;
            run.OutputFolder = outputFolder;
            run.Scan = scan;
            run.Started = DateTime.Now;

            Progress<ProgressInfo> progress = new Progress<ProgressInfo>(UpdateProgress);
            CancellationToken token = cts.Token;
            try
            {
                await Task.Run(delegate { Compressor.Run(run, progress, token); });
            }
            catch (Exception ex)
            {
                run.FatalError = ex.Message;
            }
            run.Finished = DateTime.Now;

            busy = false;
            lastRun = run;
            reportText = Fmt.Report(run);
            txtSummary.Text = reportText;
            txtSummary.Select(0, 0);
            ShowPage(PageSummary);
            cts.Dispose();
            cts = null;

            if (closeWhenDone) Close();
        }

        private void UpdateProgress(ProgressInfo p)
        {
            if (page != PageProgress) return;
            lblProgCount.Text = "Compressing file " + p.FileNumber.ToString("N0") + " of " + p.FileCount.ToString("N0") + ":";
            lblProgFile.Text = p.FileName;
            int v = p.BytesTotal > 0 ? (int)Math.Min(1000, p.BytesDone * 1000 / p.BytesTotal) : 0;
            progressBar.Value = v;
            lblProgBytes.Text = Fmt.Size(p.BytesDone) + " of " + Fmt.Size(p.BytesTotal);
        }

        // ---------------- Log ----------------

        private void SaveLog()
        {
            using (SaveFileDialog d = new SaveFileDialog())
            {
                d.Title = "Save log";
                d.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
                d.DefaultExt = "txt";
                d.AddExtension = true;
                d.OverwritePrompt = true;
                d.FileName = "FolderZipper log " + lastRun.Started.ToString("yyyy-MM-dd HHmmss") + ".txt";
                if (outputFolder != null && Directory.Exists(outputFolder)) d.InitialDirectory = outputFolder;
                if (d.ShowDialog(this) != DialogResult.OK) return;
                try
                {
                    File.WriteAllText(d.FileName, reportText, Encoding.UTF8);
                    MessageBox.Show(this, "The log was saved to:\r\n" + d.FileName, "Folder Zipper",
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    Error("The log could not be saved:\r\n" + ex.Message);
                }
            }
        }

        // ---------------- Folder picking ----------------

        private string PickFolder(string description, string current, bool allowNew)
        {
            using (FolderBrowserDialog d = new FolderBrowserDialog())
            {
                d.Description = description;
                d.ShowNewFolderButton = allowNew;
                string err;
                string start = NormalizePath(current, out err);
                if (start != null && Directory.Exists(start)) d.SelectedPath = start;
                return d.ShowDialog(this) == DialogResult.OK ? d.SelectedPath : null;
            }
        }
    }
}
