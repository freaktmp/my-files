FOLDER ZIPPER 1.0
=================

What it does
------------
Folder Zipper compresses every file in a folder into its own ZIP archive.
Each archive holds exactly one file and is named after it, with the
extension replaced by .zip:

    Input folder D:\1          Output folder D:\2
      1.txt            ->        1.zip
      2.txt            ->        2.zip
      notes.doc        ->        notes.zip

Name clashes: if two or more files would get the same archive name
(for example report.txt and report.pdf would both become report.zip),
every file in that clash keeps its extension instead:

      report.txt       ->        report.txt.zip
      report.pdf       ->        report.pdf.zip

All other files still get the short name. The review screen shows the
exact archive name for every file before anything is created, and the
report counts how many files needed the long name.

The original files are never changed, moved or deleted.


Requirements
------------
Windows with .NET Framework 4.5 or later. This is built into Windows 8,
10 and 11. Nothing needs to be installed.


Files
-----
  FolderZipper.exe   The program. Just double-click it; no installation.
  FolderZipper.cs    The complete source code (C# 5, WinForms).
  build.bat          Rebuilds FolderZipper.exe from FolderZipper.cs using the
                     C# compiler built into Windows (csc.exe in
                     C:\Windows\Microsoft.NET\Framework64\v4.0.30319).
  README.txt         This description.


Using the wizard
----------------
Step 1 - Input folder
  Choose the folder containing the files to compress (type the path or use
  Browse). The page shows how many files will be compressed and how many
  will be skipped.

Step 2 - Output folder
  Choose an EMPTY folder for the archives. A folder that contains anything
  (files or subfolders, including hidden ones) is rejected. If you type a
  path that does not exist, you are offered to create it. The output folder
  cannot be the same as the input folder.

Step 3 - Review
  A description of exactly what will happen: source and destination,
  how many archives will be created, total data size, what will be left
  out, and the full list of files. Click Start to begin.

Progress
  Shows the current file and overall progress. Cancel stops the work; any
  archives already finished are kept, and the incomplete archive of the
  file being worked on is removed.

Finish
  A report of what was accomplished: counts, sizes, compression ratio,
  every archive created, any failures with the reason, and everything that
  was skipped. "Save Log..." saves this report as a text file (UTF-8).


What is skipped or ignored
--------------------------
  - Subfolders: ignored completely. They are not opened, and nothing inside
    them is compressed. Only their number is mentioned in the report.
  - Files that are already compressed archives, recognised by extension:
    .zip .zipx .rar .7z .gz .tgz .bz2 .tbz .tbz2 .xz .txz .lz .lzma .tlz
    .zst .z .tar .cab .arj .lzh .lha .ace
    They are not compressed again and are listed by name in the report/log.
  - Hidden and system files (for example desktop.ini, Thumbs.db). Listed by
    name in the report/log.


Details
-------
  - Format: standard ZIP, "normal" (optimal Deflate) compression. Archives
    open in Windows Explorer and in any ZIP tool.
  - Files larger than 4 GB are supported (ZIP64).
  - Non-English filenames (Greek, etc.) are stored correctly (UTF-8 names).
  - Each archive entry keeps the original file's modified date.
  - A file that cannot be read (for example locked by another program) is
    reported as failed and the work continues with the next file.
  - Files that are already well compressed (JPG, MP4, MP3, DOCX, ...) will
    not get much smaller, and very small files can even grow slightly,
    because every ZIP has about 100 bytes of overhead.


Notes
-----
  - Being a small unsigned program, Windows SmartScreen may show a warning
    the first time you run a freshly built or downloaded FolderZipper.exe.
    Click "More info" and "Run anyway" if you trust it.
  - Paths longer than 260 characters are not supported by .NET Framework by
    default; such files will be reported as failed.
