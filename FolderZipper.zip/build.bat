@echo off
rem ------------------------------------------------------------------
rem  build.bat - builds FolderZipper.exe from FolderZipper.cs
rem  Uses the C# compiler that ships with Windows (.NET Framework 4.x).
rem  No Visual Studio or SDK needed. Run from the folder with the .cs file.
rem ------------------------------------------------------------------
setlocal
cd /d "%~dp0"

set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" (
    echo ERROR: csc.exe was not found. .NET Framework 4.5 or later is required.
    pause
    exit /b 1
)

if not exist "FolderZipper.cs" (
    echo ERROR: FolderZipper.cs was not found next to build.bat.
    pause
    exit /b 1
)

echo Using %CSC%
"%CSC%" /nologo /langversion:5 /target:winexe /optimize+ /out:FolderZipper.exe ^
    /r:System.dll /r:System.Core.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll ^
    /r:System.IO.Compression.dll ^
    FolderZipper.cs

if errorlevel 1 (
    echo.
    echo BUILD FAILED.
    pause
    exit /b 1
)

echo.
echo Build succeeded: FolderZipper.exe
pause
