﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;
using System.Windows.Forms;

// Greece Annual Calendar / Ημερολόγιο Αργιών Ελλάδας
// Plain C# (WinForms). Compiles with the C# compiler that ships with Windows.

class Hol { public int Month, Day; public string Gr, En, Pid; public bool Yearly; }
class PHol { public string Id, Date, Name; public bool Yearly; }
class Row
{
    public string Date = "", Name = "", Right = "";
    public bool Dim, Strike, Mine; public object Tag;
    public override string ToString() { return Date + " " + Name; }
}
class Pal
{
    public Color Bg, Card, Text, Muted, Line, Blue, Hol, HolB, OffBg, OffFg, MineBg, MineB, DisBg, DisB, LvBg, LvB, LvFg;
    public static Pal Light()
    {
        Pal p = new Pal();
        p.Bg = C(0xf3f1ec); p.Card = C(0xffffff); p.Text = C(0x1f2a37); p.Muted = C(0x6b7686); p.Line = C(0xe5e2da);
        p.Blue = C(0x1d4f91); p.Hol = C(0xfde2e0); p.HolB = C(0xe9a29c); p.OffBg = C(0xffe58a); p.OffFg = C(0x7a4d00);
        p.MineBg = C(0xe4dcff); p.MineB = C(0x8f78e0); p.DisBg = C(0xe4e4e4); p.DisB = C(0xa8a8a8);
        p.LvBg = C(0xbff0cf); p.LvB = C(0x2e9b5a); p.LvFg = C(0x14532d);
        return p;
    }
    public static Pal Dark()
    {
        Pal p = new Pal();
        p.Bg = C(0x12171f); p.Card = C(0x1a212c); p.Text = C(0xe6ebf2); p.Muted = C(0x93a0b2); p.Line = C(0x2a3340);
        p.Blue = C(0x6aa5ee); p.Hol = C(0x4a2523); p.HolB = C(0x8a4540); p.OffBg = C(0x6b5410); p.OffFg = C(0xffdd6e);
        p.MineBg = C(0x3a2f6b); p.MineB = C(0x8f78e0); p.DisBg = C(0x2c313a); p.DisB = C(0x5b626e);
        p.LvBg = C(0x1f5a3a); p.LvB = C(0x58c88a); p.LvFg = C(0xd2f7e1);
        return p;
    }
    static Color C(int rgb) { return Color.FromArgb((rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255); }
}

// A rounded "card" panel with a title and an optional hint.
class Box : Panel
{
    public string Title = "", Hint = "";
    public Pal P; public Font FTitle, FHint; public int Pad = 8;
    public Box()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
    }
    public int HintHeight()
    {
        if (string.IsNullOrEmpty(Hint) || FHint == null) return 0;
        return TextRenderer.MeasureText(Hint, FHint, new Size(Math.Max(10, Width - 2 * Pad), 0), TextFormatFlags.WordBreak | TextFormatFlags.NoPadding).Height;
    }
    public int ContentTop()
    {
        int t = Pad + (FTitle != null ? FTitle.Height : 14) + Pad / 2;
        int h = HintHeight();
        if (h > 0) t += h + Pad / 2;
        return t;
    }
    protected override void OnPaint(PaintEventArgs e)
    {
        if (P == null || FTitle == null) return;
        Graphics g = e.Graphics;
        g.Clear(P.Bg);
        g.SmoothingMode = SmoothingMode.AntiAlias;
        CalForm.FillRound(g, new RectangleF(0, 0, Width - 1, Height - 1), Pad * 0.8f, P.Card, P.Line, false);
        TextRenderer.DrawText(g, Title, FTitle, new Point(Pad, Pad), P.Blue, TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix);
        int h = HintHeight();
        if (h > 0)
        {
            int ty = Pad + FTitle.Height + Pad / 2;
            TextRenderer.DrawText(g, Hint, FHint, new Rectangle(Pad, ty, Width - 2 * Pad, h), P.Muted, TextFormatFlags.WordBreak | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix);
        }
    }
}

class IconBtn : Button
{
    public Color IconColor = Color.Black;
    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        Graphics g = e.Graphics; g.SmoothingMode = SmoothingMode.AntiAlias;
        float s = Math.Min(Width, Height) * 0.5f;
        float x = (Width - s) / 2f, y = (Height - s) / 2f;
        using (Pen pn = new Pen(IconColor, Math.Max(1.4f, s / 11f)))
        {
            g.DrawRectangle(pn, x, y, s, s);
            g.DrawRectangle(pn, x + s * 0.22f, y, s * 0.5f, s * 0.3f);
            g.DrawRectangle(pn, x + s * 0.2f, y + s * 0.55f, s * 0.6f, s * 0.45f);
        }
    }
}

class MonthCtl : Control
{
    public CalForm F; public int Month; int hot = 0; int lastTipDay = -1;
    public MonthCtl()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
    }
    float PadX() { return Width * 0.035f; }
    float PadTop() { return Height * 0.035f; }
    float TitleH() { return Height * 0.115f; }
    float DnH() { return Height * 0.07f; }
    float GridTop() { return PadTop() + TitleH() + DnH(); }
    float CW() { return (Width - 2 * PadX()) / 7f; }
    float CH() { return (Height - GridTop() - Height * 0.03f) / 6f; }
    int First() { return ((int)new DateTime(F.Y, Month, 1).DayOfWeek + 6) % 7; }
    int Dim() { return DateTime.DaysInMonth(F.Y, Month); }
    RectangleF Cell(int row, int col)
    {
        RectangleF r = new RectangleF(PadX() + col * CW(), GridTop() + row * CH(), CW(), CH());
        r.Inflate(-1f, -1f); return r;
    }
    int HitDay(Point pt)
    {
        float x = pt.X - PadX(), y = pt.Y - GridTop();
        if (x < 0 || y < 0) return 0;
        int col = (int)(x / CW()), row = (int)(y / CH());
        if (col > 6 || row > 5) return 0;
        int d = row * 7 + col - First() + 1;
        return (d >= 1 && d <= Dim()) ? d : 0;
    }
    protected override void OnPaint(PaintEventArgs e)
    {
        if (F == null || F.P == null) return;
        Graphics g = e.Graphics; Pal p = F.P;
        g.Clear(p.Bg);
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        CalForm.FillRound(g, new RectangleF(0, 0, Width - 1, Height - 1), (float)(F.S * 0.6), p.Card, p.Line, false);
        using (StringFormat sf = new StringFormat())
        {
            sf.Alignment = StringAlignment.Center; sf.LineAlignment = StringAlignment.Center;
            using (Brush bb = new SolidBrush(p.Blue))
                g.DrawString(F.MonthName(Month), F.Fnt(F.S * 0.9, true, false), bb, new RectangleF(0, PadTop(), Width, TitleH()), sf);
            using (Pen pn = new Pen(p.Line))
                g.DrawLine(pn, PadX(), PadTop() + TitleH(), Width - PadX(), PadTop() + TitleH());
            string[] dn = F.DayNames();
            using (Brush mb = new SolidBrush(p.Muted))
                for (int c = 0; c < 7; c++)
                    g.DrawString(dn[c], F.Fnt(F.S * 0.66, false, false), mb, new RectangleF(PadX() + c * CW(), PadTop() + TitleH(), CW(), DnH()), sf);
            int first = First(), dim = Dim();
            for (int d = 1; d <= dim; d++)
            {
                int idx = first + d - 1; RectangleF c = Cell(idx / 7, idx % 7);
                DateTime dt = new DateTime(F.Y, Month, d); string k = CalForm.Key(F.Y, Month, d);
                bool off = !F.work[(int)dt.DayOfWeek];
                Hol h = F.HolAt(k); bool hol = h != null; bool mine = hol && h.Pid != null;
                bool dis = hol && F.IsDisabled(k), lv = F.IsLeave(k), today = dt == DateTime.Today;
                Color fill = Color.Empty, border = Color.Empty, text = p.Text; bool bold = false, dashed = false;
                if (off) { fill = p.OffBg; text = p.OffFg; bold = true; }
                if (hol) { fill = p.Hol; border = p.HolB; text = p.Text; bold = false; }
                if (today) { fill = p.Blue; border = p.Blue; text = p.Card; bold = true; }
                if (mine) { fill = p.MineBg; border = p.MineB; text = p.Text; }
                if (hol && dis) { fill = p.DisBg; border = p.DisB; dashed = true; text = p.Muted; bold = false; }
                if (lv) { fill = p.LvBg; border = p.LvB; dashed = false; text = p.LvFg; bold = true; }
                if (border.IsEmpty && d == hot) border = p.Muted;
                if (!fill.IsEmpty || !border.IsEmpty)
                    CalForm.FillRound(g, c, (float)(F.S * 0.25), fill, border, dashed);
                if (today && lv)
                    using (Pen rp = new Pen(p.Blue, 2f)) g.DrawRectangle(rp, c.X - 1, c.Y - 1, c.Width + 2, c.Height + 2);
                using (Brush tb = new SolidBrush(text))
                    g.DrawString(d.ToString(), F.Fnt(F.S * 0.8, bold, false), tb, c, sf);
            }
        }
    }
    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        int d = HitDay(e.Location);
        Cursor = d > 0 ? Cursors.Hand : Cursors.Default;
        if (d != hot) { hot = d; Invalidate(); }
        if (d != lastTipDay)
        {
            lastTipDay = d;
            if (d > 0) F.Tip.Show(F.TipFor(F.Y, Month, d), this, e.X + 14, e.Y + 20, 5000); else F.Tip.Hide(this);
        }
    }
    protected override void OnMouseLeave(EventArgs e)
    {
        base.OnMouseLeave(e);
        hot = 0; lastTipDay = -1; F.Tip.Hide(this); Invalidate();
    }
    protected override void OnMouseUp(MouseEventArgs e)
    {
        base.OnMouseUp(e);
        if (e.Button != MouseButtons.Left) return;
        int d = HitDay(e.Location);
        if (d > 0) { F.Tip.Hide(this); lastTipDay = -1; F.ToggleLeave(CalForm.Key(F.Y, Month, d)); }
    }
}

class CalForm : Form
{
    // ---- state ----
    public bool[] work = new bool[7];
    List<PHol> personal = new List<PHol>();
    List<string> disabled = new List<string>(), leave = new List<string>();
    int lang = 0, zoom = 100; bool dark = false;
    public Pal P = Pal.Light();
    public double S = 10; public int Y = DateTime.Today.Year;
    public ToolTip Tip = new ToolTip();
    bool ready = false;
    Dictionary<int, List<Hol>> hcache = new Dictionary<int, List<Hol>>();
    Dictionary<string, Hol> hmap = new Dictionary<string, Hol>();
    Dictionary<string, Font> fc = new Dictionary<string, Font>();
    float dpi = 1f;

    static readonly string[] MonthsEN = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };
    static readonly string[] MonthsEL = { "Ιανουάριος", "Φεβρουάριος", "Μάρτιος", "Απρίλιος", "Μάιος", "Ιούνιος", "Ιούλιος", "Αύγουστος", "Σεπτέμβριος", "Οκτώβριος", "Νοέμβριος", "Δεκέμβριος" };
    static readonly string[] ShortEN = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
    static readonly string[] ShortEL = { "Ιαν", "Φεβ", "Μαρ", "Απρ", "Μάι", "Ιουν", "Ιουλ", "Αυγ", "Σεπ", "Οκτ", "Νοε", "Δεκ" };
    static readonly string[] DaysEN = { "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun" };
    static readonly string[] DaysEL = { "Δε", "Τρ", "Τε", "Πε", "Πα", "Σα", "Κυ" };
    static readonly int[] DowOrder = { 1, 2, 3, 4, 5, 6, 0 };

    // ---- controls ----
    Panel top, host, main;
    Label lblYear, lblSize, lblZoomVal, lblStatus, lblTitle, lblWSum, lblLeaveTotal, lblLongTotal;
    ComboBox cbYear; TrackBar tbZoom;
    Button btnLang, btnTheme, btnExport, btnImport;
    IconBtn btnSave;
    Box boxHol, boxWork, boxLeave, boxLong;
    ListBox lbHol, lbLeave, lbLong;
    CheckBox[] chkDay = new CheckBox[7];
    DateTimePicker dtp; TextBox txtName; CheckBox chkYearly; Button btnAdd;
    ContextMenuStrip cms; ToolStripMenuItem miRemove;
    MonthCtl[] months = new MonthCtl[12];
    Timer flashTimer = new Timer();
    Row ctxRow;

    [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern IntPtr SendMessage(IntPtr h, int msg, IntPtr w, string l);

    [STAThread]
    static void Main()
    {
        try { if (Environment.OSVersion.Platform == PlatformID.Win32NT) SetProcessDPIAware(); } catch (Exception) { }
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new CalForm());
    }

    // ---- helpers ----
    string T(string en, string el) { return lang == 1 ? el : en; }
    string Nn(int n, string en1, string enN, string el1, string elN) { return n == 1 ? T(en1, el1) : T(enN, elN); }
    public string MonthName(int m) { return (lang == 1 ? MonthsEL : MonthsEN)[m - 1]; }
    string Short(int m) { return (lang == 1 ? ShortEL : ShortEN)[m - 1]; }
    public string[] DayNames() { return lang == 1 ? DaysEL : DaysEN; }
    public static string Key(int y, int m, int d) { return y.ToString("0000") + "-" + m.ToString("00") + "-" + d.ToString("00"); }
    int D(int px) { return (int)Math.Round(px * dpi); }
    int U(double x) { return (int)Math.Round(x * S); }
    public bool IsDisabled(string k) { return disabled.Contains(k); }
    public bool IsLeave(string k) { return leave.Contains(k); }
    public Hol HolAt(string k) { Hol h; return hmap.TryGetValue(k, out h) ? h : null; }

    public Font Fnt(double px, bool bold, bool strike)
    {
        string k = Math.Round(px * 2) + "|" + bold + "|" + strike; Font f;
        if (!fc.TryGetValue(k, out f))
        {
            FontStyle st = FontStyle.Regular; if (bold) st |= FontStyle.Bold; if (strike) st |= FontStyle.Strikeout;
            f = new Font("Segoe UI", (float)Math.Max(6, px), st, GraphicsUnit.Pixel); fc[k] = f;
        }
        return f;
    }

    public static void FillRound(Graphics g, RectangleF r, float rad, Color fill, Color border, bool dashed)
    {
        using (GraphicsPath gp = new GraphicsPath())
        {
            float d = Math.Max(1f, rad * 2);
            gp.AddArc(r.X, r.Y, d, d, 180, 90); gp.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            gp.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90); gp.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            gp.CloseFigure();
            if (!fill.IsEmpty) using (Brush b = new SolidBrush(fill)) g.FillPath(b, gp);
            if (!border.IsEmpty) using (Pen pn = new Pen(border)) { if (dashed) pn.DashStyle = DashStyle.Dash; g.DrawPath(pn, gp); }
        }
    }

    // ---- holiday logic ----
    static DateTime OrthodoxEaster(int y)
    {
        int a = y % 4, b = y % 7, c = y % 19, d = (19 * c + 15) % 30, e = (2 * a + 4 * b - d + 34) % 7;
        int s = d + e + 114, m = s / 31, dd = (s % 31) + 1;
        return new DateTime(y, m, dd).AddDays(13);
    }
    static int CmpHol(Hol a, Hol b) { return a.Month != b.Month ? a.Month.CompareTo(b.Month) : a.Day.CompareTo(b.Day); }
    static List<Hol> BuildHolidays(int y)
    {
        DateTime E = OrthodoxEaster(y); List<Hol> l = new List<Hol>();
        l.Add(new Hol { Month = 1, Day = 1, Gr = "Πρωτοχρονιά", En = "New Year's Day" });
        l.Add(new Hol { Month = 1, Day = 6, Gr = "Θεοφάνεια", En = "Epiphany" });
        l.Add(new Hol { Month = 3, Day = 25, Gr = "Ευαγγελισμός της Θεοτόκου", En = "Annunciation / Independence Day" });
        l.Add(new Hol { Month = 5, Day = 1, Gr = "Εργατική Πρωτομαγιά", En = "Labour Day" });
        l.Add(new Hol { Month = 8, Day = 15, Gr = "Κοίμηση της Θεοτόκου", En = "Assumption of Mary" });
        l.Add(new Hol { Month = 10, Day = 28, Gr = "Ημέρα του Όχι", En = "Ohi Day" });
        l.Add(new Hol { Month = 12, Day = 25, Gr = "Χριστούγεννα", En = "Christmas Day" });
        l.Add(new Hol { Month = 12, Day = 26, Gr = "Σύναξη της Θεοτόκου", En = "St. Stephen's Day (Synaxis)" });
        int[] off = { -48, -2, -1, 0, 1, 49, 50 };
        string[] gr = { "Καθαρά Δευτέρα", "Μεγάλη Παρασκευή", "Μεγάλο Σάββατο", "Κυριακή του Πάσχα", "Δευτέρα του Πάσχα", "Πεντηκοστή", "Αγίου Πνεύματος" };
        string[] en = { "Clean Monday", "Good Friday", "Holy Saturday", "Easter Sunday", "Easter Monday", "Pentecost", "Holy Spirit Monday" };
        for (int i = 0; i < off.Length; i++) { DateTime t = E.AddDays(off[i]); l.Add(new Hol { Month = t.Month, Day = t.Day, Gr = gr[i], En = en[i] }); }
        l.Sort(CmpHol); return l;
    }
    List<Hol> Official(int y)
    {
        List<Hol> l; if (!hcache.TryGetValue(y, out l)) { l = BuildHolidays(y); hcache[y] = l; } return l;
    }
    List<Hol> PersonalFor(int y)
    {
        List<Hol> r = new List<Hol>();
        foreach (PHol p in personal)
        {
            DateTime dt;
            if (!DateTime.TryParseExact(p.Date, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out dt)) continue;
            if (p.Yearly)
            {
                if (dt.Month == 2 && dt.Day == 29 && !DateTime.IsLeapYear(y)) continue;
                r.Add(new Hol { Month = dt.Month, Day = dt.Day, Gr = p.Name, En = p.Name, Pid = p.Id, Yearly = true });
            }
            else if (dt.Year == y) r.Add(new Hol { Month = dt.Month, Day = dt.Day, Gr = p.Name, En = p.Name, Pid = p.Id });
        }
        return r;
    }
    string HName(Hol h) { return lang == 1 ? h.Gr : h.En; }
    public string TipFor(int y, int m, int d)
    {
        string k = Key(y, m, d); Hol h = HolAt(k); string s = "";
        if (h != null) s = HName(h) + (IsDisabled(k) ? " (" + T("disabled this year", "απενεργοποιημένη φέτος") + ")" : "") + ". ";
        return s + (IsLeave(k) ? T("Leave day. Click to remove", "Ημέρα άδειας. Πατήστε για αφαίρεση") : T("Click to mark as leave", "Πατήστε για να οριστεί ως άδεια"));
    }

    // ---- construction ----
    public CalForm()
    {
        using (Graphics g = CreateGraphics()) dpi = g.DpiX / 96f;
        work[1] = work[2] = work[3] = work[4] = work[5] = true;
        Text = "Greece Annual Calendar";
        StartPosition = FormStartPosition.CenterScreen;
        Rectangle wa = Screen.PrimaryScreen.WorkingArea;
        ClientSize = new Size((int)(wa.Width * 0.9), (int)(wa.Height * 0.88));
        MinimumSize = new Size(D(640), D(480));
        DoubleBuffered = true;
        Tip.InitialDelay = 100;

        LoadFile();

        top = new Panel(); top.Dock = DockStyle.Top; top.Height = D(46);
        host = new Panel(); host.Dock = DockStyle.Fill; host.AutoScroll = true;
        main = new Panel(); host.Controls.Add(main);
        Controls.Add(host); Controls.Add(top);

        Font uf = new Font("Segoe UI", 9f);
        lblTitle = new Label(); lblTitle.AutoSize = true; lblTitle.Font = new Font("Georgia", 13f, FontStyle.Bold);
        lblYear = new Label(); lblYear.AutoSize = true; lblYear.Font = uf;
        cbYear = new ComboBox(); cbYear.DropDownStyle = ComboBoxStyle.DropDownList; cbYear.Font = uf;
        for (int y = 2000; y <= 2050; y++) cbYear.Items.Add(y);
        if (Y < 2000 || Y > 2050) Y = 2026;
        cbYear.SelectedItem = Y;
        cbYear.SelectedIndexChanged += delegate { Y = (int)cbYear.SelectedItem; RefreshAll(); };
        lblSize = new Label(); lblSize.AutoSize = true; lblSize.Font = uf;
        tbZoom = new TrackBar(); tbZoom.Minimum = 50; tbZoom.Maximum = 150; tbZoom.TickFrequency = 25; tbZoom.SmallChange = 5; tbZoom.LargeChange = 10;
        tbZoom.Value = zoom; tbZoom.AutoSize = false; tbZoom.TickStyle = TickStyle.None;
        lblZoomVal = new Label(); lblZoomVal.AutoSize = false; lblZoomVal.TextAlign = ContentAlignment.MiddleRight; lblZoomVal.Font = uf;
        tbZoom.ValueChanged += delegate { zoom = tbZoom.Value; lblZoomVal.Text = zoom + "%"; LayoutAll(); };
        btnLang = MkBtn(uf); btnTheme = MkBtn(uf); btnExport = MkBtn(uf); btnImport = MkBtn(uf);
        btnLang.Click += delegate { lang = 1 - lang; ApplyLanguage(); SaveFile(); };
        btnTheme.Click += delegate { dark = !dark; ApplyTheme(); SaveFile(); };
        btnExport.Click += delegate { DoExport(); };
        btnImport.Click += delegate { DoImport(); };
        btnSave = new IconBtn(); btnSave.FlatStyle = FlatStyle.Flat; btnSave.Click += delegate { SaveFile(); Flash(T("Saved", "Αποθηκεύτηκε")); };
        lblStatus = new Label(); lblStatus.AutoSize = false; lblStatus.Font = uf; lblStatus.TextAlign = ContentAlignment.MiddleLeft;
        top.Controls.AddRange(new Control[] { lblTitle, lblYear, cbYear, lblSize, tbZoom, lblZoomVal, btnLang, btnTheme, btnSave, lblStatus, btnExport, btnImport });
        top.Resize += delegate { LayoutTop(); };
        flashTimer.Interval = 2000; flashTimer.Tick += delegate { lblStatus.Text = ""; flashTimer.Stop(); };

        boxHol = new Box(); boxWork = new Box(); boxLeave = new Box(); boxLong = new Box();
        main.Controls.AddRange(new Control[] { boxHol, boxWork, boxLeave, boxLong });
        lbHol = MkList(); lbLeave = MkList(); lbLong = MkList();
        boxHol.Controls.Add(lbHol); boxLeave.Controls.Add(lbLeave); boxLong.Controls.Add(lbLong);
        lbHol.MouseDown += HolMouseDown;
        cms = new ContextMenuStrip(); miRemove = new ToolStripMenuItem();
        cms.Items.Add(miRemove);
        miRemove.Click += delegate
        {
            if (ctxRow != null && ctxRow.Tag != null)
            {
                string pid = ((Hol)ctxRow.Tag).Pid; if (pid == null) return;
                personal.RemoveAll(delegate(PHol p) { return p.Id == pid; });
                Persist();
            }
        };

        for (int i = 0; i < 7; i++)
        {
            CheckBox c = new CheckBox(); c.Appearance = Appearance.Button; c.FlatStyle = FlatStyle.Flat; c.TextAlign = ContentAlignment.MiddleCenter;
            c.Checked = work[DowOrder[i]]; int dow = DowOrder[i];
            c.CheckedChanged += delegate(object s, EventArgs ev)
            {
                CheckBox cc = (CheckBox)s; work[dow] = cc.Checked; StyleDayBtn(cc); SaveFile(); RefreshAll();
            };
            chkDay[i] = c; boxWork.Controls.Add(c);
        }
        lblWSum = new Label(); boxWork.Controls.Add(lblWSum);
        lblLeaveTotal = new Label(); boxLeave.Controls.Add(lblLeaveTotal);
        lblLongTotal = new Label(); boxLong.Controls.Add(lblLongTotal);

        dtp = new DateTimePicker(); dtp.Format = DateTimePickerFormat.Short;
        dtp.MinDate = new DateTime(2000, 1, 1); dtp.MaxDate = new DateTime(2050, 12, 31);
        try { dtp.Value = new DateTime(Y, Math.Min(DateTime.Today.Month, 12), Math.Min(DateTime.Today.Day, 28)); } catch (Exception) { }
        txtName = new TextBox(); txtName.MaxLength = 40;
        chkYearly = new CheckBox(); btnAdd = MkBtn(uf);
        btnAdd.Click += delegate { AddPersonal(); };
        txtName.KeyDown += delegate(object s, KeyEventArgs ev) { if (ev.KeyCode == Keys.Enter) { ev.SuppressKeyPress = true; AddPersonal(); } };
        boxHol.Controls.AddRange(new Control[] { dtp, txtName, chkYearly, btnAdd });

        for (int m = 1; m <= 12; m++)
        {
            MonthCtl mc = new MonthCtl(); mc.F = this; mc.Month = m; months[m - 1] = mc; main.Controls.Add(mc);
        }

        lblZoomVal.Text = zoom + "%";
        Resize += delegate { LayoutAll(); };
        FormClosing += delegate { SaveFile(); };
        ready = true;
        ApplyLanguage();
        ApplyTheme();
    }

    Button MkBtn(Font f)
    {
        Button b = new Button(); b.FlatStyle = FlatStyle.Flat; b.Font = f; b.UseVisualStyleBackColor = false; return b;
    }
    ListBox MkList()
    {
        ListBox l = new ListBox(); l.DrawMode = DrawMode.OwnerDrawFixed; l.BorderStyle = BorderStyle.None; l.IntegralHeight = false;
        l.DrawItem += DrawRow; return l;
    }

    void AddPersonal()
    {
        string n = txtName.Text.Trim(); if (n.Length == 0) { txtName.Focus(); return; }
        PHol p = new PHol(); p.Id = Guid.NewGuid().ToString("N"); p.Date = dtp.Value.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
        p.Name = n; p.Yearly = chkYearly.Checked; personal.Add(p);
        txtName.Text = ""; chkYearly.Checked = false;
        if (!p.Yearly && dtp.Value.Year != Y) { Y = dtp.Value.Year; cbYear.SelectedItem = Y; }
        Persist();
    }

    public void ToggleLeave(string k)
    {
        if (leave.Contains(k)) leave.Remove(k); else leave.Add(k);
        Persist();
    }
    void ToggleHol(string k)
    {
        if (disabled.Contains(k)) disabled.Remove(k); else disabled.Add(k);
        Persist();
    }
    void Persist() { SaveFile(); RefreshAll(); }

    void HolMouseDown(object sender, MouseEventArgs e)
    {
        int idx = lbHol.IndexFromPoint(e.Location);
        if (idx < 0 || idx >= lbHol.Items.Count) return;
        Row r = (Row)lbHol.Items[idx]; Hol h = r.Tag as Hol; if (h == null) return;
        if (e.Button == MouseButtons.Left) ToggleHol(Key(Y, h.Month, h.Day));
        else if (e.Button == MouseButtons.Right && h.Pid != null) { ctxRow = r; cms.Show(lbHol, e.Location); }
    }

    // ---- drawing of list rows ----
    void DrawRow(object sender, DrawItemEventArgs e)
    {
        ListBox lb = (ListBox)sender; if (e.Index < 0 || e.Index >= lb.Items.Count) return;
        Row r = (Row)lb.Items[e.Index]; Graphics g = e.Graphics; Rectangle b = e.Bounds;
        using (Brush bg = new SolidBrush(P.Card)) g.FillRectangle(bg, b);
        using (Pen pn = new Pen(P.Line)) g.DrawLine(pn, b.Left, b.Bottom - 1, b.Right, b.Bottom - 1);
        Color fg = r.Dim ? P.Muted : P.Text;
        TextFormatFlags fl = TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine | TextFormatFlags.NoPadding | TextFormatFlags.EndEllipsis;
        int pad = U(0.2); int right = b.Right - pad;
        if (r.Right.Length > 0)
        {
            Font fr = Fnt(S * 0.72, false, false); int w = TextRenderer.MeasureText(r.Right, fr).Width;
            TextRenderer.DrawText(g, r.Right, fr, new Rectangle(right - w, b.Top, w, b.Height - 1), P.Muted, TextFormatFlags.Right | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.NoPadding);
            right -= w + U(0.4);
        }
        int x = b.Left + pad;
        if (r.Date.Length > 0)
        {
            int dw = r.Name.Length > 0 ? U(3.9) : Math.Max(10, right - x);
            TextRenderer.DrawText(g, r.Date, Fnt(S * 0.8, true, false), new Rectangle(x, b.Top, dw, b.Height - 1), fg, fl);
            x += dw;
        }
        if (r.Name.Length > 0)
            TextRenderer.DrawText(g, r.Name, Fnt(S * 0.8, r.Date.Length == 0 ? false : false, r.Strike), new Rectangle(x, b.Top, Math.Max(10, right - x), b.Height - 1), fg, fl);
    }

    // ---- refresh ----
    void RefreshAll()
    {
        if (!ready) return;
        int y = Y;
        List<Hol> offs = Official(y), mine = PersonalFor(y);
        List<Hol> all = new List<Hol>(offs); all.AddRange(mine); all.Sort(CmpHol);
        hmap.Clear();
        foreach (Hol h in offs) { string k = Key(y, h.Month, h.Day); if (!hmap.ContainsKey(k)) hmap[k] = h; }
        foreach (Hol h in mine) { string k = Key(y, h.Month, h.Day); if (!hmap.ContainsKey(k)) hmap[k] = h; }

        int ti = lbHol.TopIndex;
        lbHol.BeginUpdate(); lbHol.Items.Clear();
        foreach (Hol h in all)
        {
            Row r = new Row(); r.Date = Short(h.Month) + " " + h.Day; r.Name = HName(h); r.Tag = h; r.Mine = h.Pid != null;
            r.Dim = r.Strike = disabled.Contains(Key(y, h.Month, h.Day));
            if (h.Pid != null && h.Yearly) r.Right = T("yearly", "ετήσια");
            lbHol.Items.Add(r);
        }
        lbHol.EndUpdate();
        if (ti > 0 && ti < lbHol.Items.Count) lbHol.TopIndex = ti;

        int wdays = 0;
        for (DateTime d = new DateTime(y, 1, 1); d.Year == y; d = d.AddDays(1))
        {
            string k = Key(y, d.Month, d.Day); bool has = hmap.ContainsKey(k); bool dis = has && disabled.Contains(k);
            if (work[(int)d.DayOfWeek] && (!has || dis)) wdays++;
        }
        int wc = 0; for (int i = 0; i < 7; i++) if (work[i]) wc++;
        lblWSum.Text = wc + " " + Nn(wc, "working day", "working days", "εργάσιμη ημέρα", "εργάσιμες ημέρες") + T(" per week · ", " την εβδομάδα · ")
            + wdays + " " + Nn(wdays, "working day", "working days", "εργάσιμη ημέρα", "εργάσιμες ημέρες") + T(" in " + y + " after holidays", " το " + y + " μετά τις αργίες");

        RefreshLeave(y); RefreshLong(y);
        foreach (MonthCtl m in months) m.Invalidate();
    }

    void AddEmpty(ListBox lb, string t) { Row r = new Row(); r.Name = t; r.Dim = true; lb.Items.Add(r); }
    string Range(DateTime a, DateTime b)
    {
        if (a.Month == b.Month) return Short(a.Month) + " " + a.Day + "–" + b.Day;
        return Short(a.Month) + " " + a.Day + " – " + Short(b.Month) + " " + b.Day;
    }
    static DateTime ParseKey(string k) { return DateTime.ParseExact(k, "yyyy-MM-dd", CultureInfo.InvariantCulture); }

    void RefreshLeave(int y)
    {
        List<string> ks = new List<string>();
        foreach (string k in leave) if (k.StartsWith(y + "-") && !ks.Contains(k)) ks.Add(k);
        ks.Sort(StringComparer.Ordinal);
        lblLeaveTotal.Text = T("Total: ", "Σύνολο: ") + ks.Count + " " + Nn(ks.Count, "leave day", "leave days", "ημέρα άδειας", "ημέρες άδειας") + T(" in ", " το ") + y;
        lbLeave.BeginUpdate(); lbLeave.Items.Clear();
        int i = 0;
        while (i < ks.Count)
        {
            int j = i;
            while (j + 1 < ks.Count && (ParseKey(ks[j + 1]) - ParseKey(ks[j])).Days == 1) j++;
            int n = j - i + 1; Row r = new Row();
            r.Date = Range(ParseKey(ks[i]), ParseKey(ks[j])); r.Right = n + " " + Nn(n, "day", "days", "ημέρα", "ημέρες");
            lbLeave.Items.Add(r); i = j + 1;
        }
        if (ks.Count == 0) AddEmpty(lbLeave, T("No leave marked for " + y + ".", "Δεν έχει οριστεί άδεια για το " + y + "."));
        lbLeave.EndUpdate();
    }

    void RefreshLong(int y)
    {
        lbLong.BeginUpdate(); lbLong.Items.Clear();
        int wc = 0; for (int i = 0; i < 7; i++) if (work[i]) wc++;
        if (wc == 0) { lblLongTotal.Text = ""; AddEmpty(lbLong, T("Tick at least one working day.", "Επιλέξτε τουλάχιστον μία εργάσιμη ημέρα.")); lbLong.EndUpdate(); return; }
        HashSet<string> hol = new HashSet<string>();
        for (int yy = y - 1; yy <= y + 1; yy++)
        {
            foreach (Hol h in Official(yy)) hol.Add(Key(yy, h.Month, h.Day));
            foreach (Hol h in PersonalFor(yy)) hol.Add(Key(yy, h.Month, h.Day));
        }
        List<DateTime[]> runs = new List<DateTime[]>(); List<bool> hasLv = new List<bool>(); List<int> lens = new List<int>();
        bool inRun = false; DateTime st = DateTime.MinValue, en = DateTime.MinValue; int cnt = 0; bool lv = false;
        for (DateTime d = new DateTime(y - 1, 12, 1); d <= new DateTime(y + 1, 1, 31); d = d.AddDays(1))
        {
            string k = Key(d.Year, d.Month, d.Day); bool isLeave = leave.Contains(k);
            bool free = !work[(int)d.DayOfWeek] || (hol.Contains(k) && !disabled.Contains(k)) || isLeave;
            if (free) { if (!inRun) { inRun = true; st = d; cnt = 0; lv = false; } cnt++; en = d; if (isLeave) lv = true; }
            else if (inRun) { runs.Add(new DateTime[] { st, en }); lens.Add(cnt); hasLv.Add(lv); inRun = false; }
        }
        if (inRun) { runs.Add(new DateTime[] { st, en }); lens.Add(cnt); hasLv.Add(lv); }
        int shown = 0;
        for (int i = 0; i < runs.Count; i++)
        {
            if (lens[i] < 3 || runs[i][1].Year < y || runs[i][0].Year > y) continue;
            Row r = new Row(); r.Date = Range(runs[i][0], runs[i][1]);
            r.Right = (hasLv[i] ? "* " : "") + lens[i] + " " + T("days", "ημέρες"); lbLong.Items.Add(r); shown++;
        }
        lblLongTotal.Text = T("Total: ", "Σύνολο: ") + shown + " " + Nn(shown, "stretch", "stretches", "διάστημα", "διαστήματα") + T(" in ", " το ") + y;
        if (shown == 0) AddEmpty(lbLong, T("No stretch of 3+ days off in " + y + ".", "Κανένα διάστημα 3+ ημερών ρεπό το " + y + "."));
        lbLong.EndUpdate();
    }

    // ---- language & theme ----
    void ApplyLanguage()
    {
        Text = T("Greece Annual Calendar", "Ημερολόγιο Αργιών Ελλάδας");
        lblTitle.Text = Text;
        lblYear.Text = T("Year", "Έτος"); lblSize.Text = T("Size", "Μέγεθος");
        btnLang.Text = lang == 1 ? "EN" : "ΕΛ";
        btnTheme.Text = T("Theme", "Θέμα"); btnExport.Text = T("Export", "Εξαγωγή"); btnImport.Text = T("Import", "Εισαγωγή");
        boxHol.Title = T("Greek holidays", "Αργίες");
        boxHol.Hint = T("Click a holiday to switch it off for this year only. Right-click one of your own to remove it.",
                        "Πατήστε σε μια αργία για να την απενεργοποιήσετε μόνο για αυτό το έτος. Δεξί κλικ σε δική σας αργία για αφαίρεση.");
        boxWork.Title = T("Working days per week", "Εργάσιμες ημέρες την εβδομάδα");
        boxLeave.Title = T("Leave days", "Ημέρες άδειας");
        boxLeave.Hint = T("Click any day on the calendar to mark it as leave. Click it again to clear it.",
                          "Πατήστε σε μια ημέρα του ημερολογίου για να την ορίσετε ως άδεια. Πατήστε ξανά για να την αφαιρέσετε.");
        boxLong.Title = T("Long weekends", "Μεγάλα Σαββατοκύριακα");
        boxLong.Hint = T("Three or more days off in a row (weekends, holidays, leave). * = includes leave.",
                         "Τρεις ή περισσότερες συνεχόμενες ημέρες ρεπό (Σαββατοκύριακα, αργίες, άδειες). * = περιλαμβάνει άδεια.");
        string[] dn = DayNames(); for (int i = 0; i < 7; i++) chkDay[i].Text = dn[i];
        chkYearly.Text = T("Repeat every year", "Επανάληψη κάθε χρόνο");
        btnAdd.Text = T("Add your own holiday", "Προσθήκη δικής σας αργίας");
        miRemove.Text = T("Remove this holiday", "Αφαίρεση αυτής της αργίας");
        try { SendMessage(txtName.Handle, 0x1501, (IntPtr)1, T("Name, e.g. Name day", "Όνομα, π.χ. Η γιορτή μου")); } catch (Exception) { }
        LayoutTop(); LayoutAll(); RefreshAll();
    }

    void StyleDayBtn(CheckBox c)
    {
        c.ForeColor = c.Checked ? P.Card : P.Muted;
        c.BackColor = c.Checked ? P.Blue : P.Card;
        c.FlatAppearance.BorderColor = c.Checked ? P.Blue : P.Line;
        c.FlatAppearance.CheckedBackColor = P.Blue; c.FlatAppearance.MouseOverBackColor = c.Checked ? P.Blue : P.Bg;
    }
    void StyleBtn(Button b) { b.BackColor = P.Card; b.ForeColor = P.Text; b.FlatAppearance.BorderColor = P.Line; b.FlatAppearance.MouseOverBackColor = P.Bg; }

    void ApplyTheme()
    {
        P = dark ? Pal.Dark() : Pal.Light();
        BackColor = P.Bg; top.BackColor = P.Bg; host.BackColor = P.Bg; main.BackColor = P.Bg;
        foreach (Control c in new Control[] { lblTitle, lblYear, lblSize, lblZoomVal, lblStatus }) { c.BackColor = P.Bg; c.ForeColor = P.Text; }
        lblStatus.ForeColor = P.Muted; lblZoomVal.ForeColor = P.Muted;
        cbYear.BackColor = P.Card; cbYear.ForeColor = P.Text; tbZoom.BackColor = P.Bg;
        foreach (Button b in new Button[] { btnLang, btnTheme, btnExport, btnImport, btnAdd }) StyleBtn(b);
        StyleBtn(btnSave); btnSave.IconColor = P.Text;
        foreach (Box b in new Box[] { boxHol, boxWork, boxLeave, boxLong }) { b.P = P; b.BackColor = P.Card; b.Invalidate(); }
        foreach (ListBox l in new ListBox[] { lbHol, lbLeave, lbLong }) { l.BackColor = P.Card; l.ForeColor = P.Text; l.Invalidate(); }
        foreach (Label l in new Label[] { lblWSum, lblLeaveTotal, lblLongTotal }) { l.BackColor = P.Card; l.ForeColor = P.Text; }
        lblWSum.ForeColor = P.Muted;
        foreach (CheckBox c in chkDay) StyleDayBtn(c);
        dtp.CalendarMonthBackground = P.Card; dtp.CalendarForeColor = P.Text; dtp.CalendarTitleBackColor = P.Blue;
        txtName.BackColor = P.Bg; txtName.ForeColor = P.Text;
        chkYearly.BackColor = P.Card; chkYearly.ForeColor = P.Muted;
        foreach (MonthCtl m in months) m.Invalidate();
    }

    void Flash(string t) { lblStatus.Text = t; flashTimer.Stop(); flashTimer.Start(); }

    // ---- layout ----
    void LayoutTop()
    {
        if (top == null) return;
        int h = top.Height, g = D(8), x = top.ClientSize.Width - D(12);
        Button[] bs = { btnImport, btnExport };
        foreach (Button b in bs) { int w = TextRenderer.MeasureText(b.Text, b.Font).Width + D(24); b.SetBounds(x - w, (h - D(28)) / 2, w, D(28)); x -= w + g; }
        lblStatus.SetBounds(x - D(90), 0, D(90), h); x -= D(90);
        btnSave.SetBounds(x - D(34), (h - D(28)) / 2, D(34), D(28)); x -= D(34) + g;
        int wt = TextRenderer.MeasureText(btnTheme.Text, btnTheme.Font).Width + D(24); btnTheme.SetBounds(x - wt, (h - D(28)) / 2, wt, D(28)); x -= wt + g;
        int wl = TextRenderer.MeasureText(btnLang.Text, btnLang.Font).Width + D(24); btnLang.SetBounds(x - wl, (h - D(28)) / 2, wl, D(28)); x -= wl + g;
        lblZoomVal.SetBounds(x - D(44), 0, D(44), h); x -= D(44);
        tbZoom.SetBounds(x - D(120), (h - D(30)) / 2, D(120), D(30)); x -= D(120) + g / 2;
        lblSize.Location = new Point(x - lblSize.PreferredWidth, (h - lblSize.PreferredHeight) / 2); x -= lblSize.PreferredWidth + g * 2;
        cbYear.SetBounds(x - D(70), (h - cbYear.Height) / 2, D(70), cbYear.Height); x -= D(70) + g / 2;
        lblYear.Location = new Point(x - lblYear.PreferredWidth, (h - lblYear.PreferredHeight) / 2);
        lblTitle.Location = new Point(D(12), (h - lblTitle.PreferredHeight) / 2);
    }

    void LayoutAll()
    {
        if (!ready || WindowState == FormWindowState.Minimized) return;
        host.AutoScrollPosition = new Point(0, 0);
        double aw = ClientSize.Width - 24, ah = ClientSize.Height - top.Height - 24;
        S = Math.Min(aw / 97.0, ah / 44.0) * (zoom / 100.0); if (S < 6) S = 6;
        Size ms = new Size(U(97), U(44));
        main.Size = ms;
        host.AutoScrollMinSize = new Size(ms.Width + 24, ms.Height + 24);
        main.Location = new Point(Math.Max(12, (host.ClientSize.Width - ms.Width) / 2), 12);

        Font fT = Fnt(S * 0.95, true, false), fH = Fnt(S * 0.72, false, false), fB = Fnt(S * 0.8, false, false), fBold = Fnt(S * 0.8, true, false);
        int pad = U(0.8);
        foreach (Box b in new Box[] { boxHol, boxWork, boxLeave, boxLong }) { b.FTitle = fT; b.FHint = fH; b.Pad = pad; }
        int rowH = U(1.6);
        foreach (ListBox l in new ListBox[] { lbHol, lbLeave, lbLong }) { l.ItemHeight = rowH; l.Font = fB; }

        // column A: holidays
        boxHol.SetBounds(0, 0, U(17), U(44));
        int cx = pad, cw = boxHol.Width - 2 * pad, gap = U(0.35), y = boxHol.Height - pad;
        btnAdd.Font = fB; btnAdd.SetBounds(cx, y - U(2.1), cw, U(2.1)); y -= U(2.1) + gap;
        chkYearly.Font = fH; chkYearly.SetBounds(cx, y - U(1.5), cw, U(1.5)); y -= U(1.5) + gap;
        txtName.Font = fB; txtName.SetBounds(cx, y - txtName.Height, cw, txtName.Height); y -= txtName.Height + gap;
        dtp.Font = fB; dtp.SetBounds(cx, y - dtp.Height, cw, dtp.Height); y -= dtp.Height + gap * 2;
        int ct = boxHol.ContentTop();
        lbHol.SetBounds(cx, ct, cw, Math.Max(U(3), y - ct));

        // column B
        int bx = U(18.2), bw = U(17);
        int h1 = U(9.6), h2 = (U(44) - h1 - 2 * U(0.8)) / 2;
        boxWork.SetBounds(bx, 0, bw, h1);
        boxLeave.SetBounds(bx, h1 + U(0.8), bw, h2);
        boxLong.SetBounds(bx, h1 + U(0.8) + h2 + U(0.8), bw, U(44) - (h1 + U(0.8) + h2 + U(0.8)));
        // working days
        int wt = boxWork.ContentTop(), bg = U(0.3), cwb = bw - 2 * pad, bwid = (cwb - 6 * bg) / 7, bh = U(2.2);
        for (int i = 0; i < 7; i++) { chkDay[i].Font = fH; chkDay[i].SetBounds(pad + i * (bwid + bg), wt, bwid, bh); }
        lblWSum.Font = fH; lblWSum.SetBounds(pad, wt + bh + U(0.6), cwb, boxWork.Height - (wt + bh + U(0.6)) - pad);
        // leave + long
        foreach (object[] o in new object[][] { new object[] { boxLeave, lblLeaveTotal, lbLeave }, new object[] { boxLong, lblLongTotal, lbLong } })
        {
            Box b = (Box)o[0]; Label tl = (Label)o[1]; ListBox lb = (ListBox)o[2];
            int t = b.ContentTop(); tl.Font = fBold; tl.SetBounds(pad, t, b.Width - 2 * pad, fBold.Height + 2);
            int lt = t + fBold.Height + U(0.5); lb.SetBounds(pad, lt, b.Width - 2 * pad, Math.Max(U(2), b.Height - lt - pad));
        }

        // months
        double mw = (60 - 3 * 0.7) / 4.0, mh = (44 - 2 * 0.7) / 3.0;
        for (int m = 0; m < 12; m++)
        {
            int c = m % 4, r = m / 4;
            months[m].SetBounds(U(36.4 + c * (mw + 0.7)), U(r * (mh + 0.7)), U(mw), U(mh));
        }
        Invalidate(true);
    }

    // ---- file storage ----
    string[] Paths()
    {
        string a = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "greece-calendar-data.json");
        string b = Path.Combine(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "GreeceCalendar"), "greece-calendar-data.json");
        return new string[] { a, b };
    }
    Dictionary<string, object> Snapshot(bool settings)
    {
        Dictionary<string, object> d = new Dictionary<string, object>();
        d["version"] = 3;
        List<object> w = new List<object>(); for (int i = 0; i < 7; i++) if (work[i]) w.Add(i); d["workdays"] = w;
        List<object> pl = new List<object>();
        foreach (PHol p in personal)
        {
            Dictionary<string, object> o = new Dictionary<string, object>();
            o["id"] = p.Id; o["date"] = p.Date; o["name"] = p.Name; o["yearly"] = p.Yearly; pl.Add(o);
        }
        d["personal"] = pl;
        List<object> dis = new List<object>(); foreach (string s in disabled) dis.Add(s); d["disabled"] = dis;
        List<object> lv = new List<object>(); foreach (string s in leave) lv.Add(s); d["leave"] = lv;
        if (settings) { d["lang"] = lang == 1 ? "el" : "en"; d["theme"] = dark ? "dark" : "light"; d["zoom"] = zoom; }
        return d;
    }
    static bool ToInt(object x, out int n)
    {
        n = 0; if (x == null || x is string) return false;
        try { n = Convert.ToInt32(x); return true; } catch (Exception) { return false; }
    }
    bool Apply(object root, bool settings)
    {
        Dictionary<string, object> o = root as Dictionary<string, object>; if (o == null) return false;
        Regex dre = new Regex(@"^\d{4}-\d{2}-\d{2}$"); bool any = false; object v;
        if (o.TryGetValue("workdays", out v) && v is IEnumerable && !(v is string))
        {
            bool[] nw = new bool[7]; int n;
            foreach (object x in (IEnumerable)v) if (ToInt(x, out n) && n >= 0 && n <= 6) nw[n] = true;
            work = nw; any = true;
        }
        if (o.TryGetValue("personal", out v) && v is IEnumerable && !(v is string))
        {
            List<PHol> np = new List<PHol>();
            foreach (object x in (IEnumerable)v)
            {
                Dictionary<string, object> q = x as Dictionary<string, object>; object a, b, c, d;
                if (q == null || !q.TryGetValue("date", out a) || !q.TryGetValue("name", out b)) continue;
                string ds = a as string, nm = b as string; if (ds == null || nm == null || !dre.IsMatch(ds)) continue;
                PHol p = new PHol(); p.Date = ds; p.Name = nm.Length > 40 ? nm.Substring(0, 40) : nm;
                p.Id = (q.TryGetValue("id", out c) && c != null) ? c.ToString() : Guid.NewGuid().ToString("N");
                p.Yearly = q.TryGetValue("yearly", out d) && d is bool && (bool)d; np.Add(p);
            }
            personal = np; any = true;
        }
        if (o.TryGetValue("disabled", out v) && v is IEnumerable && !(v is string))
        {
            List<string> l = new List<string>(); foreach (object x in (IEnumerable)v) { string s = x as string; if (s != null && dre.IsMatch(s) && !l.Contains(s)) l.Add(s); }
            disabled = l; any = true;
        }
        if (o.TryGetValue("leave", out v) && v is IEnumerable && !(v is string))
        {
            List<string> l = new List<string>(); foreach (object x in (IEnumerable)v) { string s = x as string; if (s != null && dre.IsMatch(s) && !l.Contains(s)) l.Add(s); }
            leave = l; any = true;
        }
        if (settings)
        {
            string ls = o.ContainsKey("lang") ? o["lang"] as string : null; if (ls == "el") lang = 1; else if (ls == "en") lang = 0;
            string th = o.ContainsKey("theme") ? o["theme"] as string : null; if (th == "dark") dark = true; else if (th == "light") dark = false;
            int z; if (o.ContainsKey("zoom") && ToInt(o["zoom"], out z) && z >= 50 && z <= 150) zoom = z;
        }
        return any;
    }
    void LoadFile()
    {
        foreach (string p in Paths())
        {
            try
            {
                if (!File.Exists(p)) continue;
                object root = new JavaScriptSerializer().DeserializeObject(File.ReadAllText(p));
                if (Apply(root, true)) return;
            }
            catch (Exception) { }
        }
    }
    public void SaveFile()
    {
        if (!ready) return;
        string json = new JavaScriptSerializer().Serialize(Snapshot(true));
        foreach (string p in Paths())
        {
            try { Directory.CreateDirectory(Path.GetDirectoryName(p)); File.WriteAllText(p, json); return; } catch (Exception) { }
        }
        Flash(T("Couldn't save", "Αδυναμία αποθήκευσης"));
    }
    void DoExport()
    {
        using (SaveFileDialog dlg = new SaveFileDialog())
        {
            dlg.FileName = "greece-calendar-data.json"; dlg.Filter = "JSON (*.json)|*.json";
            if (dlg.ShowDialog(this) != DialogResult.OK) return;
            try { File.WriteAllText(dlg.FileName, new JavaScriptSerializer().Serialize(Snapshot(false))); Flash(T("Exported", "Εξήχθη")); }
            catch (Exception) { Flash(T("Export failed", "Η εξαγωγή απέτυχε")); }
        }
    }
    void DoImport()
    {
        using (OpenFileDialog dlg = new OpenFileDialog())
        {
            dlg.Filter = "JSON (*.json)|*.json|*.*|*.*";
            if (dlg.ShowDialog(this) != DialogResult.OK) return;
            bool ok = false;
            try { ok = Apply(new JavaScriptSerializer().DeserializeObject(File.ReadAllText(dlg.FileName)), false); } catch (Exception) { }
            if (ok)
            {
                for (int i = 0; i < 7; i++) chkDay[i].Checked = work[DowOrder[i]];
                SaveFile(); RefreshAll(); Flash(T("Imported", "Εισήχθη"));
            }
            else Flash(T("Not a valid calendar file", "Μη έγκυρο αρχείο ημερολογίου"));
        }
    }
}
