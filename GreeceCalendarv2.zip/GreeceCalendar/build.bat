@echo off
rem Builds GreeceCalendar.exe using the C# compiler that is already part of Windows.
set CSC=%windir%\Microsoft.NET\Framework64\v4.0.30319\csc.exe
if not exist "%CSC%" set CSC=%windir%\Microsoft.NET\Framework\v4.0.30319\csc.exe
if not exist "%CSC%" (
  echo Could not find the Windows C# compiler. Please tell Claude about this message.
  pause
  exit /b 1
)
cd /d "%~dp0"
"%CSC%" /nologo /target:winexe /codepage:65001 /optimize+ /out:GreeceCalendar.exe /reference:System.Windows.Forms.dll /reference:System.Drawing.dll /reference:System.Web.Extensions.dll GreeceCalendar.cs
if errorlevel 1 (
  echo.
  echo Something went wrong. Please copy the text above and send it to Claude.
) else (
  echo.
  echo Done! GreeceCalendar.exe has been created in this folder.
)
pause
