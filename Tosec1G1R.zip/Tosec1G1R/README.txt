TOSEC 1G1R FILTER
=================

WHAT IT DOES
  Reads a folder of TOSEC-named files (archives, .dsk, .adf, .tap ... any extension,
  or none), applies the filters you choose, keeps the single best version of every game,
  and copies (or moves) those files into a new, empty folder.

WHAT YOU HAVE
  Tosec1G1R.exe     the program (about 60 KB, nothing to install)
  Tosec1G1R.cs      the source code (window)
  TosecCore.cs      the source code (selection rules)
  build.bat         rebuilds the .exe on your own PC if you ever need to

HOW TO USE
  1. Double-click Tosec1G1R.exe and follow the 8 steps. Every step explains itself.
  2. The first time, Windows may show a blue "Windows protected your PC" screen.
     Click "More info", then "Run anyway".
  If the .exe will not start: double-click build.bat, wait for "Done!", and use
  the freshly built Tosec1G1R.exe. (Nothing gets installed.)

THE 8 STEPS
  1 Input folder      Browse only. Shows how many files are valid TOSEC files
                      and lists everything that will be ignored: files that are not
                      TOSEC-named, and subfolders. The file extension does not matter.
                      Subfolders are never opened.
  2 Output folder     Browse only. Must exist and be completely empty.
                      Copy or Move. Move needs both folders on the same drive.
  3 Languages         English and Greek ticked at the start.
  4 Dump quality      Bad / over / under / virus-infected dumps left out.
  5 Modifications     Cracked, hacked, trained left out. Fixed, modified, pirated kept.
  6 Demos etc.        Demos, prototypes, alpha, beta, previews left out.
  7 Release date      Optional "from" and "to" year.
  8 Summary and Run   Shows what will happen and how many files, then Run.
                      Afterwards: save a text log of everything that was skipped and why.

HOW ONE VERSION OF EACH GAME IS CHOSEN
  Files with the same title are the same game (version, date, publisher and
  machine model such as (A500) are ignored; a compilation "A & B" is one title).
  After your filters, the best remaining file wins, in this order:
   0. an intact image beats a damaged one (only matters if you allowed damaged ones)
   1. completeness: commercial, licenceware (LW), registered shareware (SW-R),
      registered cardware / giftware (CW-R, GW-R), public domain / freeware,
      cardware / giftware, shareware (SW). Demos and pre-releases come last.
   2. originality: unmodified beats alternate [a], which beats modified
   3. language: English+Greek, then English, then Greek, then other ticked languages
   4. newest version, then verified dump [!]
   5. alphabetical order, only to break a final tie
  Multi-part games (Disk 1 of 2 ...) are kept together as a set. The best first
  part is chosen, and each other part comes from the same release when it exists
  (so a shared Disk 2 works with any version of Disk 1). Sets of different sizes
  (1 of 2 / 1 of 3) are different releases. A complete set beats an incomplete one.

HOW A FILE'S LANGUAGE IS WORKED OUT
  An explicit tag such as (de) or (JP)(en) is used as written. Otherwise a country
  tag means that country's official language: (DE) = German, (EU) and (AS) = English.
  No tag at all = English. A fan translation [tr el] counts as Greek instead of the
  original language, unless marked partial. (M3)-style tags are always kept.

SAFETY
  The program never deletes, renames, edits or extracts any file, and never
  overwrites anything. Copies keep the exact original names.
  Move only works when input and output are on the same drive, where Windows just
  re-files the entry (the data is not rewritten). It asks for confirmation first.
  If the drives differ, Move is greyed out - use Copy.

TO UNINSTALL
  Delete the folder. Nothing else was installed.
