using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

// TOSEC 1G1R Filter - the wizard window.
// Plain C# 5 (WinForms). Compiles with the C# compiler that ships with Windows.

namespace Tosec1G1R
{
    static class Program
    {
        [DllImport("user32.dll")]
        static extern bool SetProcessDPIAware();

        [STAThread]
        static void Main()
        {
            try { SetProcessDPIAware(); } catch (Exception) { }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new WizardForm());
        }
    }

    class LangItem
    {
        public string Code, Name;
        public override string ToString() { return Name + " (" + Code + ")"; }
    }

    class RunArgs { public List<TosecFile> Files; public string OutDir; public bool Move; }
    class RunResult { public int Done; public bool Cancelled; public List<string> Errors = new List<string>(); }

    class WizardForm : Form
    {
        const int PageCount = 8;
        static readonly Color Accent = Color.FromArgb(0x1d, 0x4f, 0x91);
        static readonly Color Bad = Color.FromArgb(0xb0, 0x2a, 0x2a);
        static readonly Color Good = Color.FromArgb(0x1e, 0x7a, 0x3e);

        readonly string[] titles = {
            "Input folder", "Output folder and mode", "Languages", "Dump quality",
            "Modifications", "Demos and unfinished builds", "Release date", "Summary and run"
        };

        Panel[] pages = new Panel[PageCount];
        int cur;
        Label lblStep, lblTitle;
        Button btnBack, btnNext, btnCancel;

        // page 1
        TextBox txtIn, txtIgnored;
        Label lblScan, lblIgnoredHdr;
        ScanResult scan;
        // page 2
        TextBox txtOut;
        Label lblOutStatus, lblModeHint;
        RadioButton rbCopy, rbMove;
        bool outOk;
        // page 3
        CheckedListBox clbLang;
        // pages 4-6
        CheckBox cbBad, cbOver, cbUnder, cbVirus;
        CheckBox cbCr, cbHack, cbTrain, cbFix, cbMod, cbPir;
        CheckBox cbDemo, cbProto, cbAlpha, cbBeta, cbPrev;
        // page 7
        CheckBox cbFrom, cbTo, cbUnknownDate;
        Label lblDateWarn;
        NumericUpDown nudFrom, nudTo;
        // page 8
        TextBox txtSummary;
        ProgressBar bar;
        Label lblStatus;
        Button btnSaveLog, btnOpenOut;
        BackgroundWorker worker;
        Options opts;
        Selection plan;
        string settingsText = "", logText = "";
        bool running, finished, closeWhenDone;
        bool moveMode;

        public WizardForm()
        {
            Text = "TOSEC 1G1R Filter";
            Font = new Font("Segoe UI", 9.5f);
            AutoScaleMode = AutoScaleMode.Dpi;
            AutoScaleDimensions = new SizeF(96f, 96f);
            ClientSize = new Size(820, 640);
            MinimumSize = new Size(740, 580);
            StartPosition = FormStartPosition.CenterScreen;

            // ---- header ----
            Panel head = new Panel(); head.Dock = DockStyle.Top; head.Height = 68; head.BackColor = Color.White;
            lblStep = new Label(); lblStep.AutoSize = true; lblStep.Left = 24; lblStep.Top = 10; lblStep.ForeColor = Color.DimGray;
            lblTitle = new Label(); lblTitle.AutoSize = true; lblTitle.Left = 24; lblTitle.Top = 28;
            lblTitle.Font = new Font("Segoe UI", 15f, FontStyle.Bold); lblTitle.ForeColor = Accent;
            head.Controls.Add(lblStep); head.Controls.Add(lblTitle);
            Panel headLine = new Panel(); headLine.Dock = DockStyle.Top; headLine.Height = 1; headLine.BackColor = Color.Silver;

            // ---- footer ----
            Panel foot = new Panel(); foot.Dock = DockStyle.Bottom; foot.Height = 54;
            Panel footLine = new Panel(); footLine.Dock = DockStyle.Bottom; footLine.Height = 1; footLine.BackColor = Color.Silver;
            FlowLayoutPanel flow = new FlowLayoutPanel(); flow.Dock = DockStyle.Fill; flow.FlowDirection = FlowDirection.RightToLeft;
            flow.Padding = new Padding(0, 10, 16, 0);
            btnCancel = MakeButton("Cancel"); btnNext = MakeButton("Next >"); btnBack = MakeButton("< Back");
            flow.Controls.Add(btnCancel); flow.Controls.Add(btnNext); flow.Controls.Add(btnBack);
            foot.Controls.Add(flow);
            btnBack.Click += delegate { GoBack(); };
            btnNext.Click += delegate { GoNext(); };
            btnCancel.Click += delegate { OnCancel(); };
            AcceptButton = btnNext;

            // ---- pages ----
            Panel host = new Panel(); host.Dock = DockStyle.Fill;
            BuildPage1(); BuildPage2(); BuildPage3(); BuildPage4(); BuildPage5(); BuildPage6(); BuildPage7(); BuildPage8();
            foreach (Panel p in pages) host.Controls.Add(p);

            Stack(this, head, headLine, foot, footLine, host);

            worker = new BackgroundWorker();
            worker.WorkerReportsProgress = true;
            worker.WorkerSupportsCancellation = true;
            worker.DoWork += WorkerDoWork;
            worker.ProgressChanged += WorkerProgress;
            worker.RunWorkerCompleted += WorkerDone;

            FormClosing += OnFormClosing;
            ShowPage(0);
        }

        // ============================================================
        // small layout helpers
        // ============================================================
        // Adds controls so that they appear in the given order (top docked ones top-down,
        // bottom docked ones bottom-up, and a Fill control last).
        static void Stack(Control parent, params Control[] cs)
        {
            foreach (Control c in cs) { parent.Controls.Add(c); c.BringToFront(); }
        }

        static Button MakeButton(string text)
        {
            Button b = new Button(); b.Text = text; b.Size = new Size(104, 32); b.Margin = new Padding(8, 0, 0, 0);
            b.FlatStyle = FlatStyle.System;
            return b;
        }

        static Panel NewPage()
        {
            Panel p = new Panel(); p.Dock = DockStyle.Fill; p.Padding = new Padding(24, 14, 24, 10); p.Visible = false;
            return p;
        }

        static Panel Spacer(int h)
        {
            Panel s = new Panel(); s.Dock = DockStyle.Top; s.Height = h;
            return s;
        }

        // A wrapping text label whose height follows its text.
        static Label Note(string text)
        {
            Label l = new Label();
            l.AutoSize = false; l.Dock = DockStyle.Top; l.Height = 24; l.Text = text;
            l.Resize += delegate { FitHeight(l); };
            l.TextChanged += delegate { FitHeight(l); };
            return l;
        }

        static void FitHeight(Label l)
        {
            if (l.Width <= 0) return;
            int w = l.Width - l.Padding.Horizontal;
            if (w <= 0) return;
            int h = TextRenderer.MeasureText(l.Text, l.Font, new Size(w, 0), TextFormatFlags.WordBreak | TextFormatFlags.NoPrefix).Height
                    + l.Padding.Vertical + 6;
            if (l.Height != h) l.Height = h;
        }

        static Label Muted(string text)
        {
            Label l = Note(text); l.ForeColor = Color.DimGray; return l;
        }

        static Label Bold(string text)
        {
            Label l = Note(text); l.Font = new Font(l.Font, FontStyle.Bold); return l;
        }

        // A read-only path box with a browse button next to it.
        static Panel FolderRow(out TextBox tb, out Button btn)
        {
            Panel row = new Panel(); row.Dock = DockStyle.Top; row.Height = 28;
            btn = new Button(); btn.Text = "Browse..."; btn.Dock = DockStyle.Right; btn.Width = 110; btn.FlatStyle = FlatStyle.System;
            Panel gap = new Panel(); gap.Dock = DockStyle.Right; gap.Width = 8;
            tb = new TextBox(); tb.ReadOnly = true; tb.Dock = DockStyle.Fill; tb.BackColor = SystemColors.Window;
            Stack(row, btn, gap, tb);
            return row;
        }

        static CheckBox AddOption(Panel p, string text, string desc, bool chk)
        {
            CheckBox cb = new CheckBox(); cb.Text = text; cb.Checked = chk; cb.AutoSize = false;
            cb.Dock = DockStyle.Top; cb.Height = 24;
            Label d = Muted(desc); d.Padding = new Padding(22, 0, 0, 0);
            Stack(p, cb, d, Spacer(4));
            return cb;
        }

        // ============================================================
        // the pages
        // ============================================================
        void BuildPage1()
        {
            Panel p = pages[0] = NewPage();
            Label expl = Note("Choose the folder that holds your TOSEC-named files (archives, disk images, tapes - the file extension does not matter). " +
                "The program looks only at the files directly inside it (subfolders are never opened) and keeps only files whose names follow the " +
                "TOSEC naming convention. Everything else is ignored. Nothing in this folder is changed.\r\n\r\n" +
                "The folder should hold one platform only (for example just Amiga or just ZX Spectrum), because games are matched by their title.");
            Button browse;
            Panel row = FolderRow(out txtIn, out browse);
            browse.Click += delegate { BrowseInput(); };
            lblScan = Bold(""); lblIgnoredHdr = Muted("Items that will be ignored:");
            lblIgnoredHdr.Visible = false;
            txtIgnored = new TextBox(); txtIgnored.Multiline = true; txtIgnored.ReadOnly = true; txtIgnored.ScrollBars = ScrollBars.Vertical;
            txtIgnored.Dock = DockStyle.Fill; txtIgnored.BackColor = SystemColors.Window; txtIgnored.Visible = false;
            Stack(p, expl, Spacer(10), row, Spacer(10), lblScan, Spacer(4), lblIgnoredHdr, txtIgnored);
        }

        void BuildPage2()
        {
            Panel p = pages[1] = NewPage();
            Label expl = Note("Choose an empty folder to receive the selected files. It must already exist and be completely empty, so " +
                "that nothing can be overwritten by mistake (use \"Make New Folder\" in the browse window to create one). " +
                "The files keep their exact original names and are never changed or extracted.");
            Button browse;
            Panel row = FolderRow(out txtOut, out browse);
            browse.Click += delegate { BrowseOutput(); };
            lblOutStatus = Note("");
            Label modeHdr = Bold("What should happen to the chosen files?");
            rbCopy = new RadioButton(); rbCopy.Text = "Copy - the originals stay where they are"; rbCopy.Checked = true;
            rbCopy.Dock = DockStyle.Top; rbCopy.Height = 26;
            rbMove = new RadioButton(); rbMove.Text = "Move - the files leave the input folder (same drive only)"; rbMove.Dock = DockStyle.Top; rbMove.Height = 26;
            rbCopy.CheckedChanged += delegate { UpdateModeHint(); };
            rbMove.CheckedChanged += delegate { UpdateModeHint(); };
            lblModeHint = Muted("");
            lblModeHint.Padding = new Padding(22, 0, 0, 0);
            Stack(p, expl, Spacer(10), row, Spacer(4), lblOutStatus, Spacer(14), modeHdr, Spacer(4), rbCopy, rbMove, Spacer(4), lblModeHint);
        }

        void BuildPage3()
        {
            Panel p = pages[2] = NewPage();
            Label expl = Note("Tick the languages you want. The program works out each file's language from its name: an explicit language tag " +
                "such as (de) or (JP)(en) is used as written; otherwise a country tag counts as that country's official language " +
                "(for example (DE) is German; EU and AS count as English); a file with neither tag is English, as the TOSEC convention says. " +
                "A fan translation [tr xx] counts as language xx instead of the original, unless it is marked partial. " +
                "A file is kept if it has at least one language you tick; files with a multi-language tag such as (M3) are always kept.\r\n\r\n" +
                "When several versions of a game remain, English is preferred, then Greek, then the other languages you ticked.");
            FlowLayoutPanel btns = new FlowLayoutPanel(); btns.Dock = DockStyle.Top; btns.Height = 36;
            Button all = new Button(); all.Text = "Tick all"; all.Width = 90; all.FlatStyle = FlatStyle.System;
            Button none = new Button(); none.Text = "Clear all"; none.Width = 90; none.FlatStyle = FlatStyle.System;
            btns.Controls.Add(all); btns.Controls.Add(none);
            all.Click += delegate { SetAllLanguages(true); };
            none.Click += delegate { SetAllLanguages(false); };

            clbLang = new CheckedListBox(); clbLang.Dock = DockStyle.Fill; clbLang.CheckOnClick = true; clbLang.IntegralHeight = false;
            List<LangItem> items = new List<LangItem>();
            foreach (KeyValuePair<string, string> kv in Tosec.LangNames)
            {
                LangItem li = new LangItem(); li.Code = kv.Key; li.Name = kv.Value; items.Add(li);
            }
            items.Sort(delegate (LangItem a, LangItem b) { return string.Compare(a.Name, b.Name, StringComparison.Ordinal); });
            AddLang(items, "en", true); AddLang(items, "el", true);
            foreach (LangItem li in items) clbLang.Items.Add(li, false);
            clbLang.ItemCheck += delegate { BeginInvoke(new MethodInvoker(UpdateNav)); };
            Stack(p, expl, Spacer(6), btns, clbLang);
        }

        void AddLang(List<LangItem> items, string code, bool chk)
        {
            for (int i = 0; i < items.Count; i++)
                if (items[i].Code == code) { clbLang.Items.Add(items[i], chk); items.RemoveAt(i); return; }
        }

        void BuildPage4()
        {
            Panel p = pages[3] = NewPage();
            Label expl = Note("Some images are damaged. Ticked kinds are removed before anything else, so a game that exists only as a damaged " +
                "dump will not appear in the result. Untick a kind to let it stay in the running; it is then used only when nothing better exists.");
            cbBad = AddOption(p, "Leave out bad dumps [b]", "The image is damaged or incorrect and probably does not work.", true);
            cbOver = AddOption(p, "Leave out over dumps [o]", "The image holds duplicated or surplus data.", true);
            cbUnder = AddOption(p, "Leave out under dumps [u]", "The image is missing data.", true);
            cbVirus = AddOption(p, "Leave out virus-infected images [v]", "The image was infected by a virus.", true);
            Label note = Muted("Verified dumps [!] are always preferred when everything else is equal.");
            Stack(p, Spacer(2), note);
            // explanation goes on top
            p.Controls.Add(expl); expl.BringToFront(); MoveToTop(p, expl);
        }

        void BuildPage5()
        {
            Panel p = pages[4] = NewPage();
            Label expl = Note("These flags mark files that were altered after the original release. Ticked kinds are removed before anything else. " +
                "Unticked kinds stay in the running, but an unmodified original always beats a modified version of the same game. " +
                "(Fan translations are handled by the language step.)");
            cbCr = AddOption(p, "Leave out cracked files [cr]", "Copy protection was removed.", true);
            cbHack = AddOption(p, "Leave out hacked files [h]", "The game was altered, for example with a new intro or changed graphics.", true);
            cbTrain = AddOption(p, "Leave out trained files [t]", "Cheats or a cheat menu were added.", true);
            cbFix = AddOption(p, "Leave out fixed files [f]", "Altered to work in a non-standard way, for example PAL fixed for NTSC. Often useful, so kept by default.", false);
            cbMod = AddOption(p, "Leave out modified files [m]", "Changed by accident, for example a saved game or high score written to the disk.", false);
            cbPir = AddOption(p, "Leave out pirated files [p]", "Not legally licensed.", false);
            MoveToTop(p, expl);
        }

        void BuildPage6()
        {
            Panel p = pages[5] = NewPage();
            Label expl = Note("Demos and unfinished builds are not the full game. Ticked kinds are removed before anything else. Unticked kinds stay in the " +
                "running, but any finished version of the same game always beats them.");
            cbDemo = AddOption(p, "Leave out demos", "Demonstration, promotional or sample versions (all demo types).", true);
            cbProto = AddOption(p, "Leave out prototypes (proto)", "Unreleased prototype software.", true);
            cbAlpha = AddOption(p, "Leave out alpha builds (alpha)", "Early test builds.", true);
            cbBeta = AddOption(p, "Leave out beta builds (beta)", "Later, feature-complete test builds.", true);
            cbPrev = AddOption(p, "Leave out previews and pre-releases (preview, pre-release)", "Near-complete builds released before the final version.", true);
            MoveToTop(p, expl);
        }

        void BuildPage7()
        {
            Panel p = pages[6] = NewPage();
            Label expl = Note("Optionally keep only software released within a range of years. Use one side or both: tick \"From\" to ignore anything older, " +
                "tick \"To\" to ignore anything newer. A date such as 199x counts as the whole decade (1990 to 1999) and is kept if any part of it falls in " +
                "your range. Dates written 19xx or 20xx are unknown. With nothing ticked, every year is accepted.");
            FlowLayoutPanel fl = new FlowLayoutPanel(); fl.Dock = DockStyle.Top; fl.Height = 40; fl.WrapContents = false;
            cbFrom = new CheckBox(); cbFrom.Text = "From year"; cbFrom.AutoSize = true; cbFrom.Margin = new Padding(0, 6, 4, 0);
            nudFrom = new NumericUpDown(); nudFrom.Minimum = 1950; nudFrom.Maximum = 2099; nudFrom.Value = 1980; nudFrom.Width = 70; nudFrom.Enabled = false;
            cbTo = new CheckBox(); cbTo.Text = "To year"; cbTo.AutoSize = true; cbTo.Margin = new Padding(28, 6, 4, 0);
            nudTo = new NumericUpDown(); nudTo.Minimum = 1950; nudTo.Maximum = 2099; nudTo.Value = 1999; nudTo.Width = 70; nudTo.Enabled = false;
            fl.Controls.Add(cbFrom); fl.Controls.Add(nudFrom); fl.Controls.Add(cbTo); fl.Controls.Add(nudTo);
            cbUnknownDate = new CheckBox(); cbUnknownDate.Text = "Keep files whose date is unknown (19xx, 20xx)"; cbUnknownDate.Checked = true;
            cbUnknownDate.AutoSize = false; cbUnknownDate.Dock = DockStyle.Top; cbUnknownDate.Height = 26; cbUnknownDate.Enabled = false;
            Label d = Muted("Only matters when a year limit is ticked above."); d.Padding = new Padding(22, 0, 0, 0);
            cbFrom.CheckedChanged += delegate { nudFrom.Enabled = cbFrom.Checked; cbUnknownDate.Enabled = cbFrom.Checked || cbTo.Checked; UpdateNav(); };
            cbTo.CheckedChanged += delegate { nudTo.Enabled = cbTo.Checked; cbUnknownDate.Enabled = cbFrom.Checked || cbTo.Checked; UpdateNav(); };
            nudFrom.ValueChanged += delegate { UpdateNav(); };
            nudTo.ValueChanged += delegate { UpdateNav(); };
            lblDateWarn = Note(""); lblDateWarn.ForeColor = Bad;
            Stack(p, expl, Spacer(8), fl, Spacer(4), cbUnknownDate, d, Spacer(6), lblDateWarn);
        }

        void BuildPage8()
        {
            Panel p = pages[7] = NewPage();
            Label expl = Note("Check your choices, then press Run. For every game the program keeps the single best version; the rules are listed below the settings.");
            txtSummary = new TextBox(); txtSummary.Multiline = true; txtSummary.ReadOnly = true; txtSummary.ScrollBars = ScrollBars.Vertical;
            txtSummary.Dock = DockStyle.Fill; txtSummary.BackColor = SystemColors.Window;
            txtSummary.Font = new Font("Consolas", 9f);
            bar = new ProgressBar(); bar.Dock = DockStyle.Bottom; bar.Height = 22; bar.Minimum = 0; bar.Maximum = 100;
            lblStatus = Note(""); lblStatus.Dock = DockStyle.Bottom; lblStatus.AutoSize = false;
            FlowLayoutPanel btns = new FlowLayoutPanel(); btns.Dock = DockStyle.Bottom; btns.Height = 38;
            btnSaveLog = new Button(); btnSaveLog.Text = "Save log..."; btnSaveLog.Width = 120; btnSaveLog.FlatStyle = FlatStyle.System; btnSaveLog.Visible = false;
            btnOpenOut = new Button(); btnOpenOut.Text = "Open output folder"; btnOpenOut.Width = 150; btnOpenOut.FlatStyle = FlatStyle.System; btnOpenOut.Visible = false;
            btns.Controls.Add(btnSaveLog); btns.Controls.Add(btnOpenOut);
            btnSaveLog.Click += delegate { SaveLog(); };
            btnOpenOut.Click += delegate { try { Process.Start(txtOut.Text); } catch (Exception) { } };
            Stack(p, expl, Spacer(6), bar, lblStatus, btns, txtSummary);
            bar.Dock = DockStyle.Bottom;
        }

        // Dock-order helpers for pages that were filled before their explanation label was created.
        static void MoveToTop(Panel p, Label l)
        {
            // Controls are docked from the highest index to the lowest, so the first thing to dock
            // (the top-most) must have the highest index.
            if (!p.Controls.Contains(l)) p.Controls.Add(l);
            p.Controls.SetChildIndex(l, p.Controls.Count - 1);
        }

        static void MoveAbove(Panel p, Control c, Control below)
        {
            int idx = p.Controls.GetChildIndex(below);
            if (!p.Controls.Contains(c)) p.Controls.Add(c);
            p.Controls.SetChildIndex(c, idx + 1);
        }

        // ============================================================
        // navigation
        // ============================================================
        void ShowPage(int i)
        {
            cur = i;
            for (int k = 0; k < PageCount; k++) pages[k].Visible = (k == i);
            lblStep.Text = "Step " + (i + 1) + " of " + PageCount;
            lblTitle.Text = titles[i];
            if (i == PageCount - 1) PreparePlan();
            UpdateNav();
        }

        void UpdateNav()
        {
            bool last = cur == PageCount - 1;
            btnBack.Enabled = cur > 0 && !running && !finished;
            btnNext.Text = finished ? "Close" : (last ? "Run" : "Next >");
            btnCancel.Text = running ? "Stop" : "Cancel";
            btnCancel.Visible = !finished;
            if (running) btnNext.Enabled = false;
            else if (finished) btnNext.Enabled = true;
            else btnNext.Enabled = PageValid(cur);
        }

        bool PageValid(int i)
        {
            switch (i)
            {
                case 0: return scan != null && scan.Valid.Count > 0;
                case 1: return outOk;
                case 2: return clbLang.CheckedItems.Count > 0;
                case 6:
                    {
                        bool bad = cbFrom.Checked && cbTo.Checked && nudFrom.Value > nudTo.Value;
                        lblDateWarn.Text = bad ? "The \"From\" year is later than the \"To\" year." : "";
                        return !bad;
                    }
                case 7: return plan != null && plan.Chosen.Count > 0;
                default: return true;
            }
        }

        void GoBack() { if (cur > 0 && !running && !finished) ShowPage(cur - 1); }

        void GoNext()
        {
            if (finished) { Close(); return; }
            if (cur == 0 && !Directory.Exists(txtIn.Text)) { MessageBox.Show(this, "The input folder no longer exists.", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            if (cur == 1) { CheckOutput(); if (!outOk) return; }
            if (cur < PageCount - 1) { ShowPage(cur + 1); return; }
            StartRun();
        }

        void OnCancel()
        {
            if (running) { worker.CancelAsync(); lblStatus.Text = "Stopping after the current file..."; btnCancel.Enabled = false; }
            else Close();
        }

        void OnFormClosing(object sender, FormClosingEventArgs e)
        {
            if (!running) return;
            DialogResult r = MessageBox.Show(this, "A transfer is still running. Stop it and close the program?", Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
            e.Cancel = true;
            if (r == DialogResult.Yes) { closeWhenDone = true; worker.CancelAsync(); }
        }

        // ============================================================
        // page 1 and 2 actions
        // ============================================================
        void BrowseInput()
        {
            using (FolderBrowserDialog d = new FolderBrowserDialog())
            {
                d.Description = "Choose the folder with your TOSEC-named files";
                d.ShowNewFolderButton = false;
                if (Directory.Exists(txtIn.Text)) d.SelectedPath = txtIn.Text;
                if (d.ShowDialog(this) != DialogResult.OK) return;
                txtIn.Text = d.SelectedPath;
            }
            ScanInput();
        }

        void ScanInput()
        {
            scan = null;
            Cursor = Cursors.WaitCursor;
            try
            {
                scan = Tosec.Scan(txtIn.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "The folder could not be read:\r\n" + ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            finally { Cursor = Cursors.Default; }

            if (scan == null) { lblScan.Text = ""; txtIgnored.Visible = lblIgnoredHdr.Visible = false; UpdateNav(); return; }

            int ign = scan.BadName.Count + scan.SubFolders.Count;
            StringBuilder sb = new StringBuilder();
            sb.Append(scan.Valid.Count.ToString("N0")).Append(" valid TOSEC file(s) found.");
            if (ign > 0)
                sb.Append("\r\nIgnored: ").Append(scan.BadName.Count.ToString("N0")).Append(" not TOSEC-named, ")
                  .Append(scan.SubFolders.Count.ToString("N0")).Append(" subfolder(s).");
            if (scan.Valid.Count == 0) sb.Append("\r\nNothing usable here - please choose another folder.");
            lblScan.Text = sb.ToString();
            lblScan.ForeColor = scan.Valid.Count == 0 ? Bad : Good;

            StringBuilder ig = new StringBuilder();
            int shown = 0;
            foreach (string n in scan.SubFolders) { if (shown++ < 500) ig.Append("[subfolder]   ").Append(n).Append("\r\n"); }
            foreach (string n in scan.BadName) { if (shown++ < 500) ig.Append("[not TOSEC]   ").Append(n).Append("\r\n"); }
            if (ign > 500) ig.Append("... and ").Append(ign - 500).Append(" more.\r\n");
            txtIgnored.Text = ig.ToString();
            txtIgnored.Visible = lblIgnoredHdr.Visible = ign > 0;
            UpdateModeHint();
            UpdateNav();
        }

        void BrowseOutput()
        {
            using (FolderBrowserDialog d = new FolderBrowserDialog())
            {
                d.Description = "Choose an EMPTY folder for the result (use Make New Folder to create one)";
                d.ShowNewFolderButton = true;
                if (Directory.Exists(txtOut.Text)) d.SelectedPath = txtOut.Text;
                if (d.ShowDialog(this) != DialogResult.OK) return;
                txtOut.Text = d.SelectedPath;
            }
            CheckOutput();
        }

        void CheckOutput()
        {
            outOk = false;
            string path = txtOut.Text;
            if (path.Length == 0) { lblOutStatus.Text = "No folder chosen yet."; lblOutStatus.ForeColor = Color.DimGray; }
            else if (!Directory.Exists(path)) { lblOutStatus.Text = "This folder does not exist."; lblOutStatus.ForeColor = Bad; }
            else
            {
                int n = 0;
                try { n = Directory.GetFileSystemEntries(path).Length; }
                catch (Exception ex) { lblOutStatus.Text = "The folder cannot be read: " + ex.Message; lblOutStatus.ForeColor = Bad; n = -1; }
                if (n > 0) { lblOutStatus.Text = "This folder is not empty (" + n + " item(s)). Choose an empty folder, or make a new one."; lblOutStatus.ForeColor = Bad; }
                else if (n == 0) { lblOutStatus.Text = "The folder is empty - good."; lblOutStatus.ForeColor = Good; outOk = true; }
            }
            UpdateModeHint();
            UpdateNav();
        }

        void UpdateModeHint()
        {
            if (lblModeHint == null) return;
            if (txtIn.Text.Length == 0 || !outOk)
            {
                lblModeHint.Text = "Choose an empty output folder first; this shows whether Move is possible.";
                rbMove.Enabled = false; rbCopy.Checked = true;
                return;
            }
            bool same = FileOps.SameVolume(txtIn.Text, txtOut.Text);
            rbMove.Enabled = same;
            if (same) lblModeHint.Text = "Both folders are on the same drive: a move is instant and the files are not rewritten - the gentlest option for an old mechanical disk.";
            else
            {
                rbCopy.Checked = true;
                lblModeHint.Text = "The folders are on different drives, so Move is not available: it would have to copy every file and then remove the original, " +
                    "which is no faster than Copy. This program never deletes files. Choose an output folder on the same drive as the input to enable Move.";
            }
        }

        void SetAllLanguages(bool on)
        {
            for (int i = 0; i < clbLang.Items.Count; i++) clbLang.SetItemChecked(i, on);
            UpdateNav();
        }

        // ============================================================
        // page 8: plan, run, log
        // ============================================================
        Options ReadOptions()
        {
            Options o = new Options();
            foreach (object it in clbLang.CheckedItems) o.Languages.Add(((LangItem)it).Code);
            o.ExclBad = cbBad.Checked; o.ExclOver = cbOver.Checked; o.ExclUnder = cbUnder.Checked; o.ExclVirus = cbVirus.Checked;
            o.ExclCracked = cbCr.Checked; o.ExclHacked = cbHack.Checked; o.ExclTrained = cbTrain.Checked;
            o.ExclFixed = cbFix.Checked; o.ExclModified = cbMod.Checked; o.ExclPirated = cbPir.Checked;
            o.ExclDemo = cbDemo.Checked; o.ExclProto = cbProto.Checked; o.ExclAlpha = cbAlpha.Checked;
            o.ExclBeta = cbBeta.Checked; o.ExclPreview = cbPrev.Checked;
            o.FromYear = cbFrom.Checked ? (int)nudFrom.Value : 0;
            o.ToYear = cbTo.Checked ? (int)nudTo.Value : 0;
            o.KeepUnknownDate = cbUnknownDate.Checked;
            return o;
        }

        static string Join(List<string> l, string none)
        {
            return l.Count == 0 ? none : string.Join(", ", l.ToArray());
        }

        string BuildSettings()
        {
            StringBuilder b = new StringBuilder();
            string nl = "\r\n";
            moveMode = rbMove.Checked;
            b.Append("SETTINGS").Append(nl);
            b.Append("  Input folder  : ").Append(txtIn.Text).Append(nl);
            b.Append("  Output folder : ").Append(txtOut.Text).Append(nl);
            b.Append("  Mode          : ").Append(moveMode ? "MOVE (files leave the input folder)" : "Copy (originals stay)").Append(nl);

            List<string> langs = new List<string>();
            foreach (object it in clbLang.CheckedItems) langs.Add(((LangItem)it).Name);
            b.Append("  Languages     : ").Append(Join(langs, "-")).Append(nl);

            List<string> left = new List<string>();
            if (opts.ExclBad) left.Add("bad dumps"); if (opts.ExclOver) left.Add("over dumps");
            if (opts.ExclUnder) left.Add("under dumps"); if (opts.ExclVirus) left.Add("virus-infected");
            if (opts.ExclCracked) left.Add("cracked"); if (opts.ExclHacked) left.Add("hacked");
            if (opts.ExclTrained) left.Add("trained"); if (opts.ExclFixed) left.Add("fixed");
            if (opts.ExclModified) left.Add("modified"); if (opts.ExclPirated) left.Add("pirated");
            if (opts.ExclDemo) left.Add("demos"); if (opts.ExclProto) left.Add("prototypes");
            if (opts.ExclAlpha) left.Add("alpha"); if (opts.ExclBeta) left.Add("beta");
            if (opts.ExclPreview) left.Add("previews / pre-releases");
            b.Append("  Left out      : ").Append(Join(left, "nothing")).Append(nl);

            if (opts.FromYear > 0 || opts.ToYear > 0)
                b.Append("  Release years : ").Append(opts.FromYear > 0 ? "from " + opts.FromYear : "any start")
                 .Append(opts.ToYear > 0 ? " to " + opts.ToYear : " with no end")
                 .Append(opts.KeepUnknownDate ? " (unknown dates kept)" : " (unknown dates left out)").Append(nl);
            else b.Append("  Release years : any").Append(nl);
            return b.ToString();
        }

        void PreparePlan()
        {
            if (running || finished) return;
            opts = ReadOptions();
            Cursor = Cursors.WaitCursor;
            try { plan = Selector.Select(scan.Valid, opts); }
            finally { Cursor = Cursors.Default; }
            settingsText = BuildSettings();

            StringBuilder b = new StringBuilder();
            string nl = "\r\n";
            b.Append(settingsText).Append(nl);
            b.Append("PREVIEW").Append(nl);
            b.Append("  Valid TOSEC files read             : ").Append(plan.ValidFiles.ToString("N0")).Append(nl);
            b.Append("  Left out by your filters           : ").Append(plan.Excluded.ToString("N0")).Append(nl);
            b.Append("  Different games found              : ").Append(plan.Games.ToString("N0")).Append(nl);
            b.Append("  Not chosen (a better version kept) : ").Append(plan.NotChosen.ToString("N0")).Append(nl);
            b.Append("  Files that will be ").Append(moveMode ? "MOVED" : "copied").Append("            : ").Append(plan.Chosen.Count.ToString("N0")).Append(nl);
            if (plan.WarningLines.Count > 0)
                b.Append("  Games kept only as a less desirable version or incomplete set: ").Append(plan.WarningLines.Count).Append(" (listed in the log)").Append(nl);
            if (plan.Chosen.Count == 0) b.Append(nl).Append("  Nothing would be transferred. Go back and relax some filters.").Append(nl);
            b.Append(nl);
            b.Append("HOW ONE VERSION OF EACH GAME IS CHOSEN").Append(nl);
            b.Append("  Files with the same title are the same game (version, date, publisher and machine model are ignored).").Append(nl);
            b.Append("  After your filters, the best remaining file wins, in this order:").Append(nl);
            b.Append("   0. Intact images beat damaged ones (only matters if you allowed damaged dumps).").Append(nl);
            b.Append("   1. Completeness: commercial, licenceware, registered shareware, registered cardware/giftware,").Append(nl);
            b.Append("      public domain / freeware, cardware/giftware, shareware. Demos and pre-releases come last.").Append(nl);
            b.Append("   2. Originality: an unmodified release beats an alternate [a], which beats a modified one.").Append(nl);
            b.Append("   3. Language: English and Greek, then English, then Greek, then any other language you ticked.").Append(nl);
            b.Append("   4. Newest version, then verified dumps [!].").Append(nl);
            b.Append("   5. Alphabetical order, only to break a final tie.").Append(nl);
            b.Append("  Multi-part games (Disk 1 of 2 ...) are kept together as a set: the best first part is chosen, and each other").Append(nl);
            b.Append("  part comes from the same release when it exists. A complete set beats an incomplete one.").Append(nl);
            b.Append("  Files are never renamed, changed, extracted or overwritten.").Append(nl);
            txtSummary.Text = b.ToString();
            txtSummary.SelectionStart = 0; txtSummary.SelectionLength = 0;
            lblStatus.Text = "";
            bar.Value = 0;
        }

        void StartRun()
        {
            if (plan == null || plan.Chosen.Count == 0) return;
            if (!Directory.Exists(txtOut.Text) || Directory.GetFileSystemEntries(txtOut.Text).Length > 0)
            {
                MessageBox.Show(this, "The output folder is no longer an empty folder. Please go back and choose another one.", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (moveMode)
            {
                DialogResult r = MessageBox.Show(this,
                    plan.Chosen.Count.ToString("N0") + " file(s) will be MOVED out of:\r\n\r\n" + txtIn.Text + "\r\n\r\ninto:\r\n\r\n" + txtOut.Text +
                    "\r\n\r\nThey will no longer be in the input folder afterwards. Continue?",
                    "Confirm move", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
                if (r != DialogResult.Yes) return;
            }
            running = true;
            RunArgs a = new RunArgs(); a.Files = plan.Chosen; a.OutDir = txtOut.Text; a.Move = moveMode;
            bar.Value = 0;
            lblStatus.Text = "Starting...";
            UpdateNav();
            worker.RunWorkerAsync(a);
        }

        void WorkerDoWork(object sender, DoWorkEventArgs e)
        {
            RunArgs a = (RunArgs)e.Argument;
            RunResult r = new RunResult();
            Stopwatch sw = Stopwatch.StartNew();
            long nextReport = 0;
            for (int i = 0; i < a.Files.Count; i++)
            {
                if (worker.CancellationPending) { r.Cancelled = true; break; }
                TosecFile f = a.Files[i];
                if (sw.ElapsedMilliseconds >= nextReport)
                {
                    worker.ReportProgress((int)(i * 100L / a.Files.Count), (i + 1) + " / " + a.Files.Count + "   " + f.FileName);
                    nextReport = sw.ElapsedMilliseconds + 80;
                }
                string err = FileOps.Transfer(f.FullPath, a.OutDir, a.Move);
                if (err == null) r.Done++; else r.Errors.Add(f.FileName + "  :  " + err);
            }
            e.Result = r;
        }

        void WorkerProgress(object sender, ProgressChangedEventArgs e)
        {
            bar.Value = Math.Min(100, Math.Max(0, e.ProgressPercentage));
            lblStatus.Text = (string)e.UserState;
        }

        void WorkerDone(object sender, RunWorkerCompletedEventArgs e)
        {
            running = false; finished = true;
            if (e.Error != null)
            {
                lblStatus.Text = "Stopped by an unexpected error: " + e.Error.Message;
                lblStatus.ForeColor = Bad;
                logText = settingsText + "\r\nUNEXPECTED ERROR: " + e.Error.Message + "\r\n";
            }
            else
            {
                RunResult r = (RunResult)e.Result;
                bar.Value = r.Cancelled ? bar.Value : 100;
                string verb = moveMode ? "moved" : "copied";
                lblStatus.Text = (r.Cancelled ? "Stopped. " : "Done. ") + r.Done.ToString("N0") + " file(s) " + verb + ", " + r.Errors.Count + " problem(s). Save the log for the full details.";
                lblStatus.ForeColor = r.Errors.Count == 0 && !r.Cancelled ? Good : Bad;
                logText = Report.BuildLog(settingsText, plan, moveMode, r.Done, r.Cancelled, r.Errors);
            }
            btnSaveLog.Visible = btnOpenOut.Visible = true;
            btnCancel.Enabled = true;
            UpdateNav();
            if (closeWhenDone) Close();
        }

        void SaveLog()
        {
            using (SaveFileDialog d = new SaveFileDialog())
            {
                d.Title = "Save the log";
                d.Filter = "Text file (*.txt)|*.txt";
                d.FileName = "Tosec1G1R-log.txt";
                d.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                if (d.ShowDialog(this) != DialogResult.OK) return;
                try { File.WriteAllText(d.FileName, logText, new UTF8Encoding(true)); }
                catch (Exception ex) { MessageBox.Show(this, "The log could not be saved:\r\n" + ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning); }
            }
        }
    }
}
