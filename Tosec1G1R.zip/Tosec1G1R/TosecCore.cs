using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;

// TOSEC 1G1R Filter - selection engine (no user interface in this file).
// Plain C# 5, no extra libraries.

namespace Tosec1G1R
{
    // ------------------------------------------------------------------
    // Parsed information about one file name
    // ------------------------------------------------------------------
    public class PartInfo
    {
        public int Start, End, Total;      // which part(s) of how many (Total 0 = unknown)
        public string Side = "";           // "A", "B" ... when a tape/disk side is named
        public string Key = "";            // unique position inside the set, e.g. "1", "2B", "1-2"
    }

    public class TosecFile
    {
        public string FileName = "", FullPath = "";
        public string Title = "", TitleKey = "", Version = "";
        public string Date = "";
        public int YearFrom, YearTo;                    // 0/0 = unknown
        public string Copyright = "";                   // "", PD, FW, SW, SW-R, CW, CW-R, GW, GW-R, LW
        public bool Demo, Alpha, Beta, Preview, Proto;
        public HashSet<string> Langs = new HashSet<string>();
        public bool MultiLang;                          // (M3) style tag: languages not listed
        public bool Cracked, Fixed, Hacked, Modified, Pirated, Trained, Translated;
        public bool Over, Under, Virus, Bad, Alternate, Verified;
        public PartInfo Part;                           // null = not a multi-part file
        public int CopyrightRank;                       // 0 = most complete

        public bool Incomplete
        {
            get { return Demo || Alpha || Beta || Preview || Proto; }
        }

        // 0 = clean original, 1 = alternate original [a], 2 = modified in some way
        public int OriginalityTier
        {
            get
            {
                if (Cracked || Fixed || Hacked || Modified || Pirated || Trained || Translated) return 2;
                return Alternate ? 1 : 0;
            }
        }

        public int DamageCount
        {
            get { return (Bad ? 1 : 0) + (Over ? 1 : 0) + (Under ? 1 : 0) + (Virus ? 1 : 0); }
        }

        public string LangKey()
        {
            List<string> l = new List<string>(Langs);
            l.Sort(StringComparer.Ordinal);
            return string.Join(",", l.ToArray());
        }
    }

    // ------------------------------------------------------------------
    // Reference data and the file name parser
    // ------------------------------------------------------------------
    public static class Tosec
    {

        public static readonly Dictionary<string, string> LangNames = new Dictionary<string, string>();
        public static readonly Dictionary<string, string[]> CountryLangs = new Dictionary<string, string[]>();

        static readonly Regex GroupRx = new Regex(@"\(([^()]*)\)|\[([^\[\]]*)\]", RegexOptions.Compiled);
        static readonly Regex DateRx = new Regex(@"^[12][0-9][0-9x]{2}(?:-[0-9]{2}(?:-[0-9x]{2})?)?$", RegexOptions.Compiled);
        static readonly Regex DemoRx = new Regex(@"^demo(?:-(?:kiosk|playable|rolling|slideshow))?$", RegexOptions.Compiled);
        static readonly Regex MediaRx = new Regex(@"^(Disc|Disk|File|Part|Side|Tape)\s+(\d+)(?:-(\d+))?\s+of\s+(\d+)(?:\s+Side\s+([A-Za-z]))?$", RegexOptions.Compiled);
        static readonly Regex SideRx = new Regex(@"^Side\s+([A-Za-z])$", RegexOptions.Compiled);
        static readonly Regex MultiRx = new Regex(@"^M\d+$", RegexOptions.Compiled);
        static readonly Regex FlagRx = new Regex(@"^(tr|cr|f|h|m|p|t|o|u|v|b|a)(\d*)(?:\s+(.*))?$", RegexOptions.Compiled);
        static readonly Regex TrLangRx = new Regex(@"^([a-z]{2}(?:-(?:partial|[a-z]{2}))*)(?:\s|$)", RegexOptions.Compiled);
        static readonly Regex VersionRx = new Regex(@"^(.*?)\s+(v\s?\d\S*|Rev\s+\S+)$", RegexOptions.Compiled);
        static readonly Regex SpacesRx = new Regex(@"\s+", RegexOptions.Compiled);

        static Tosec()
        {
            string[] langs = {
                "ar|Arabic","bg|Bulgarian","bs|Bosnian","cs|Czech","cy|Welsh","da|Danish","de|German","el|Greek",
                "en|English","eo|Esperanto","es|Spanish","et|Estonian","fa|Persian","fi|Finnish","fr|French",
                "ga|Irish","gu|Gujarati","he|Hebrew","hi|Hindi","hr|Croatian","hu|Hungarian","is|Icelandic",
                "it|Italian","ja|Japanese","ko|Korean","lt|Lithuanian","lv|Latvian","ms|Malay","nl|Dutch",
                "no|Norwegian","pl|Polish","pt|Portuguese","ro|Romanian","ru|Russian","sk|Slovak","sl|Slovenian",
                "sq|Albanian","sr|Serbian","sv|Swedish","th|Thai","tr|Turkish","ur|Urdu","vi|Vietnamese",
                "yi|Yiddish","zh|Chinese",
                "id|Indonesian","mn|Mongolian","ne|Nepali"   // only reachable through country tags
            };
            foreach (string s in langs)
            {
                string[] p = s.Split('|');
                LangNames[p[0]] = p[1];
            }

            string[] ctry = {
                "AE:ar","AL:sq","AS:en","AT:de","AU:en","BA:bs,hr,sr","BE:nl,fr,de","BG:bg","BR:pt","CA:en,fr",
                "CH:de,fr,it","CL:es","CN:zh","CS:sr","CY:el,tr","CZ:cs","DE:de","DK:da","EE:et","EG:ar","ES:es",
                "EU:en","FI:fi,sv","FR:fr","GB:en","GR:el","HK:zh,en","HR:hr","HU:hu","ID:id","IE:en,ga","IL:he",
                "IN:hi,en","IR:fa","IS:is","IT:it","JO:ar","JP:ja","KR:ko","LT:lt","LU:fr,de","LV:lv","MN:mn",
                "MX:es","MY:ms","NL:nl","NO:no","NP:ne","NZ:en","OM:ar","PE:es","PH:en","PL:pl","PT:pt","QA:ar",
                "RO:ro","RU:ru","SE:sv","SG:en,zh,ms","SI:sl","SK:sk","TH:th","TR:tr","TW:zh","US:en","VN:vi",
                "YU:sr","ZA:en"
            };
            foreach (string s in ctry)
            {
                string[] p = s.Split(':');
                CountryLangs[p[0]] = p[1].Split(',');
            }
        }

        public static int CopyrightRankOf(string c)
        {
            switch (c)
            {
                case "LW": return 1;
                case "SW-R": return 2;
                case "CW-R": case "GW-R": return 3;
                case "PD": case "FW": return 4;
                case "CW": case "GW": return 5;
                case "SW": return 6;
                default: return 0;          // no flag = commercial release
            }
        }

        static bool IsCopyright(string g)
        {
            switch (g)
            {
                case "CW": case "CW-R": case "FW": case "GW": case "GW-R": case "LW": case "PD": case "SW": case "SW-R": return true;
                default: return false;
            }
        }

        // A TOSEC name ends with ")" or "]". Whatever follows (".zip", ".dsk", ".tar.gz", or nothing at all)
        // is the file extension, which this program does not care about. Returns false when the name
        // does not end like a TOSEC name.
        public static bool SplitName(string name, out string stem)
        {
            int i = Math.Max(name.LastIndexOf(')'), name.LastIndexOf(']'));
            if (i < 0) { stem = name; return false; }
            stem = name.Substring(0, i + 1);
            string rest = name.Substring(i + 1);
            return rest.Length == 0 || rest[0] == '.';
        }

        // Returns null when the name does not follow the TOSEC convention
        // (at least "Title (date)(publisher)"). Any file extension is accepted.
        public static TosecFile Parse(string fileName, string fullPath)
        {
            string stem;
            if (!SplitName(fileName, out stem)) return null;
            return ParseStem(stem, fileName, fullPath);
        }

        public static TosecFile ParseStem(string stem, string fileName, string fullPath)
        {
            TosecFile f = new TosecFile();
            f.FileName = fileName;
            f.FullPath = fullPath;

            bool afterDate = false, hasDatePub = false;
            int dateCount = 0;
            HashSet<string> explicitLangs = new HashSet<string>();
            HashSet<string> countryLangs = new HashSet<string>();
            HashSet<string> transLangs = new HashSet<string>();
            bool hasCountry = false;

            foreach (Match m in GroupRx.Matches(stem))
            {
                if (m.Groups[1].Success)
                {
                    string g = m.Groups[1].Value.Trim();
                    if (afterDate) { afterDate = false; hasDatePub = true; continue; }   // publisher
                    if (DateRx.IsMatch(g))
                    {
                        dateCount++;
                        afterDate = true;
                        if (f.Date.Length == 0) SetDate(f, g);
                        continue;
                    }
                    if (DemoRx.IsMatch(g)) { f.Demo = true; continue; }
                    if (IsCopyright(g))
                    {
                        if (CopyrightRankOf(g) > f.CopyrightRank || f.Copyright.Length == 0)
                        {
                            f.Copyright = g;
                            f.CopyrightRank = CopyrightRankOf(g);
                        }
                        continue;
                    }
                    switch (g)
                    {
                        case "alpha": f.Alpha = true; continue;
                        case "beta": f.Beta = true; continue;
                        case "preview": case "pre-release": f.Preview = true; continue;
                        case "proto": f.Proto = true; continue;
                    }
                    Match mm = MediaRx.Match(g);
                    if (mm.Success)
                    {
                        PartInfo pi = new PartInfo();
                        pi.Start = int.Parse(mm.Groups[2].Value);
                        pi.End = mm.Groups[3].Success ? int.Parse(mm.Groups[3].Value) : pi.Start;
                        pi.Total = int.Parse(mm.Groups[4].Value);
                        if (mm.Groups[5].Success) pi.Side = mm.Groups[5].Value.ToUpperInvariant();
                        pi.Key = pi.Start.ToString() + (pi.End > pi.Start ? "-" + pi.End : "") + pi.Side;
                        if (f.Part == null) f.Part = pi;
                        continue;
                    }
                    mm = SideRx.Match(g);
                    if (mm.Success)
                    {
                        PartInfo pi = new PartInfo();
                        string sd = mm.Groups[1].Value.ToUpperInvariant();
                        pi.Start = pi.End = (sd[0] - 'A') + 1;
                        pi.Total = 0;
                        pi.Key = pi.Start.ToString();
                        if (f.Part == null) f.Part = pi;
                        continue;
                    }
                    if (MultiRx.IsMatch(g)) { f.MultiLang = true; continue; }
                    if (IsCodeList(g, true))
                    {
                        hasCountry = true;
                        foreach (string c in g.Split('-'))
                            foreach (string l in CountryLangs[c.Trim()]) countryLangs.Add(l);
                        continue;
                    }
                    if (IsCodeList(g, false))
                    {
                        foreach (string l in g.Split('-')) explicitLangs.Add(l.Trim());
                        continue;
                    }
                    // anything else (system, video, media label, ...) is not needed here
                }
                else
                {
                    afterDate = false;
                    string g = m.Groups[2].Value.Trim();
                    if (g == "!") { f.Verified = true; continue; }
                    Match fm = FlagRx.Match(g);
                    if (!fm.Success) continue;                  // "more info" flag
                    string rest = fm.Groups[3].Success ? fm.Groups[3].Value.Trim() : "";
                    switch (fm.Groups[1].Value)
                    {
                        case "cr": f.Cracked = true; break;
                        case "f": f.Fixed = true; break;
                        case "h": f.Hacked = true; break;
                        case "m": f.Modified = true; break;
                        case "p": f.Pirated = true; break;
                        case "t": f.Trained = true; break;
                        case "o": f.Over = true; break;
                        case "u": f.Under = true; break;
                        case "v": f.Virus = true; break;
                        case "b": f.Bad = true; break;
                        case "a": f.Alternate = true; break;
                        case "tr":
                            f.Translated = true;
                            Match tm = TrLangRx.Match(rest);
                            if (tm.Success)
                            {
                                string[] parts = tm.Groups[1].Value.Split('-');
                                for (int i = 0; i < parts.Length; i++)
                                {
                                    if (parts[i] == "partial") continue;
                                    bool partial = i + 1 < parts.Length && parts[i + 1] == "partial";
                                    if (!partial && LangNames.ContainsKey(parts[i])) transLangs.Add(parts[i]);
                                }
                            }
                            break;
                    }
                }
            }

            if (!hasDatePub) return null;

            // ---- title (and version) ----
            string marked = GroupRx.Replace(stem, "\u0001");
            List<string> titles = new List<string>();
            List<string> versions = new List<string>();
            foreach (string piece in marked.Split(new string[] { " & " }, StringSplitOptions.None))
            {
                int i1 = piece.IndexOf('\u0001');
                string t = (i1 >= 0 ? piece.Substring(0, i1) : piece).Trim().TrimEnd('-', ' ');
                if (t.Length == 0) continue;
                Match vm = VersionRx.Match(t);
                if (vm.Success) { t = vm.Groups[1].Value.Trim(); versions.Add(vm.Groups[2].Value.Trim()); }
                if (t.Length > 0) titles.Add(t);
            }
            if (titles.Count == 0) return null;
            f.Title = string.Join(" & ", titles.ToArray());
            f.TitleKey = SpacesRx.Replace(f.Title, " ").ToLowerInvariant();
            f.Version = string.Join(" & ", versions.ToArray());

            // ---- language of the file ----
            if (explicitLangs.Count > 0) f.Langs = explicitLangs;
            else if (hasCountry) f.Langs = countryLangs;
            else f.Langs.Add("en");                                  // TNC: no tag = English
            if (transLangs.Count > 0) f.Langs = transLangs;          // full translation replaces the language
            return f;
        }

        static bool IsCodeList(string g, bool country)
        {
            if (g.Length < 2) return false;
            foreach (string c0 in g.Split('-'))
            {
                string c = c0.Trim();
                if (country) { if (!CountryLangs.ContainsKey(c)) return false; }
                else { if (!LangNames.ContainsKey(c)) return false; }
            }
            return true;
        }

        static void SetDate(TosecFile f, string g)
        {
            f.Date = g;
            if (g.Length >= 4 && char.IsDigit(g[0]) && char.IsDigit(g[1]) && char.IsDigit(g[2]) && char.IsDigit(g[3]))
            {
                f.YearFrom = f.YearTo = int.Parse(g.Substring(0, 4));
            }
            else if (g.Length >= 4 && char.IsDigit(g[2]) && g[3] == 'x' && char.IsDigit(g[0]) && char.IsDigit(g[1]))
            {
                f.YearFrom = int.Parse(g.Substring(0, 3)) * 10;      // 199x -> 1990..1999
                f.YearTo = f.YearFrom + 9;
            }
            // 19xx / 20xx = unknown (0, 0)
        }

        // Natural comparison of version texts: v1.03b > v1.03 > v1.0 > (none)
        public static int CompareVersion(string a, string b)
        {
            if (a == b) return 0;
            if (a.Length == 0) return -1;
            if (b.Length == 0) return 1;
            string[] ta = VersionTokens(a), tb = VersionTokens(b);
            int n = Math.Min(ta.Length, tb.Length);
            for (int i = 0; i < n; i++)
            {
                bool da = char.IsDigit(ta[i][0]), db = char.IsDigit(tb[i][0]);
                int c;
                if (da && db)
                {
                    string x = ta[i].TrimStart('0'), y = tb[i].TrimStart('0');
                    c = x.Length != y.Length ? x.Length.CompareTo(y.Length) : string.CompareOrdinal(x, y);
                }
                else if (da != db) c = da ? 1 : -1;
                else c = string.Compare(ta[i], tb[i], StringComparison.OrdinalIgnoreCase);
                if (c != 0) return c;
            }
            return ta.Length.CompareTo(tb.Length);
        }

        static string[] VersionTokens(string v)
        {
            v = Regex.Replace(v, @"^(?:v|Rev)\s*", "");
            List<string> l = new List<string>();
            foreach (Match m in Regex.Matches(v, @"\d+|[A-Za-z]+")) l.Add(m.Value);
            return l.ToArray();
        }

        // ------------------------------------------------------------------
        // Scanning an input folder
        // ------------------------------------------------------------------
        public static ScanResult Scan(string folder)
        {
            ScanResult r = new ScanResult();
            r.Folder = folder;
            foreach (string path in Directory.GetFiles(folder))
            {
                string name = Path.GetFileName(path);
                string stem;
                TosecFile f = SplitName(name, out stem) ? ParseStem(stem, name, path) : null;
                if (f == null) r.BadName.Add(name); else r.Valid.Add(f);
            }
            foreach (string d in Directory.GetDirectories(folder)) r.SubFolders.Add(Path.GetFileName(d));
            return r;
        }
    }

    public class ScanResult
    {
        public string Folder = "";
        public List<TosecFile> Valid = new List<TosecFile>();
        public List<string> BadName = new List<string>();
        public List<string> SubFolders = new List<string>();
    }

    // ------------------------------------------------------------------
    // The user's choices
    // ------------------------------------------------------------------
    public class Options
    {
        public HashSet<string> Languages = new HashSet<string>();
        public bool ExclBad = true, ExclOver = true, ExclUnder = true, ExclVirus = true;
        public bool ExclCracked = true, ExclHacked = true, ExclTrained = true;
        public bool ExclFixed = false, ExclModified = false, ExclPirated = false;
        public bool ExclDemo = true, ExclProto = true, ExclAlpha = true, ExclBeta = true, ExclPreview = true;
        public int FromYear = 0, ToYear = 0;           // 0 = no limit on that side
        public bool KeepUnknownDate = true;

        // Returns the reason a file is left out, or null when it may stay in the running.
        public string Reject(TosecFile f)
        {
            if (ExclBad && f.Bad) return "bad dump [b]";
            if (ExclOver && f.Over) return "over dump [o]";
            if (ExclUnder && f.Under) return "under dump [u]";
            if (ExclVirus && f.Virus) return "virus-infected [v]";
            if (ExclCracked && f.Cracked) return "cracked [cr]";
            if (ExclHacked && f.Hacked) return "hacked [h]";
            if (ExclTrained && f.Trained) return "trained [t]";
            if (ExclFixed && f.Fixed) return "fixed [f]";
            if (ExclModified && f.Modified) return "modified [m]";
            if (ExclPirated && f.Pirated) return "pirated [p]";
            if (ExclDemo && f.Demo) return "demo";
            if (ExclProto && f.Proto) return "prototype";
            if (ExclAlpha && f.Alpha) return "alpha build";
            if (ExclBeta && f.Beta) return "beta build";
            if (ExclPreview && f.Preview) return "preview / pre-release";
            if (FromYear > 0 || ToYear > 0)
            {
                if (f.YearFrom == 0)
                {
                    if (!KeepUnknownDate) return "release date unknown";
                }
                else if ((FromYear > 0 && f.YearTo < FromYear) || (ToYear > 0 && f.YearFrom > ToYear)) return "outside the date range";
            }
            if (!f.MultiLang)
            {
                bool ok = false;
                foreach (string l in f.Langs) if (Languages.Contains(l)) { ok = true; break; }
                if (!ok) return "language not selected";
            }
            return null;
        }
    }

    // ------------------------------------------------------------------
    // Choosing the best version of each game
    // ------------------------------------------------------------------
    public class Ranker
    {
        HashSet<string> sel;
        public Ranker(HashSet<string> selected) { sel = selected; }

        // 0 = English and Greek, 1 = English, 2 = Greek, 3 = any other selected language
        public int LangScore(TosecFile f)
        {
            if (f.MultiLang) return 3;
            bool en = f.Langs.Contains("en") && sel.Contains("en");
            bool el = f.Langs.Contains("el") && sel.Contains("el");
            if (en && el) return 0;
            if (en) return 1;
            if (el) return 2;
            return 3;
        }

        // Negative = a is better than b.
        public int Compare(TosecFile a, TosecFile b)
        {
            int c = a.DamageCount.CompareTo(b.DamageCount);               // 0. an intact image beats a damaged one
            if (c != 0) return c;
            c = a.Incomplete.CompareTo(b.Incomplete);                     // 1. completeness
            if (c != 0) return c;
            c = a.CopyrightRank.CompareTo(b.CopyrightRank);
            if (c != 0) return c;
            c = a.OriginalityTier.CompareTo(b.OriginalityTier);           // 2. originality
            if (c != 0) return c;
            c = LangScore(a).CompareTo(LangScore(b));                     // 3. language
            if (c != 0) return c;
            c = Tosec.CompareVersion(b.Version, a.Version);               // 4. newest version first
            if (c != 0) return c;
            c = b.Verified.CompareTo(a.Verified);                         //    then verified [!]
            if (c != 0) return c;
            c = string.Compare(a.FileName, b.FileName, StringComparison.OrdinalIgnoreCase);   // 5. alphabetical
            if (c != 0) return c;
            return string.CompareOrdinal(a.FileName, b.FileName);
        }
    }

    public class Selection
    {
        public int ValidFiles, Excluded, Games;
        public List<TosecFile> Chosen = new List<TosecFile>();
        public SortedDictionary<string, int> ExcludedByReason = new SortedDictionary<string, int>();
        public List<string> ExcludedLines = new List<string>();
        public List<string> NotChosenLines = new List<string>();
        public List<string> WarningLines = new List<string>();
        public int NotChosen { get { return NotChosenLines.Count; } }
    }

    class Release
    {
        public List<TosecFile> Files = new List<TosecFile>();
        public TosecFile Lead;
        public bool Complete = true;
        public string Missing = "";
    }

    public static class Selector
    {
        public static Selection Select(List<TosecFile> all, Options o)
        {
            Selection s = new Selection();
            s.ValidFiles = all.Count;
            Ranker r = new Ranker(o.Languages);
            Dictionary<string, List<TosecFile>> groups = new Dictionary<string, List<TosecFile>>();

            foreach (TosecFile f in all)
            {
                string why = o.Reject(f);
                if (why != null)
                {
                    s.Excluded++;
                    int n;
                    s.ExcludedByReason.TryGetValue(why, out n);
                    s.ExcludedByReason[why] = n + 1;
                    s.ExcludedLines.Add(f.FileName + "   <- " + why);
                    continue;
                }
                List<TosecFile> l;
                if (!groups.TryGetValue(f.TitleKey, out l)) { l = new List<TosecFile>(); groups[f.TitleKey] = l; }
                l.Add(f);
            }

            List<string> keys = new List<string>(groups.Keys);
            keys.Sort(StringComparer.Ordinal);
            foreach (string k in keys) ChooseForGame(groups[k], r, s);
            s.Games = keys.Count;

            s.Chosen.Sort(delegate (TosecFile a, TosecFile b) { return string.Compare(a.FileName, b.FileName, StringComparison.OrdinalIgnoreCase); });
            s.ExcludedLines.Sort(StringComparer.OrdinalIgnoreCase);
            s.NotChosenLines.Sort(StringComparer.OrdinalIgnoreCase);
            return s;
        }

        static void ChooseForGame(List<TosecFile> group, Ranker r, Selection s)
        {
            List<Release> rels = new List<Release>();
            Dictionary<int, List<TosecFile>> byTotal = new Dictionary<int, List<TosecFile>>();
            foreach (TosecFile f in group)
            {
                if (f.Part == null)
                {
                    Release one = new Release();
                    one.Files.Add(f);
                    one.Lead = f;
                    rels.Add(one);
                }
                else
                {
                    List<TosecFile> l;
                    if (!byTotal.TryGetValue(f.Part.Total, out l)) { l = new List<TosecFile>(); byTotal[f.Part.Total] = l; }
                    l.Add(f);
                }
            }
            foreach (KeyValuePair<int, List<TosecFile>> kv in byTotal) rels.Add(BuildMulti(kv.Value, kv.Key, r));

            rels.Sort(delegate (Release a, Release b)
            {
                if (a.Complete != b.Complete) return a.Complete ? -1 : 1;     // a complete set beats an incomplete one
                return r.Compare(a.Lead, b.Lead);
            });

            Release best = rels[0];
            foreach (TosecFile f in best.Files) s.Chosen.Add(f);
            foreach (TosecFile f in group)
                if (!best.Files.Contains(f))
                    s.NotChosenLines.Add(f.FileName + "   <- a better version was kept: " + best.Lead.FileName);

            if (!best.Complete)
                s.WarningLines.Add(best.Lead.Title + ": incomplete multi-part set, missing part(s) " + best.Missing + "  [" + best.Lead.FileName + "]");
            string weak = Weakness(best.Lead);
            if (weak != null)
                s.WarningLines.Add(best.Lead.Title + ": the best available version is " + weak + "  [" + best.Lead.FileName + "]");
        }

        static string Weakness(TosecFile f)
        {
            List<string> w = new List<string>();
            if (f.Bad) w.Add("a bad dump");
            if (f.Over) w.Add("an over dump");
            if (f.Under) w.Add("an under dump");
            if (f.Virus) w.Add("virus-infected");
            if (f.Demo) w.Add("a demo");
            if (f.Proto) w.Add("a prototype");
            if (f.Alpha) w.Add("an alpha build");
            if (f.Beta) w.Add("a beta build");
            if (f.Preview) w.Add("a preview / pre-release");
            if (f.Alternate) w.Add("an alternate dump [a]");
            if (f.Cracked) w.Add("cracked");
            if (f.Hacked) w.Add("hacked");
            if (f.Trained) w.Add("trained");
            if (f.Fixed) w.Add("fixed");
            if (f.Modified) w.Add("modified");
            if (f.Pirated) w.Add("pirated");
            if (f.Translated) w.Add("a fan translation");
            if (f.Copyright == "SW") w.Add("unregistered shareware");
            return w.Count == 0 ? null : string.Join(", ", w.ToArray());
        }

        static bool SameRelease(TosecFile a, TosecFile b)
        {
            return Tosec.CompareVersion(a.Version, b.Version) == 0 && a.Copyright == b.Copyright && a.LangKey() == b.LangKey();
        }

        // Builds one multi-part release: the best first part, then for every other part the file that
        // belongs to the same release as that first part (same version, copyright and language) when
        // there is one, otherwise the best remaining file.
        static Release BuildMulti(List<TosecFile> files, int total, Ranker r)
        {
            Release rel = new Release();
            int T = total;
            int minStart = int.MaxValue;
            foreach (TosecFile f in files)
            {
                if (total == 0 && f.Part.End > T) T = f.Part.End;
                if (f.Part.Start < minStart) minStart = f.Part.Start;
            }

            TosecFile lead = null;
            foreach (TosecFile f in files)
                if (f.Part.Start == minStart && (lead == null || r.Compare(f, lead) < 0)) lead = f;
            rel.Lead = lead;

            Dictionary<string, List<TosecFile>> byKey = new Dictionary<string, List<TosecFile>>();
            foreach (TosecFile f in files)
            {
                List<TosecFile> l;
                if (!byKey.TryGetValue(f.Part.Key, out l)) { l = new List<TosecFile>(); byKey[f.Part.Key] = l; }
                l.Add(f);
            }

            foreach (KeyValuePair<string, List<TosecFile>> kv in byKey)
            {
                if (kv.Key == lead.Part.Key) { rel.Files.Add(lead); continue; }
                TosecFile pick = null;
                foreach (TosecFile f in kv.Value)
                {
                    if (pick == null) { pick = f; continue; }
                    bool mf = SameRelease(f, lead), mp = SameRelease(pick, lead);
                    if (mf != mp) { if (mf) pick = f; continue; }
                    if (r.Compare(f, pick) < 0) pick = f;
                }
                rel.Files.Add(pick);
            }
            rel.Files.Sort(delegate (TosecFile a, TosecFile b)
            {
                int c = a.Part.Start.CompareTo(b.Part.Start);
                return c != 0 ? c : string.CompareOrdinal(a.Part.Key, b.Part.Key);
            });

            bool[] covered = new bool[T + 2];
            foreach (TosecFile f in rel.Files)
                for (int i = f.Part.Start; i <= f.Part.End && i <= T; i++) covered[i] = true;
            List<string> missing = new List<string>();
            for (int i = 1; i <= T; i++) if (!covered[i]) missing.Add(i.ToString());
            if (missing.Count > 0) { rel.Complete = false; rel.Missing = string.Join(", ", missing.ToArray()); }
            return rel;
        }
    }

    // ------------------------------------------------------------------
    // Copying / moving one file. Never overwrites, never renames, never edits,
    // and contains no code that deletes anything.
    // ------------------------------------------------------------------
    public static class FileOps
    {
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true, EntryPoint = "MoveFileExW")]
        static extern bool MoveFileEx(string existing, string target, int flags);

        public static bool SameVolume(string a, string b)
        {
            string ra = Path.GetPathRoot(Path.GetFullPath(a)), rb = Path.GetPathRoot(Path.GetFullPath(b));
            return string.Equals(ra, rb, StringComparison.OrdinalIgnoreCase);
        }

        // Returns null on success, otherwise a short message (the file is then left untouched).
        public static string Transfer(string src, string dstDir, bool move)
        {
            try
            {
                string dst = Path.Combine(dstDir, Path.GetFileName(src));
                if (File.Exists(dst)) return "not transferred: a file with this name already exists in the output folder";
                if (!move) { File.Copy(src, dst, false); return null; }

                if (Environment.OSVersion.Platform == PlatformID.Win32NT)
                {
                    // Flags = 0: Windows only re-files the entry on the same drive. It is NOT allowed to
                    // copy-and-delete across drives and it cannot overwrite, so a wrong guess just fails.
                    if (MoveFileEx(src, dst, 0)) return null;
                    int err = Marshal.GetLastWin32Error();
                    return err == 17 ? "not moved: the output folder is on a different drive (the file was left where it is)"
                                     : "not moved: " + new System.ComponentModel.Win32Exception(err).Message;
                }
                File.Move(src, dst);        // non-Windows (testing only)
                return null;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
    }

    // ------------------------------------------------------------------
    // The text log
    // ------------------------------------------------------------------
    public static class Report
    {
        public static string BuildLog(string settings, Selection s, bool move, int done, bool cancelled, List<string> errors)
        {
            StringBuilder b = new StringBuilder();
            string nl = "\r\n";
            b.Append("TOSEC 1G1R Filter - log").Append(nl);
            b.Append(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")).Append(nl).Append(nl);
            b.Append(settings).Append(nl).Append(nl);
            b.Append("RESULT").Append(nl);
            b.Append("  Valid TOSEC files read           : ").Append(s.ValidFiles).Append(nl);
            b.Append("  Left out by your filters         : ").Append(s.Excluded).Append(nl);
            b.Append("  Games found                      : ").Append(s.Games).Append(nl);
            b.Append("  Not chosen (better version kept) : ").Append(s.NotChosen).Append(nl);
            b.Append("  Selected for transfer            : ").Append(s.Chosen.Count).Append(nl);
            b.Append("  Actually ").Append(move ? "moved" : "copied").Append("                  : ").Append(done).Append(nl);
            if (cancelled) b.Append("  The run was stopped before it finished.").Append(nl);
            b.Append("  Problems                         : ").Append(errors.Count).Append(nl).Append(nl);

            if (errors.Count > 0) Section(b, "PROBLEMS DURING THE TRANSFER", errors);
            if (s.WarningLines.Count > 0) Section(b, "GAMES KEPT ONLY AS A LESS DESIRABLE VERSION, OR AS AN INCOMPLETE SET", s.WarningLines);
            if (s.ExcludedByReason.Count > 0)
            {
                b.Append("FILES LEFT OUT BY FILTERS - SUMMARY").Append(nl);
                foreach (KeyValuePair<string, int> kv in s.ExcludedByReason)
                    b.Append("  ").Append(kv.Value.ToString().PadLeft(7)).Append("  ").Append(kv.Key).Append(nl);
                b.Append(nl);
            }
            List<string> chosen = new List<string>();
            foreach (TosecFile f in s.Chosen) chosen.Add(f.FileName);
            Section(b, "SELECTED FILES", chosen);
            Section(b, "NOT CHOSEN - A BETTER VERSION OF THE SAME GAME WAS KEPT", s.NotChosenLines);
            Section(b, "LEFT OUT BY FILTERS", s.ExcludedLines);
            return b.ToString();
        }

        static void Section(StringBuilder b, string title, List<string> lines)
        {
            b.Append(title).Append(" (").Append(lines.Count).Append(")").Append("\r\n");
            foreach (string l in lines) b.Append("  ").Append(l).Append("\r\n");
            b.Append("\r\n");
        }
    }
}
