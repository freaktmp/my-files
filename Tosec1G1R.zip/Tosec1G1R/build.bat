@echo off
rem Builds Tosec1G1R.exe using the C# compiler that is already part of Windows.
set CSC=%windir%\Microsoft.NET\Framework64\v4.0.30319\csc.exe
if not exist "%CSC%" set CSC=%windir%\Microsoft.NET\Framework\v4.0.30319\csc.exe
if not exist "%CSC%" (
  echo Could not find the Windows C# compiler. Please tell Claude about this message.
  pause
  exit /b 1
)
cd /d "%~dp0"
"%CSC%" /nologo /target:winexe /codepage:65001 /optimize+ /out:Tosec1G1R.exe /reference:System.Windows.Forms.dll /reference:System.Drawing.dll Tosec1G1R.cs TosecCore.cs
if errorlevel 1 (
  echo.
  echo Something went wrong. Please copy the text above and send it to Claude.
) else (
  echo.
  echo Done! Tosec1G1R.exe has been created in this folder.
)
pause
