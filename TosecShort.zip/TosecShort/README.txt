TOSEC SHORT NAMES
=================

WHAT IT DOES
  Takes a folder that the TOSEC 1G1R Filter produced and copies every file into a new,
  empty folder with a short name:

    Legend of TOSEC, The v1.03b (1986-06-21)(Devstudio)(A500)(PAL)(US)[cr Fairlight].adf
      -> The Legend of TOSEC.adf
    Lemmings v1.1 (1991)(Psygnosis)(Disk 1 of 2).adf
      -> Lemmings (Disk 1).adf

  Your original files are never renamed, moved, changed or deleted.

WHAT YOU HAVE
  TosecShort.exe       the program (about 60 KB, nothing to install)
  TosecShort.cs        the source code (window)
  TosecShortCore.cs    the source code (naming rules)
  build.bat            rebuilds the .exe on your own PC if you ever need to

HOW TO USE
  1. Double-click TosecShort.exe and follow the steps. Every step explains itself.
  2. The first time, Windows may show a blue "Windows protected your PC" screen.
     Click "More info", then "Run anyway".
  If the .exe will not start: double-click build.bat, wait for "Done!", and use
  the freshly built TosecShort.exe. (Nothing gets installed.)

THE STEPS
  1 Input folder      Browse only. Only the files directly in it are used;
                      subfolders are ignored.
  2 Output folder     Browse only. Must exist and be completely empty.
  3 The new names     The new name is the title. Choose: "The" back at the front
                      (on), plain letters only (on), add the year (off),
                      add the publisher (off).
  4 Multi-part games  Only shown when the folder has multi-disk or multi-tape games.
                      Choose how the number is written: (Disk 1 of 2), (Disk 1),
                      (D1) or (1 of 2), and whether to create .m3u playlists.
                      If games only name a side, e.g. (Side A), you are asked
                      whether they are disk sides or tape sides.
  5 Summary and Run   Shows what will happen, then Run. Files are copied one at
                      a time.

  Steps 3 and 4 show a live count of name clashes and an example from your folder.

WHAT ENDS UP IN THE OUTPUT FOLDER
  Every file from the input folder, renamed where possible, plus one .m3u per
  multi-part game if you asked for playlists, plus _NOT RENAMED.txt when some
  files kept their original names.

  A file keeps its original name when:
    - its name is not a TOSEC name (hidden or system files such as Thumbs.db
      are copied too, but not listed)
    - it is a compilation with shared flags, e.g. "A & B-(19xx)(-)[h]"
    - the new name would be the same as the old one
    - no usable new name is left (e.g. a title in Japanese letters with
      "plain letters" on, or a name Windows reserves such as "Con")
    - NAME CLASH: two files would get the same new name. Both keep their
      original names. Upper and lower case count as the same. If one disk of a
      game clashes, all its disks keep their original names. Ticking "Add the
      year" or "Add the publisher" often separates them.

THE NAMING RULES
  - The extension is kept exactly as it is (everything after the last ")" or "]").
  - Everything else is removed: version, date, publisher, machine model, video,
    region, language, licence, demo/beta flags, dump flags, notes.
  - "The" at the front: "Legend of TOSEC, The" -> "The Legend of TOSEC",
    "Simpsons, The - Bart vs. ..." -> "The Simpsons - Bart vs. ...".
    Only "The" is moved.
  - Plain letters: accents are removed (é -> e), special letters get a fixed
    spelling (ß -> ss, æ -> ae, Greek and Cyrillic are transliterated), " & "
    becomes " and ". Anything that cannot be guessed is dropped.
  - Year: only when the exact year is known; (19xx) or (198x) adds nothing.
  - Publisher: left out when unknown "(-)".
  - All disks of a game get the name of its first disk, so they stay together
    even when they come from different versions. A game with 10 or more disks
    gets a leading zero (Disk 01) so the disks sort correctly.
  - (Part 1-2 of 3) and (File 1 of 2) are always kept as written.
  - Playlists (.m3u): named after the game, listing its files in order, one per
    line, UTF-8 without BOM. Not created when that name is already taken.

SAFETY
  - Copies only. Nothing in the input folder is ever renamed, moved, changed or
    deleted. Nothing is ever overwritten.
  - Right before Run the program checks again that the output folder is still
    empty, that the input folder has not changed, and that there is enough free
    space.
  - The first copy error stops the run. Stop finishes the current file and then
    stops. _NOT RENAMED.txt then says how far the run got.
  - The program writes nothing else (no settings file, no registry entries).

TO UNINSTALL
  Delete the folder. Nothing else was installed.
