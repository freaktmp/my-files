using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

// TOSEC Short Names - the wizard window.
// Plain C# 5 (WinForms). Compiles with the C# compiler that ships with Windows.

namespace TosecShort
{
    static class Program
    {
        [DllImport("user32.dll")]
        static extern bool SetProcessDPIAware();

        [STAThread]
        static void Main()
        {
            try { SetProcessDPIAware(); } catch (Exception) { }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new WizardForm());
        }
    }

    class RunState
    {
        public Plan Plan; public string Out;
        public int Done; public bool Stopped, PlaylistsWritten, LogWritten;
        public string FailedName, Error, LogError;
        public bool Incomplete { get { return Stopped || FailedName != null; } }
    }

    class WizardForm : Form
    {
        const int P_IN = 0, P_OUT = 1, P_NAMES = 2, P_MULTI = 3, P_SUM = 4;
        static readonly Color Accent = Color.FromArgb(0x1d, 0x4f, 0x91);
        static readonly Color Bad = Color.FromArgb(0xb0, 0x2a, 0x2a);
        static readonly Color Good = Color.FromArgb(0x1e, 0x7a, 0x3e);

        readonly string[] titles = { "Input folder", "Output folder", "The new names", "Multi-part games", "Summary" };

        Panel[] pages = new Panel[5];
        List<int> active = new List<int>();
        int cur;
        Label lblStep, lblTitle;
        Button btnBack, btnNext, btnCancel;

        // step 1
        TextBox txtIn; Label lblScan; ScanResult scan;
        // step 2
        TextBox txtOut; Label lblOutStatus; bool outOk;
        // step 3
        CheckBox cbThe, cbPlain, cbYear, cbPub;
        Label lblClash3, lblExample3; Button btnClash3;
        // step 4
        Label lblFound, lblSideQ, lblExample4, lblClash4; Button btnClash4;
        Panel sideRow; RadioButton rbSideDisk, rbSideTape;
        RadioButton[] rbDisk = new RadioButton[4], rbTape = new RadioButton[4];
        CheckBox cbDiskM3u, cbTapeM3u;
        List<Control> diskGroup = new List<Control>(), tapeGroup = new List<Control>();
        // step 5
        TextBox txtSummary; ProgressBar bar; Label lblStatus; Button btnOpenOut;
        BackgroundWorker worker;

        Options opts = new Options();
        Plan plan;
        bool running, finished, closeWhenDone, building;

        public WizardForm()
        {
            Text = "TOSEC Short Names";
            Font = new Font("Segoe UI", 9.5f);
            AutoScaleMode = AutoScaleMode.Dpi;
            AutoScaleDimensions = new SizeF(96f, 96f);
            ClientSize = new Size(820, 680);
            MinimumSize = new Size(740, 600);
            StartPosition = FormStartPosition.CenterScreen;

            Panel head = new Panel(); head.Dock = DockStyle.Top; head.Height = 68; head.BackColor = Color.White;
            lblStep = new Label(); lblStep.AutoSize = true; lblStep.Left = 24; lblStep.Top = 10; lblStep.ForeColor = Color.DimGray;
            lblTitle = new Label(); lblTitle.AutoSize = true; lblTitle.Left = 24; lblTitle.Top = 28;
            lblTitle.Font = new Font("Segoe UI", 15f, FontStyle.Bold); lblTitle.ForeColor = Accent;
            head.Controls.Add(lblStep); head.Controls.Add(lblTitle);
            Panel headLine = new Panel(); headLine.Dock = DockStyle.Top; headLine.Height = 1; headLine.BackColor = Color.Silver;

            Panel foot = new Panel(); foot.Dock = DockStyle.Bottom; foot.Height = 54;
            Panel footLine = new Panel(); footLine.Dock = DockStyle.Bottom; footLine.Height = 1; footLine.BackColor = Color.Silver;
            FlowLayoutPanel flow = new FlowLayoutPanel(); flow.Dock = DockStyle.Fill; flow.FlowDirection = FlowDirection.RightToLeft;
            flow.Padding = new Padding(0, 10, 16, 0);
            btnCancel = MakeButton("Cancel"); btnNext = MakeButton("Next >"); btnBack = MakeButton("< Back");
            flow.Controls.Add(btnCancel); flow.Controls.Add(btnNext); flow.Controls.Add(btnBack);
            foot.Controls.Add(flow);
            btnBack.Click += delegate { GoBack(); };
            btnNext.Click += delegate { GoNext(); };
            btnCancel.Click += delegate { OnCancel(); };
            AcceptButton = btnNext;

            Panel host = new Panel(); host.Dock = DockStyle.Fill;
            building = true;
            BuildInput(); BuildOutput(); BuildNames(); BuildMulti(); BuildSummary();
            building = false;
            foreach (Panel p in pages) host.Controls.Add(p);
            host.Resize += delegate { FitScroll(pages[P_NAMES]); FitScroll(pages[P_MULTI]); };
            Stack(this, head, headLine, foot, footLine, host);

            worker = new BackgroundWorker();
            worker.WorkerReportsProgress = true;
            worker.WorkerSupportsCancellation = true;
            worker.DoWork += WorkerDoWork;
            worker.ProgressChanged += WorkerProgress;
            worker.RunWorkerCompleted += WorkerDone;

            FormClosing += OnFormClosing;
            UpdateActive();
            ShowPage(P_IN);
        }

        // ============================================================
        // layout helpers (same style as the 1G1R filter)
        // ============================================================
        static void Stack(Control parent, params Control[] cs)
        {
            foreach (Control c in cs) { parent.Controls.Add(c); c.BringToFront(); }
        }

        static Button MakeButton(string text)
        {
            Button b = new Button(); b.Text = text; b.Size = new Size(104, 32); b.Margin = new Padding(8, 0, 0, 0);
            b.FlatStyle = FlatStyle.System;
            return b;
        }

        static Panel NewPage()
        {
            Panel p = new Panel(); p.Dock = DockStyle.Fill; p.Padding = new Padding(24, 14, 24, 10); p.Visible = false;
            p.AutoScroll = true;
            return p;
        }

        static Panel Spacer(int h) { Panel s = new Panel(); s.Dock = DockStyle.Top; s.Height = h; return s; }

        static Label Note(string text)
        {
            Label l = new Label();
            l.AutoSize = false; l.Dock = DockStyle.Top; l.Height = 24; l.Text = text;
            l.UseMnemonic = false;                         // show "&" as written
            l.Resize += delegate { FitHeight(l); };
            l.TextChanged += delegate { FitHeight(l); };
            return l;
        }

        static void FitHeight(Label l)
        {
            if (l.Width <= 0) return;
            int w = l.Width - l.Padding.Horizontal;
            if (w <= 0) return;
            int h = TextRenderer.MeasureText(l.Text, l.Font, new Size(w, 0), TextFormatFlags.WordBreak | TextFormatFlags.NoPrefix).Height
                    + l.Padding.Vertical + 6;
            if (l.Height != h) l.Height = h;
        }

        static Label Muted(string text) { Label l = Note(text); l.ForeColor = Color.DimGray; return l; }
        static Label Bold(string text) { Label l = Note(text); l.Font = new Font(l.Font, FontStyle.Bold); return l; }

        static Label Indented(Label l) { l.Padding = new Padding(22, 0, 0, 0); return l; }

        static Label Example()
        {
            Label l = Note("");
            l.Font = new Font("Consolas", 9f);
            l.BackColor = Color.FromArgb(0xf4, 0xf4, 0xf4);
            l.Padding = new Padding(8, 6, 8, 2);
            return l;
        }

        static Panel FolderRow(out TextBox tb, out Button btn)
        {
            Panel row = new Panel(); row.Dock = DockStyle.Top; row.Height = 28;
            btn = new Button(); btn.Text = "Browse..."; btn.Dock = DockStyle.Right; btn.Width = 110; btn.FlatStyle = FlatStyle.System;
            Panel gap = new Panel(); gap.Dock = DockStyle.Right; gap.Width = 8;
            tb = new TextBox(); tb.ReadOnly = true; tb.Dock = DockStyle.Fill; tb.BackColor = SystemColors.Window;
            Stack(row, btn, gap, tb);
            return row;
        }

        CheckBox Tick(string text, bool chk)
        {
            CheckBox cb = new CheckBox(); cb.Text = text; cb.Checked = chk; cb.AutoSize = false;
            cb.Dock = DockStyle.Top; cb.Height = 26;
            cb.CheckedChanged += delegate { Recalc(); };
            return cb;
        }

        Panel ClashRow(out Label lbl, out Button btn)
        {
            Panel row = new Panel(); row.Dock = DockStyle.Top; row.Height = 30;
            btn = new Button(); btn.Text = "Show..."; btn.Dock = DockStyle.Right; btn.Width = 90; btn.FlatStyle = FlatStyle.System;
            btn.Click += delegate { ShowClashes(); };
            lbl = new Label(); lbl.Dock = DockStyle.Fill; lbl.TextAlign = ContentAlignment.MiddleLeft; lbl.UseMnemonic = false;
            lbl.Font = new Font(Font, FontStyle.Bold);
            Stack(row, btn, lbl);
            return row;
        }

        // ============================================================
        // the pages
        // ============================================================
        void BuildInput()
        {
            Panel p = pages[P_IN] = NewPage();
            Label expl = Note("Choose the folder that holds the files to rename. These should be the files your 1G1R filter produced, " +
                "from one TOSEC set. Your files are never changed: renamed copies go into a separate folder. Subfolders are ignored.");
            Button browse;
            Panel row = FolderRow(out txtIn, out browse);
            browse.Click += delegate { BrowseInput(); };
            lblScan = Note("");
            Stack(p, expl, Spacer(10), row, Spacer(10), lblScan);
        }

        void BuildOutput()
        {
            Panel p = pages[P_OUT] = NewPage();
            Label expl = Note("Choose an EMPTY folder for the renamed copies. Every file from the input folder will be copied here, " +
                "renamed where possible. The folder must already exist and be completely empty (use \"Make New Folder\" in the " +
                "browse window to create one).");
            Button browse;
            Panel row = FolderRow(out txtOut, out browse);
            browse.Click += delegate { BrowseOutput(); };
            lblOutStatus = Note("");
            Stack(p, expl, Spacer(10), row, Spacer(6), lblOutStatus);
        }

        void BuildNames()
        {
            Panel p = pages[P_NAMES] = NewPage();
            Label expl = Note("Your folder already holds one version of each game, so the new name is just the title. Everything else in " +
                "the TOSEC name is removed: version, region, language, machine model, licence, flags and notes. A disk or tape number is kept.");
            cbThe = Tick("Put \"The\" back at the front", true);
            Label dThe = Indented(Muted("Legend of TOSEC, The  ->  The Legend of TOSEC"));
            cbPlain = Tick("Use plain letters only", true);
            Label dPlain = Indented(Muted("Accents and special letters are replaced, and \" & \" becomes \"and\":  Café & Crème  ->  Cafe and Creme. " +
                "Avoids problems on emulators and older systems."));
            cbYear = Tick("Add the year", false);
            Label dYear = Indented(Muted("Elite  ->  Elite (1986)      only when the exact year is known"));
            cbPub = Tick("Add the publisher", false);
            Label dPub = Indented(Muted("Elite  ->  Elite (Firebird)      left out when unknown"));
            Panel clash = ClashRow(out lblClash3, out btnClash3);
            lblExample3 = Example();
            Stack(p, expl, Spacer(10), cbThe, dThe, Spacer(4), cbPlain, dPlain, Spacer(4), cbYear, dYear, Spacer(4), cbPub, dPub,
                  Spacer(10), clash, Spacer(6), Bold("Example from your folder"), lblExample3);
        }

        void BuildMulti()
        {
            Panel p = pages[P_MULTI] = NewPage();
            Label expl = Note("Some games come on more than one disk or tape. Every file of a game gets the same name and only the number " +
                "changes, so they always appear together and in order. Choose how the number is written.");
            lblFound = Bold("");

            lblSideQ = Note("These games name only a side, for example (Side A), without saying disk or tape. What are they?");
            sideRow = new Panel(); sideRow.Dock = DockStyle.Top; sideRow.Height = 30;
            FlowLayoutPanel sf = new FlowLayoutPanel(); sf.Dock = DockStyle.Fill; sf.WrapContents = false;
            rbSideDisk = new RadioButton(); rbSideDisk.Text = "Disk sides"; rbSideDisk.AutoSize = true;
            rbSideTape = new RadioButton(); rbSideTape.Text = "Tape sides"; rbSideTape.AutoSize = true; rbSideTape.Margin = new Padding(24, 3, 3, 3);
            rbSideDisk.CheckedChanged += delegate { Recalc(); };
            rbSideTape.CheckedChanged += delegate { Recalc(); };
            sf.Controls.Add(rbSideDisk); sf.Controls.Add(rbSideTape);
            sideRow.Controls.Add(sf);

            BuildGroup(p, diskGroup, rbDisk, out cbDiskM3u, "disk",
                new string[] { "As in TOSEC:      (Disk 1 of 2)", "Without total:    (Disk 1)", "Short:            (D1)", "Numbers only:     (1 of 2)" },
                "Disks with sides follow the same choice: (Disk 1 Side A) · (D1A) · (1A of 2). A game with 10 or more disks gets a " +
                "leading zero, so its disks sort correctly: (Disk 01).",
                "Create a playlist (.m3u) for every multi-disk game",
                "A small text file named after the game that lists its disks in order. Many emulators open it as one game and let you " +
                "swap disks from their menu. One extra file per multi-disk game.");
            BuildGroup(p, tapeGroup, rbTape, out cbTapeM3u, "tape",
                new string[] { "As in TOSEC:      (Tape 1 of 2 Side A)", "Without total:    (Tape 1 Side A)", "Short:            (T1A)", "Numbers only:     (1A of 2)" },
                "A single tape that only names a side follows the same choice: (Side A) · (SA) · (A). A game with 10 or more tapes gets " +
                "a leading zero: (Tape 01).",
                "Create a playlist (.m3u) for every multi-part game",
                "A small text file named after the game that lists its tapes and sides in order. Some emulators open it as one game and " +
                "let you change tapes from their menu. Note: the sides of a tape are not always meant to be played one after another " +
                "(side B can be a different version or a copy). One extra file per multi-part game.");

            Panel clash = ClashRow(out lblClash4, out btnClash4);
            lblExample4 = Example();

            List<Control> all = new List<Control>();
            all.Add(expl); all.Add(Spacer(10)); all.Add(lblFound); all.Add(Spacer(6)); all.Add(lblSideQ); all.Add(sideRow); all.Add(Spacer(6));
            all.AddRange(diskGroup); all.AddRange(tapeGroup);
            all.Add(Spacer(6)); all.Add(clash); all.Add(Spacer(6)); all.Add(Bold("Example from your folder")); all.Add(lblExample4);
            Stack(p, all.ToArray());
        }

        void BuildGroup(Panel p, List<Control> group, RadioButton[] rbs, out CheckBox m3u, string what,
                        string[] styles, string note, string m3uText, string m3uNote)
        {
            Label hdr = Bold("How should the " + what + " number be written?");
            Panel box = new Panel(); box.Dock = DockStyle.Top; box.Height = 4 * 26 + 4;
            for (int i = 3; i >= 0; i--)
            {
                RadioButton rb = new RadioButton(); rb.Text = styles[i]; rb.Dock = DockStyle.Top; rb.Height = 26;
                rb.Font = new Font("Consolas", 9.5f); rb.Padding = new Padding(4, 0, 0, 0);
                rb.Checked = i == (int)Style.NoTotal;
                rb.CheckedChanged += delegate { Recalc(); };
                rbs[i] = rb;
                box.Controls.Add(rb);
            }
            Label n = Indented(Muted(note));
            m3u = new CheckBox(); m3u.Text = m3uText; m3u.Checked = false; m3u.AutoSize = false; m3u.Dock = DockStyle.Top; m3u.Height = 26;
            m3u.CheckedChanged += delegate { Recalc(); };
            Label mn = Indented(Muted(m3uNote));
            group.Add(hdr); group.Add(box); group.Add(n); group.Add(Spacer(6)); group.Add(m3u); group.Add(mn); group.Add(Spacer(10));
        }

        void BuildSummary()
        {
            Panel p = pages[P_SUM] = NewPage();
            p.AutoScroll = false;
            Label expl = Note("Check the settings, then press Run. Files are copied one at a time. Your original files are not changed.");
            txtSummary = new TextBox(); txtSummary.Multiline = true; txtSummary.ReadOnly = true; txtSummary.ScrollBars = ScrollBars.Vertical;
            txtSummary.Dock = DockStyle.Fill; txtSummary.BackColor = SystemColors.Window; txtSummary.Font = new Font("Consolas", 9f);
            bar = new ProgressBar(); bar.Dock = DockStyle.Bottom; bar.Height = 22; bar.Minimum = 0; bar.Maximum = 1000; bar.Visible = false;
            lblStatus = Note(""); lblStatus.Dock = DockStyle.Bottom;
            FlowLayoutPanel btns = new FlowLayoutPanel(); btns.Dock = DockStyle.Bottom; btns.Height = 38;
            btnOpenOut = new Button(); btnOpenOut.Text = "Open output folder"; btnOpenOut.Width = 160; btnOpenOut.FlatStyle = FlatStyle.System; btnOpenOut.Visible = false;
            btnOpenOut.Click += delegate { try { Process.Start(txtOut.Text); } catch (Exception) { } };
            btns.Controls.Add(btnOpenOut);
            Stack(p, expl, Spacer(6), btns, bar, lblStatus, txtSummary);
        }

        // ============================================================
        // navigation
        // ============================================================
        void UpdateActive()
        {
            active.Clear();
            active.Add(P_IN); active.Add(P_OUT); active.Add(P_NAMES);
            if (scan != null && scan.HasMultiPart) active.Add(P_MULTI);
            active.Add(P_SUM);
        }

        void ShowPage(int page)
        {
            cur = page;
            for (int k = 0; k < pages.Length; k++) pages[k].Visible = (k == page);
            lblStep.Text = "Step " + (active.IndexOf(page) + 1) + " of " + active.Count;
            lblTitle.Text = page == P_MULTI ? MultiTitle() : titles[page];
            if (page == P_SUM) PrepareSummary();
            UpdateNav();
        }

        string MultiTitle()
        {
            if (scan == null) return titles[P_MULTI];
            if (scan.DiskSets > 0 && scan.TapeSets == 0) return "Multi-disk games";
            if (scan.TapeSets > 0 && scan.DiskSets == 0) return "Multi-tape games";
            return titles[P_MULTI];
        }

        void UpdateNav()
        {
            bool last = cur == P_SUM;
            btnBack.Visible = cur != P_IN;
            btnBack.Enabled = !running && !finished;
            btnNext.Text = finished ? "Close" : (last ? "Run" : "Next >");
            btnCancel.Text = running ? "Stop" : "Cancel";
            btnCancel.Visible = !finished;
            if (running) btnNext.Enabled = false;
            else if (finished) btnNext.Enabled = true;
            else btnNext.Enabled = PageValid(cur);
        }

        bool PageValid(int page)
        {
            switch (page)
            {
                case P_IN: return scan != null && scan.Files.Count > 0;
                case P_OUT: return outOk;
                case P_MULTI: return SidesResolved();
                case P_SUM: return plan != null && plan.Items.Count > 0;
                default: return true;
            }
        }

        bool SidesResolved()
        {
            return scan == null || !scan.NeedsSideQuestion || rbSideDisk.Checked || rbSideTape.Checked;
        }

        void GoBack()
        {
            if (running || finished) return;
            int i = active.IndexOf(cur);
            if (i > 0) ShowPage(active[i - 1]);
        }

        void GoNext()
        {
            if (finished) { Close(); return; }
            if (cur == P_IN && !Directory.Exists(txtIn.Text)) { Warn("The input folder no longer exists."); return; }
            if (cur == P_OUT) { CheckOutput(); if (!outOk) return; }
            if (cur == P_SUM) { StartRun(); return; }
            int i = active.IndexOf(cur);
            if (i < active.Count - 1) ShowPage(active[i + 1]);
        }

        void OnCancel()
        {
            if (running) { worker.CancelAsync(); lblStatus.Text = "Stopping after the current file..."; btnCancel.Enabled = false; }
            else Close();
        }

        void OnFormClosing(object sender, FormClosingEventArgs e)
        {
            if (!running) return;
            DialogResult r = MessageBox.Show(this, "Files are still being copied. Stop after the current file and close the program?", Text,
                MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
            e.Cancel = true;
            if (r == DialogResult.Yes) { closeWhenDone = true; worker.CancelAsync(); }
        }

        void Warn(string msg) { MessageBox.Show(this, msg, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning); }

        // ============================================================
        // steps 1 and 2
        // ============================================================
        void BrowseInput()
        {
            using (FolderBrowserDialog d = new FolderBrowserDialog())
            {
                d.Description = "Choose the folder with the files to rename";
                d.ShowNewFolderButton = false;
                if (Directory.Exists(txtIn.Text)) d.SelectedPath = txtIn.Text;
                if (d.ShowDialog(this) != DialogResult.OK) return;
                txtIn.Text = d.SelectedPath;
            }
            ScanInput();
        }

        void ScanInput()
        {
            scan = null;
            Cursor = Cursors.WaitCursor;
            try { scan = Tosec.Scan(txtIn.Text); }
            catch (Exception ex) { Warn("The folder could not be read:\r\n" + ex.Message); }
            finally { Cursor = Cursors.Default; }

            building = true;
            rbSideDisk.Checked = rbSideTape.Checked = false;
            building = false;

            if (scan == null) { lblScan.Text = ""; UpdateActive(); UpdateNav(); return; }
            StringBuilder sb = new StringBuilder();
            sb.Append("Files found:            ").Append(scan.Files.Count.ToString("N0")).Append("\r\n");
            sb.Append("   with TOSEC names:    ").Append(scan.TosecCount.ToString("N0")).Append("\r\n");
            sb.Append("   other files:         ").Append(scan.OtherCount.ToString("N0")).Append("   (copied with their original names)\r\n");
            sb.Append("Subfolders ignored:     ").Append(scan.SubFolders.ToString("N0"));
            if (scan.Files.Count == 0) sb.Append("\r\n\r\nThere are no files in this folder. Please choose another one.");
            lblScan.Font = new Font("Consolas", 9.5f);
            lblScan.Text = sb.ToString();
            lblScan.ForeColor = scan.Files.Count == 0 ? Bad : SystemColors.ControlText;
            UpdateActive();
            Recalc();
            UpdateNav();
        }

        void BrowseOutput()
        {
            using (FolderBrowserDialog d = new FolderBrowserDialog())
            {
                d.Description = "Choose an EMPTY folder for the renamed copies (use Make New Folder to create one)";
                d.ShowNewFolderButton = true;
                if (Directory.Exists(txtOut.Text)) d.SelectedPath = txtOut.Text;
                if (d.ShowDialog(this) != DialogResult.OK) return;
                txtOut.Text = d.SelectedPath;
            }
            CheckOutput();
        }

        void CheckOutput()
        {
            outOk = false;
            string path = txtOut.Text;
            if (path.Length == 0) { lblOutStatus.Text = "No folder chosen yet."; lblOutStatus.ForeColor = Color.DimGray; }
            else if (!Directory.Exists(path)) { lblOutStatus.Text = "This folder does not exist."; lblOutStatus.ForeColor = Bad; }
            else
            {
                int n;
                try { n = Directory.GetFileSystemEntries(path).Length; }
                catch (Exception ex) { lblOutStatus.Text = "The folder cannot be read: " + ex.Message; lblOutStatus.ForeColor = Bad; n = -1; }
                if (n > 0) { lblOutStatus.Text = "This folder is not empty. Please choose an empty folder."; lblOutStatus.ForeColor = Bad; }
                else if (n == 0) { lblOutStatus.Text = "The folder is empty."; lblOutStatus.ForeColor = Good; outOk = true; }
            }
            UpdateNav();
        }

        // ============================================================
        // steps 3 and 4: options, live clash count and examples
        // ============================================================
        Options ReadOptions()
        {
            Options o = new Options();
            o.MoveThe = cbThe.Checked; o.Plain = cbPlain.Checked; o.Year = cbYear.Checked; o.Publisher = cbPub.Checked;
            for (int i = 0; i < 4; i++)
            {
                if (rbDisk[i].Checked) o.DiskStyle = (Style)i;
                if (rbTape[i].Checked) o.TapeStyle = (Style)i;
            }
            o.DiskM3u = cbDiskM3u.Checked; o.TapeM3u = cbTapeM3u.Checked;
            if (scan != null && scan.NeedsSideQuestion) o.SidesAreTapes = rbSideTape.Checked;
            else o.SidesAreTapes = scan != null && scan.TapeSets > 0 && scan.DiskSets == 0;
            return o;
        }

        void Recalc()
        {
            if (building || scan == null) return;
            opts = ReadOptions();
            plan = Planner.Build(scan, opts);

            string clash;
            if (plan.Clashes == 0 && plan.PlaylistsDropped == 0) clash = "No name clashes.";
            else
            {
                clash = "Name clashes with these settings: " + plan.Clashes.ToString("N0") + " file(s)";
                if (plan.PlaylistsDropped > 0) clash += ", " + plan.PlaylistsDropped + " playlist(s)";
                clash += " - they will keep their original names.";
            }
            lblClash3.Text = lblClash4.Text = clash;
            lblClash3.ForeColor = lblClash4.ForeColor = plan.Clashes + plan.PlaylistsDropped > 0 ? Bad : Good;
            btnClash3.Enabled = btnClash4.Enabled = plan.Clashes + plan.PlaylistsDropped > 0;

            lblExample3.Text = NamesExample();
            UpdateMultiPage();
            FitScroll(pages[P_NAMES]); FitScroll(pages[P_MULTI]);
            UpdateNav();
        }

        // Docked controls do not make a panel scroll by themselves; tell it how tall the content is.
        static void FitScroll(Panel p)
        {
            int h = p.Padding.Vertical;
            foreach (Control c in p.Controls) if (c.Visible && c.Dock == DockStyle.Top) h += c.Height;
            p.AutoScrollMinSize = new Size(0, h);
        }

        string Arrow(Item it)
        {
            string s = "  " + it.Src.Name + "\r\n  -> ";
            if (it.Reason == Reason.Renamed) return s + it.Target;
            if (it.Reason == Reason.Clash) return s + it.Would + "\r\n     (name clash: keeps its original name)";
            return s + it.Target + "   (" + Planner.ReasonText(it.Reason) + ")";
        }

        // The usable TOSEC file with the longest name shows the most of what is removed.
        string NamesExample()
        {
            Item best = null;
            foreach (Item it in plan.Items)
            {
                if (!Tosec.Usable(it.Src)) continue;
                if (best == null || it.Src.Name.Length > best.Src.Name.Length) best = it;
            }
            return best == null ? "  (no TOSEC names in this folder)" : Arrow(best);
        }

        void UpdateMultiPage()
        {
            if (!scan.HasMultiPart) return;
            List<string> found = new List<string>();
            if (scan.DiskSets > 0) found.Add(scan.DiskSets.ToString("N0") + " multi-disk game(s) (" + scan.DiskFiles.ToString("N0") + " files)");
            if (scan.TapeSets > 0) found.Add(scan.TapeSets.ToString("N0") + " multi-tape game(s) (" + scan.TapeFiles.ToString("N0") + " files)");
            if (scan.SideSets > 0) found.Add(scan.SideSets.ToString("N0") + " game(s) that only name a side (" + scan.SideFiles.ToString("N0") + " files)");
            string f = "Found: " + string.Join(", ", found.ToArray()) + ".";
            if (scan.DiskSets > 0 && scan.TapeSets > 0) f += "\r\nThis folder seems to hold both disks and tapes.";
            else if (scan.DiskSets > 0) f += scan.SideSets > 0 ? " Side-only names are treated as disk sides." : " All of them are disks.";
            else if (scan.TapeSets > 0) f += scan.SideSets > 0 ? " Side-only names are treated as tape sides." : " All of them are tapes.";
            lblFound.Text = f;

            bool ask = scan.NeedsSideQuestion;
            lblSideQ.Visible = sideRow.Visible = ask;
            bool resolved = SidesResolved();
            bool showDisk = scan.DiskSets > 0 || (scan.SideSets > 0 && resolved && !opts.SidesAreTapes);
            bool showTape = scan.TapeSets > 0 || (scan.SideSets > 0 && resolved && opts.SidesAreTapes);
            foreach (Control c in diskGroup) c.Visible = showDisk;
            foreach (Control c in tapeGroup) c.Visible = showTape;

            StringBuilder ex = new StringBuilder();
            if (showDisk) AppendSetExample(ex, Kind.Disk);
            if (showTape) AppendSetExample(ex, Kind.Tape);
            if (ex.Length == 0) ex.Append("  Answer the question above to see an example.");
            lblExample4.Text = ex.ToString().TrimEnd();
        }

        void AppendSetExample(StringBuilder b, Kind k)
        {
            int set = -1;
            foreach (Item it in plan.Items)
                if (it.Set >= 0 && it.Src.Part != null && Planner.EffectiveKind(it.Src.Part, opts) == k) { set = it.Set; break; }
            if (set < 0) return;
            List<Item> members = new List<Item>();
            foreach (Item it in plan.Items) if (it.Set == set) members.Add(it);
            members.Sort(delegate (Item a, Item c) { return Planner.ComparePart(a.Src, c.Src); });
            int shown = 0;
            foreach (Item it in members)
            {
                if (shown++ == 4) { b.Append("  ... and ").Append(members.Count - 4).Append(" more\r\n"); break; }
                b.Append(Arrow(it)).Append("\r\n");
            }
            foreach (Playlist pl in plan.Playlists)
                if (pl.Items.Count > 0 && pl.Items[0].Set == set)
                    b.Append("  Playlist: ").Append(pl.Name).Append(pl.Dropped ? "   (name clash: not created)" : "").Append("\r\n");
            b.Append("\r\n");
        }

        void ShowClashes()
        {
            if (plan == null) return;
            StringBuilder b = new StringBuilder();
            foreach (Item it in plan.Items)
                if (it.Reason == Reason.Clash)
                    b.Append(it.Src.Name).Append("\r\n    would have been: ").Append(it.Would).Append("\r\n");
            foreach (Playlist pl in plan.Playlists)
                if (pl.Dropped) b.Append("Playlist not created: ").Append(pl.Name).Append("\r\n");
            using (Form f = new Form())
            {
                f.Text = "Name clashes"; f.Font = Font; f.StartPosition = FormStartPosition.CenterParent;
                f.ClientSize = new Size(760, 420); f.MinimizeBox = false; f.ShowInTaskbar = false;
                TextBox t = new TextBox(); t.Multiline = true; t.ReadOnly = true; t.ScrollBars = ScrollBars.Both; t.WordWrap = false;
                t.Dock = DockStyle.Fill; t.Font = new Font("Consolas", 9f); t.BackColor = SystemColors.Window; t.Text = b.ToString();
                Label l = Note("These files keep their original names, because with the current settings another file would get the same new name. " +
                    "Ticking \"Add the year\" or \"Add the publisher\" often separates them."); l.Padding = new Padding(8, 8, 8, 4);
                Panel bottom = new Panel(); bottom.Dock = DockStyle.Bottom; bottom.Height = 44;
                Button ok = MakeButton("Close"); ok.Location = new Point(f.ClientSize.Width - 120, 6); ok.Anchor = AnchorStyles.Right | AnchorStyles.Top;
                ok.DialogResult = DialogResult.OK; bottom.Controls.Add(ok);
                Stack(f, l, bottom, t);
                f.AcceptButton = ok;
                f.ShowDialog(this);
            }
        }

        // ============================================================
        // step 5: summary and run
        // ============================================================
        static string SizeText(long bytes)
        {
            if (bytes < 1024L * 1024) return (bytes / 1024.0).ToString("0.0") + " KB";
            if (bytes < 1024L * 1024 * 1024) return (bytes / (1024.0 * 1024)).ToString("0.0") + " MB";
            return (bytes / (1024.0 * 1024 * 1024)).ToString("0.0") + " GB";
        }

        static string StyleName(Style s)
        {
            switch (s)
            {
                case Style.AsTosec: return "As in TOSEC";
                case Style.NoTotal: return "Without total";
                case Style.Short: return "Short";
                default: return "Numbers only";
            }
        }

        void PrepareSummary()
        {
            if (running || finished) return;
            Recalc();
            string nl = "\r\n";
            StringBuilder b = new StringBuilder();
            b.Append("From:    ").Append(txtIn.Text).Append(nl);
            b.Append("To:      ").Append(txtOut.Text).Append(nl);
            List<string> nm = new List<string>();
            nm.Add(opts.MoveThe ? "\"The\" at the front" : "\"The\" as in TOSEC");
            nm.Add(opts.Plain ? "plain letters" : "letters as in TOSEC");
            nm.Add(opts.Year ? "with year" : "no year");
            nm.Add(opts.Publisher ? "with publisher" : "no publisher");
            b.Append("Names:   ").Append(string.Join(" · ", nm.ToArray())).Append(nl);
            if (active.Contains(P_MULTI))
            {
                bool disk = scan.DiskSets > 0 || (scan.SideSets > 0 && !opts.SidesAreTapes);
                bool tape = scan.TapeSets > 0 || (scan.SideSets > 0 && opts.SidesAreTapes);
                if (disk) b.Append("Disks:   ").Append(StyleName(opts.DiskStyle)).Append(" · ").Append(opts.DiskM3u ? "playlists" : "no playlists").Append(nl);
                if (tape) b.Append("Tapes:   ").Append(StyleName(opts.TapeStyle)).Append(" · ").Append(opts.TapeM3u ? "playlists" : "no playlists").Append(nl);
            }
            b.Append(nl);
            int kept = plan.Items.Count - plan.Renamed;
            b.Append("Files to copy:                    ").Append(plan.Items.Count.ToString("N0").PadLeft(7)).Append(nl);
            b.Append("  renamed:                        ").Append(plan.Renamed.ToString("N0").PadLeft(7)).Append(nl);
            b.Append("  kept their original name:       ").Append(kept.ToString("N0").PadLeft(7)).Append(nl);
            Line(b, "    not a TOSEC name", plan.NotTosec);
            Line(b, "    compilation with shared flags", plan.Shared);
            Line(b, "    nothing to shorten", plan.Nothing);
            Line(b, "    no usable new name", plan.Unusable);
            Line(b, "    name clash", plan.Clashes);
            if (plan.Hidden > 0)
                b.Append("    hidden or system files          ").Append(plan.Hidden.ToString("N0").PadLeft(7)).Append("   (not listed)").Append(nl);
            if (plan.Playlists.Count > 0)
            {
                b.Append("Playlists to create:              ").Append(plan.PlaylistsMade.ToString("N0").PadLeft(7)).Append(nl);
                if (plan.PlaylistsDropped > 0)
                    b.Append("  not created (name clash):       ").Append(plan.PlaylistsDropped.ToString("N0").PadLeft(7)).Append(nl);
            }
            b.Append(nl);
            b.Append("List of files not renamed:        ").Append(plan.NeedsLog ? "yes  (" + plan.LogName + " in the output folder)" : "not needed").Append(nl);
            long free = FileOps.FreeSpace(txtOut.Text);
            b.Append("Space needed:                     ").Append(SizeText(plan.TotalBytes));
            if (free >= 0) b.Append("    free: ").Append(SizeText(free)).Append(free > plan.TotalBytes ? "  OK" : "  NOT ENOUGH");
            b.Append(nl);
            txtSummary.Text = b.ToString();
            txtSummary.SelectionStart = 0; txtSummary.SelectionLength = 0;
            lblStatus.Text = ""; lblStatus.ForeColor = SystemColors.ControlText;
            bar.Value = 0; bar.Visible = false;
        }

        static void Line(StringBuilder b, string label, int n)
        {
            if (n == 0) return;
            b.Append(label.PadRight(34)).Append(n.ToString("N0").PadLeft(7)).Append("\r\n");
        }

        void StartRun()
        {
            if (plan == null || plan.Items.Count == 0) return;
            if (!FileOps.FolderIsEmpty(txtOut.Text)) { Warn("The output folder is no longer an empty folder. Please go back and choose an empty one."); return; }
            bool changed = false;
            try
            {
                if (Directory.GetFiles(txtIn.Text).Length != plan.Items.Count) changed = true;
                else foreach (Item it in plan.Items) if (!File.Exists(it.Src.FullPath)) { changed = true; break; }
            }
            catch (Exception) { changed = true; }
            if (changed) { Warn("The input folder has changed since it was chosen. Please go back to step 1 and choose it again."); return; }
            long free = FileOps.FreeSpace(txtOut.Text);
            if (free >= 0 && free < plan.TotalBytes + 1024 * 1024)
            {
                Warn("There is not enough free space for the copies.\r\n\r\nNeeded: " + SizeText(plan.TotalBytes) + "\r\nFree: " + SizeText(free));
                return;
            }
            running = true;
            RunState st = new RunState(); st.Plan = plan; st.Out = txtOut.Text;
            bar.Value = 0; bar.Visible = true;
            lblStatus.Text = "Starting..."; lblStatus.ForeColor = SystemColors.ControlText;
            UpdateNav();
            worker.RunWorkerAsync(st);
        }

        void WorkerDoWork(object sender, DoWorkEventArgs e)
        {
            RunState st = (RunState)e.Argument;
            List<Item> list = st.Plan.CopyOrder;
            Stopwatch sw = Stopwatch.StartNew();
            long nextReport = 0;
            for (int i = 0; i < list.Count; i++)
            {
                if (worker.CancellationPending) { st.Stopped = true; break; }
                Item it = list[i];
                if (sw.ElapsedMilliseconds >= nextReport)
                {
                    worker.ReportProgress((int)(i * 1000L / list.Count), (i + 1).ToString("N0") + " of " + list.Count.ToString("N0") + "   " + it.Src.Name);
                    nextReport = sw.ElapsedMilliseconds + 80;
                }
                string err = FileOps.Copy(it.Src.FullPath, st.Out, it.Target);
                if (err != null) { st.FailedName = it.Src.Name; st.Error = err; break; }
                st.Done++;
            }
            if (!st.Incomplete)
            {
                foreach (Playlist pl in st.Plan.Playlists)
                {
                    if (pl.Dropped) continue;
                    string err = FileOps.WriteNew(Path.Combine(st.Out, pl.Name), FileOps.PlaylistText(pl), false);
                    if (err != null) { st.FailedName = pl.Name; st.Error = err; break; }
                }
                st.PlaylistsWritten = st.FailedName == null;
            }
            if (Report.HasContent(st.Plan, st.Done, st.Incomplete))
            {
                string text = Report.Build(st.Plan, st.Done, st.Stopped, st.FailedName, st.Error, st.PlaylistsWritten);
                st.LogError = FileOps.WriteNew(Path.Combine(st.Out, st.Plan.LogName), text, true);
                st.LogWritten = st.LogError == null;
            }
            e.Result = st;
        }

        void WorkerProgress(object sender, ProgressChangedEventArgs e)
        {
            bar.Value = Math.Min(1000, Math.Max(0, e.ProgressPercentage));
            lblStatus.Text = "Copying " + (string)e.UserState;
        }

        void WorkerDone(object sender, RunWorkerCompletedEventArgs e)
        {
            running = false; finished = true;
            if (e.Error != null)
            {
                lblStatus.Text = "Stopped by an unexpected error: " + e.Error.Message;
                lblStatus.ForeColor = Bad;
            }
            else
            {
                RunState st = (RunState)e.Result;
                string msg;
                if (st.FailedName != null)
                {
                    msg = "STOPPED: \"" + st.FailedName + "\" could not be written: " + st.Error + "\r\n" +
                          st.Done.ToString("N0") + " of " + plan.CopyOrder.Count.ToString("N0") + " files were copied.";
                    lblStatus.ForeColor = Bad;
                }
                else if (st.Stopped)
                {
                    msg = "Stopped by you after " + st.Done.ToString("N0") + " of " + plan.CopyOrder.Count.ToString("N0") + " files. No playlists were created.";
                    lblStatus.ForeColor = Bad;
                }
                else
                {
                    bar.Value = 1000;
                    msg = "Done: " + st.Done.ToString("N0") + " files copied, " + plan.Renamed.ToString("N0") + " renamed";
                    if (plan.PlaylistsMade > 0) msg += ", " + plan.PlaylistsMade.ToString("N0") + " playlist(s) created";
                    msg += ".";
                    lblStatus.ForeColor = Good;
                }
                if (st.LogWritten) msg += "\r\nThe files that kept their original names are listed in " + plan.LogName + ".";
                else if (st.LogError != null) { msg += "\r\nThe list of files not renamed could not be written: " + st.LogError; lblStatus.ForeColor = Bad; }
                lblStatus.Text = msg;
            }
            btnOpenOut.Visible = true;
            btnCancel.Enabled = true;
            UpdateNav();
            if (closeWhenDone) Close();
        }
    }
}
