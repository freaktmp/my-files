using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;

// TOSEC Short Names - naming engine (no user interface in this file).
// Plain C# 5, no extra libraries.

namespace TosecShort
{
    public enum Kind { None, Disk, Tape, Side, Other }                 // Side = "(Side A)" with no media word
    public enum Style { AsTosec = 0, NoTotal = 1, Short = 2, NumbersOnly = 3 }
    public enum Reason { Renamed, NothingToShorten, NotTosec, SharedFlags, Unusable, Clash, Hidden }

    // One game inside a name (a compilation "A (..)(..) & B (..)(..)" has two).
    public class Entry
    {
        public string Title = "", Year = "", Publisher = "";
    }

    public class PartInfo
    {
        public Kind Kind;
        public string Word = "";          // Disk, Disc, Tape, Side, Part, File
        public string Raw = "";           // the group text exactly as written
        public int Start, End, Total;     // Start 0 = no number (Side A)
        public string Side = "";          // side letter, "A", "B" ...
    }

    public class SrcFile
    {
        public string Name = "", FullPath = "", Ext = "";
        public long Size;
        public bool Hidden;               // hidden or system file (Thumbs.db, desktop.ini ...)
        public bool Tosec;                // follows the naming convention
        public bool Shared;               // compilation with shared ("global") flags
        public List<Entry> Entries = new List<Entry>();
        public string TitleKey = "";
        public PartInfo Part;             // null = single file
        public string SetKey = "";
    }

    public class ScanResult
    {
        public string Folder = "";
        public List<SrcFile> Files = new List<SrcFile>();
        public int TosecCount, OtherCount, SubFolders;
        public int DiskSets, DiskFiles, TapeSets, TapeFiles, SideSets, SideFiles;
        public bool HasDisc;              // the word "Disc" (CD) was seen

        public bool NeedsSideQuestion { get { return SideSets > 0 && (DiskSets > 0) == (TapeSets > 0); } }
        public bool HasMultiPart { get { return DiskSets + TapeSets + SideSets > 0; } }
    }

    public class Options
    {
        public bool MoveThe = true, Plain = true, Year = false, Publisher = false;
        public Style DiskStyle = Style.NoTotal, TapeStyle = Style.NoTotal;
        public bool DiskM3u = false, TapeM3u = false;
        public bool SidesAreTapes = false;            // how "(Side A)" names are treated
    }

    public class Item
    {
        public SrcFile Src;
        public string Target = "";        // name in the output folder
        public string Would = "";         // the new name a clash prevented
        public Reason Reason;
        public int Set = -1;              // index into Plan.Sets
    }

    public class Playlist
    {
        public string Name = "";
        public List<Item> Items = new List<Item>();
        public bool Dropped;              // not created because of a name clash
    }

    public class PartSet
    {
        public List<SrcFile> Files = new List<SrcFile>();
        public SrcFile Lead;
        public int Width = 1;             // digits used for numbers in this set
        public Kind Kind;
    }

    public class Plan
    {
        public List<Item> Items = new List<Item>();        // same order as ScanResult.Files
        public List<Item> CopyOrder = new List<Item>();    // alphabetical by new name
        public List<Playlist> Playlists = new List<Playlist>();
        public string LogName = "_NOT RENAMED.txt";
        public int Renamed, Clashes, NotTosec, Shared, Nothing, Unusable, Hidden, PlaylistsMade, PlaylistsDropped;
        public long TotalBytes;

        public int NotRenamedListed { get { return Clashes + NotTosec + Shared + Nothing + Unusable; } }
        public bool NeedsLog { get { return NotRenamedListed > 0 || PlaylistsDropped > 0; } }
    }

    // ------------------------------------------------------------------
    // Reading names
    // ------------------------------------------------------------------
    public static class Tosec
    {
        static readonly Regex GroupRx = new Regex(@"\(([^()]*)\)|\[([^\[\]]*)\]", RegexOptions.Compiled);
        static readonly Regex DateRx = new Regex(@"^[12][0-9][0-9x]{2}(?:-[0-9]{2}(?:-[0-9x]{2})?)?$", RegexOptions.Compiled);
        static readonly Regex YearRx = new Regex(@"^([12][0-9]{3})", RegexOptions.Compiled);
        static readonly Regex MediaRx = new Regex(@"^(Disc|Disk|File|Part|Side|Tape)\s+(\d+)(?:-(\d+))?(?:\s+of\s+(\d+))?(?:\s+Side\s+([A-Za-z]))?$", RegexOptions.Compiled);
        static readonly Regex SideRx = new Regex(@"^Side\s+([A-Za-z])$", RegexOptions.Compiled);
        static readonly Regex VersionRx = new Regex(@"^(.*?)\s+(v\s?\d\S*|Rev\s+\S+)$", RegexOptions.Compiled);
        static readonly Regex SharedRx = new Regex(@"\S-[\(\[]", RegexOptions.Compiled);
        static readonly Regex SpacesRx = new Regex(@"\s+", RegexOptions.Compiled);

        // A TOSEC name ends with ")" or "]". Everything after it is the extension, kept exactly as is.
        public static bool SplitName(string name, out string stem, out string ext)
        {
            int i = Math.Max(name.LastIndexOf(')'), name.LastIndexOf(']'));
            stem = name; ext = "";
            if (i < 0) return false;
            stem = name.Substring(0, i + 1);
            ext = name.Substring(i + 1);
            return ext.Length == 0 || ext[0] == '.';
        }

        public static SrcFile Parse(string name, string fullPath)
        {
            SrcFile f = new SrcFile();
            f.Name = name; f.FullPath = fullPath;
            string stem, ext;
            if (!SplitName(name, out stem, out ext)) return f;
            f.Ext = ext;

            // ---- break the stem into text and groups ----
            List<string> tok = new List<string>();      // text pieces and groups, in order
            List<bool> isGroup = new List<bool>();
            int pos = 0;
            foreach (Match m in GroupRx.Matches(stem))
            {
                if (m.Index > pos) { tok.Add(stem.Substring(pos, m.Index - pos)); isGroup.Add(false); }
                tok.Add(m.Value); isGroup.Add(true);
                pos = m.Index + m.Length;
            }
            if (pos < stem.Length) { tok.Add(stem.Substring(pos)); isGroup.Add(false); }

            // ---- valid TOSEC name: a date followed by a publisher (same rule as the filter) ----
            bool afterDate = false, hasDatePub = false;
            for (int i = 0; i < tok.Count; i++)
            {
                if (!isGroup[i]) continue;
                if (tok[i][0] == '(')
                {
                    if (afterDate) { hasDatePub = true; break; }
                    afterDate = DateRx.IsMatch(Inner(tok[i]));
                }
                else afterDate = false;
            }
            if (!hasDatePub) return f;
            f.Tosec = true;
            if (SharedRx.IsMatch(stem)) { f.Shared = true; return f; }

            // ---- split into games at " & " (outside brackets) ----
            List<List<string>> pieces = new List<List<string>>();
            List<List<bool>> pieceGrp = new List<List<bool>>();
            pieces.Add(new List<string>()); pieceGrp.Add(new List<bool>());
            for (int i = 0; i < tok.Count; i++)
            {
                if (isGroup[i]) { pieces[pieces.Count - 1].Add(tok[i]); pieceGrp[pieceGrp.Count - 1].Add(true); continue; }
                string[] parts = tok[i].Split(new string[] { " & " }, StringSplitOptions.None);
                for (int k = 0; k < parts.Length; k++)
                {
                    if (k > 0) { pieces.Add(new List<string>()); pieceGrp.Add(new List<bool>()); }
                    if (parts[k].Length > 0) { pieces[pieces.Count - 1].Add(parts[k]); pieceGrp[pieceGrp.Count - 1].Add(false); }
                }
            }

            // A piece without groups is part of the next title ("Tom & Jerry (1989)(X)").
            string carry = "";
            List<int> datePubIdx = new List<int>();
            int globalIdx = 0;
            List<string> keyParts = new List<string>();
            for (int p = 0; p < pieces.Count; p++)
            {
                List<string> pt = pieces[p]; List<bool> pg = pieceGrp[p];
                bool hasGroup = pg.Contains(true);
                string lead = "";
                int g0 = 0;
                while (g0 < pt.Count && !pg[g0]) { lead += pt[g0]; g0++; }
                if (!hasGroup && p < pieces.Count - 1)
                {
                    carry += (carry.Length > 0 ? " & " : "") + lead.Trim();
                    globalIdx += pt.Count;
                    continue;
                }
                string title = lead.Trim().TrimEnd('-', ' ');
                if (carry.Length > 0) { title = carry + " & " + title; carry = ""; }
                Match vm = VersionRx.Match(title);
                if (vm.Success) title = vm.Groups[1].Value.Trim();

                Entry e = new Entry();
                e.Title = title;
                bool sawDate = false;
                for (int k = g0; k < pt.Count; k++)
                {
                    if (!pg[k] || pt[k][0] != '(') { if (pg[k]) sawDate = false; continue; }
                    string inner = Inner(pt[k]);
                    if (sawDate)
                    {
                        if (inner.Trim() != "-") e.Publisher = inner.Trim();
                        datePubIdx.Add(globalIdx + k);
                        break;
                    }
                    if (DateRx.IsMatch(inner))
                    {
                        Match ym = YearRx.Match(inner);
                        if (ym.Success) e.Year = ym.Groups[1].Value;
                        datePubIdx.Add(globalIdx + k);
                        sawDate = true;
                    }
                }
                globalIdx += pt.Count;
                if (e.Title.Length > 0) { f.Entries.Add(e); keyParts.Add(e.Title); }
            }
            if (f.Entries.Count == 0) { f.Shared = false; return f; }       // treated as unusable later
            f.TitleKey = SpacesRx.Replace(string.Join(" & ", keyParts.ToArray()), " ").ToLowerInvariant();

            // ---- the media group (Disk 1 of 2, Tape 2 of 2 Side B, Side A ...) ----
            int gi = 0;
            for (int p = 0; p < pieces.Count && f.Part == null; p++)
            {
                for (int k = 0; k < pieces[p].Count; k++, gi++)
                {
                    if (!pieceGrp[p][k] || pieces[p][k][0] != '(' || datePubIdx.Contains(gi)) continue;
                    PartInfo pi = ParsePart(Inner(pieces[p][k]).Trim());
                    if (pi != null) { f.Part = pi; break; }
                }
            }
            if (f.Part != null)
                f.SetKey = f.TitleKey + "|" + f.Part.Kind + "|" + f.Part.Total;
            return f;
        }

        static string Inner(string group) { return group.Substring(1, group.Length - 2); }

        public static PartInfo ParsePart(string g)
        {
            Match m = MediaRx.Match(g);
            PartInfo pi = new PartInfo();
            pi.Raw = g;
            if (m.Success)
            {
                pi.Word = m.Groups[1].Value;
                pi.Start = int.Parse(m.Groups[2].Value, CultureInfo.InvariantCulture);
                pi.End = m.Groups[3].Success ? int.Parse(m.Groups[3].Value, CultureInfo.InvariantCulture) : pi.Start;
                pi.Total = m.Groups[4].Success ? int.Parse(m.Groups[4].Value, CultureInfo.InvariantCulture) : 0;
                if (m.Groups[5].Success) pi.Side = m.Groups[5].Value.ToUpperInvariant();
                switch (pi.Word)
                {
                    case "Disk": case "Disc": pi.Kind = Kind.Disk; break;
                    case "Tape": pi.Kind = Kind.Tape; break;
                    case "Side": pi.Kind = Kind.Side; break;
                    default: pi.Kind = Kind.Other; break;
                }
                return pi;
            }
            m = SideRx.Match(g);
            if (m.Success)
            {
                pi.Word = "Side"; pi.Kind = Kind.Side;
                pi.Side = m.Groups[1].Value.ToUpperInvariant();
                return pi;
            }
            return null;
        }

        // ------------------------------------------------------------------
        // Scanning the input folder (files directly inside it only)
        // ------------------------------------------------------------------
        public static ScanResult Scan(string folder)
        {
            ScanResult r = new ScanResult();
            r.Folder = folder;
            DirectoryInfo di = new DirectoryInfo(folder);
            foreach (FileInfo fi in di.GetFiles())
            {
                SrcFile f = Parse(fi.Name, fi.FullName);
                f.Size = fi.Length;
                f.Hidden = (fi.Attributes & (FileAttributes.Hidden | FileAttributes.System)) != 0;
                r.Files.Add(f);
                if (f.Tosec) r.TosecCount++; else r.OtherCount++;
                if (f.Part != null && f.Part.Word == "Disc") r.HasDisc = true;
            }
            r.SubFolders = di.GetDirectories().Length;
            r.Files.Sort(delegate (SrcFile a, SrcFile b) { return string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase); });

            Dictionary<string, Kind> sets = new Dictionary<string, Kind>();
            foreach (SrcFile f in r.Files)
            {
                if (!Usable(f) || f.Part == null) continue;
                switch (f.Part.Kind)
                {
                    case Kind.Disk: r.DiskFiles++; break;
                    case Kind.Tape: r.TapeFiles++; break;
                    case Kind.Side: r.SideFiles++; break;
                }
                sets[f.SetKey] = f.Part.Kind;
            }
            foreach (Kind k in sets.Values)
            {
                if (k == Kind.Disk) r.DiskSets++;
                else if (k == Kind.Tape) r.TapeSets++;
                else if (k == Kind.Side) r.SideSets++;
            }
            return r;
        }

        public static bool Usable(SrcFile f) { return f.Tosec && !f.Shared && !f.Hidden && f.Entries.Count > 0; }
    }

    // ------------------------------------------------------------------
    // Plain letters
    // ------------------------------------------------------------------
    public static class Letters
    {
        static readonly Dictionary<char, string> Map = new Dictionary<char, string>();

        static Letters()
        {
            string[] pairs = {
                "ß|ss","ẞ|SS","æ|ae","Æ|AE","œ|oe","Œ|OE","ø|o","Ø|O","ł|l","Ł|L","đ|d","Đ|D","ð|d","Ð|D",
                "þ|th","Þ|Th","ı|i","ħ|h","Ħ|H","ŋ|ng","Ŋ|NG","ĸ|k","ſ|s","ŀ|l","Ŀ|L",
                "‘|'","’|'","‚|'","‛|'","′|'","´|'","`|'","“|'","”|'","„|'","″|'","«|'","»|'","‹|'","›|'",
                "–|-","—|-","‐|-","‑|-","‒|-","―|-","−|-","…|...","×|x","·|.","•|-",
                "¹|1","²|2","³|3","¼|1-4","½|1-2","¾|3-4","°| ","©| ","®| ","™| ","¡| ","¿| ","§| ","¶| ",
                "€|EUR","£|L","¥|Y","¢|c",
                // Greek
                "α|a","β|v","γ|g","δ|d","ε|e","ζ|z","η|i","θ|th","ι|i","κ|k","λ|l","μ|m","ν|n","ξ|x","ο|o","π|p",
                "ρ|r","σ|s","ς|s","τ|t","υ|y","φ|f","χ|ch","ψ|ps","ω|o",
                "Α|A","Β|V","Γ|G","Δ|D","Ε|E","Ζ|Z","Η|I","Θ|Th","Ι|I","Κ|K","Λ|L","Μ|M","Ν|N","Ξ|X","Ο|O","Π|P",
                "Ρ|R","Σ|S","Τ|T","Υ|Y","Φ|F","Χ|Ch","Ψ|Ps","Ω|O",
                // Cyrillic
                "а|a","б|b","в|v","г|g","д|d","е|e","ё|e","ж|zh","з|z","и|i","й|y","к|k","л|l","м|m","н|n","о|o",
                "п|p","р|r","с|s","т|t","у|u","ф|f","х|kh","ц|ts","ч|ch","ш|sh","щ|shch","ъ|","ы|y","ь|","э|e",
                "ю|yu","я|ya","і|i","ї|yi","є|ye","ґ|g",
                "А|A","Б|B","В|V","Г|G","Д|D","Е|E","Ё|E","Ж|Zh","З|Z","И|I","Й|Y","К|K","Л|L","М|M","Н|N","О|O",
                "П|P","Р|R","С|S","Т|T","У|U","Ф|F","Х|Kh","Ц|Ts","Ч|Ch","Ш|Sh","Щ|Shch","Ъ|","Ы|Y","Ь|","Э|E",
                "Ю|Yu","Я|Ya","І|I","Ї|Yi","Є|Ye","Ґ|G"
            };
            foreach (string p in pairs)
            {
                int i = p.IndexOf('|');
                Map[p[0]] = p.Substring(i + 1);
            }
        }

        // Turns any text into plain ASCII. Letters with accents lose the accent, a few special letters get a
        // fixed spelling, and anything that cannot be guessed is dropped.
        public static string ToPlain(string s)
        {
            StringBuilder b = new StringBuilder(s.Length);
            for (int ci = 0; ci < s.Length; ci++)
            {
                char c0 = s[ci];
                if (c0 < 128) { b.Append(c0); continue; }
                string rep;
                if (Map.TryGetValue(c0, out rep))
                {
                    // "Ærø" -> "Aero", but "ÆRØ" -> "AERO"
                    if (rep.Length > 1 && rep == rep.ToUpperInvariant() && ci + 1 < s.Length && char.IsLower(s[ci + 1]))
                        rep = rep[0] + rep.Substring(1).ToLowerInvariant();
                    b.Append(rep);
                    continue;
                }
                string d = c0.ToString().Normalize(NormalizationForm.FormD);
                bool any = false;
                foreach (char c in d)
                {
                    if (c < 128) { b.Append(c); any = true; }
                    else if (Map.TryGetValue(c, out rep)) { b.Append(rep); any = true; }
                }
                if (!any && char.IsWhiteSpace(c0)) b.Append(' ');
            }
            // nothing produced here may be a character Windows forbids in names
            for (int i = 0; i < b.Length; i++)
            {
                char c = b[i];
                if (c < 32 || c == '"' || c == '<' || c == '>' || c == '|' || c == ':' || c == '*' || c == '?' || c == '/' || c == '\\') b[i] = ' ';
            }
            return b.ToString();
        }
    }

    // ------------------------------------------------------------------
    // Building the new names
    // ------------------------------------------------------------------
    public static class Planner
    {
        static readonly Regex TheRx = new Regex(@"^(.*?), The(?=$| - )", RegexOptions.Compiled);
        static readonly Regex SpacesRx = new Regex(@"\s+", RegexOptions.Compiled);
        static readonly HashSet<string> Reserved = new HashSet<string>(StringComparer.OrdinalIgnoreCase) {
            "CON","PRN","AUX","NUL","COM1","COM2","COM3","COM4","COM5","COM6","COM7","COM8","COM9",
            "LPT1","LPT2","LPT3","LPT4","LPT5","LPT6","LPT7","LPT8","LPT9" };

        public static Kind EffectiveKind(PartInfo p, Options o)
        {
            if (p.Kind == Kind.Side) return o.SidesAreTapes ? Kind.Tape : Kind.Disk;
            return p.Kind;
        }

        static string Pad(int n, int width) { return n.ToString(CultureInfo.InvariantCulture).PadLeft(width, '0'); }

        // The text that goes inside the brackets for one part.
        public static string PartText(PartInfo p, Style style, int width)
        {
            if (p.Kind == Kind.Other || style == Style.AsTosec) return p.Raw;
            string num = p.Start > 0 ? Pad(p.Start, width) + (p.End > p.Start ? "-" + Pad(p.End, width) : "") : "";
            string tot = p.Total > 0 ? " of " + Pad(p.Total, width) : "";
            if (p.Kind == Kind.Side)
            {
                // "(Side A)" or "(Side 1 of 2)"
                string id = num.Length > 0 ? num : p.Side;
                switch (style)
                {
                    case Style.NoTotal: return "Side " + id;
                    case Style.Short: return "S" + id;
                    default: return id + tot;
                }
            }
            string word = p.Word;                         // Disk, Disc or Tape
            string letter = p.Kind == Kind.Tape ? "T" : "D";
            switch (style)
            {
                case Style.NoTotal: return word + " " + num + (p.Side.Length > 0 ? " Side " + p.Side : "");
                case Style.Short: return letter + num + p.Side;
                default: return num + p.Side + tot;
            }
        }

        static string FixTitle(string t, Options o)
        {
            if (o.MoveThe)
            {
                Match m = TheRx.Match(t);
                if (m.Success && m.Groups[1].Value.Trim().Length > 0) t = "The " + m.Groups[1].Value + t.Substring(m.Length);
            }
            return t;
        }

        // Title (year)(publisher) & Title2 (year)(publisher) (part)
        static string Compose(List<Entry> entries, Options o, string part)
        {
            StringBuilder b = new StringBuilder();
            for (int i = 0; i < entries.Count; i++)
            {
                Entry e = entries[i];
                if (i > 0) b.Append(" & ");
                b.Append(FixTitle(e.Title, o));
                string groups = "";
                if (o.Year && e.Year.Length > 0) groups += "(" + e.Year + ")";
                if (o.Publisher && e.Publisher.Length > 0) groups += "(" + e.Publisher + ")";
                if (i == entries.Count - 1 && part.Length > 0) groups += "(" + part + ")";
                if (groups.Length > 0) b.Append(' ').Append(groups);
            }
            string s = b.ToString();
            if (o.Plain)
            {
                s = s.Replace(" & ", " and ");
                s = Letters.ToPlain(s);
            }
            s = SpacesRx.Replace(s, " ").Trim();
            return s;
        }

        static bool BadBase(string baseName, string ext)
        {
            if (baseName.Length == 0) return true;
            if (baseName.Replace(".", "").Trim().Length == 0) return true;
            int dot = baseName.IndexOf('.');
            string dev = (dot >= 0 ? baseName.Substring(0, dot) : baseName).Trim();
            if (Reserved.Contains(dev)) return true;
            if (ext.Length == 0 && (baseName.EndsWith(".") || baseName.EndsWith(" "))) return true;
            if (baseName.Length + ext.Length > 255) return true;
            return false;
        }

        static string Key(string name) { return name.ToUpperInvariant(); }

        public static Plan Build(ScanResult s, Options o)
        {
            Plan plan = new Plan();

            // ---- multi-part sets ----
            Dictionary<string, PartSet> setByKey = new Dictionary<string, PartSet>();
            List<PartSet> sets = new List<PartSet>();
            foreach (SrcFile f in s.Files)
            {
                if (!Tosec.Usable(f) || f.Part == null) continue;
                PartSet ps;
                if (!setByKey.TryGetValue(f.SetKey, out ps))
                {
                    ps = new PartSet(); ps.Kind = f.Part.Kind;
                    setByKey[f.SetKey] = ps; sets.Add(ps);
                }
                ps.Files.Add(f);
            }
            foreach (PartSet ps in sets)
            {
                ps.Files.Sort(ComparePart);
                ps.Lead = ps.Files[0];
                int max = 0;
                foreach (SrcFile f in ps.Files) max = Math.Max(max, Math.Max(f.Part.Total, f.Part.End));
                ps.Width = max >= 10 ? max.ToString(CultureInfo.InvariantCulture).Length : 1;
            }

            // ---- a name for every file ----
            Dictionary<SrcFile, int> setOf = new Dictionary<SrcFile, int>();
            for (int i = 0; i < sets.Count; i++) foreach (SrcFile f in sets[i].Files) setOf[f] = i;
            List<List<Item>> setItems = new List<List<Item>>();
            for (int i = 0; i < sets.Count; i++) setItems.Add(new List<Item>());

            foreach (SrcFile f in s.Files)
            {
                Item it = new Item(); it.Src = f; it.Target = f.Name;
                plan.Items.Add(it);
                plan.TotalBytes += f.Size;
                if (f.Hidden) { it.Reason = Reason.Hidden; continue; }
                if (!f.Tosec) { it.Reason = Reason.NotTosec; continue; }
                if (f.Shared) { it.Reason = Reason.SharedFlags; continue; }
                if (f.Entries.Count == 0) { it.Reason = Reason.Unusable; continue; }

                List<Entry> entries = f.Entries;
                string part = "";
                int si;
                if (setOf.TryGetValue(f, out si))
                {
                    it.Set = si;
                    setItems[si].Add(it);
                    PartSet ps = sets[si];
                    entries = ps.Lead.Entries;                // every part carries the lead's name
                    Kind k = EffectiveKind(f.Part, o);
                    Style st = k == Kind.Tape ? o.TapeStyle : (k == Kind.Disk ? o.DiskStyle : Style.AsTosec);
                    part = PartText(f.Part, st, ps.Width);
                }
                string bn = Compose(entries, o, part);
                if (f.Ext.Length == 0) bn = bn.TrimEnd('.', ' ');   // Windows drops a trailing dot or space
                if (BadBase(bn, f.Ext)) { it.Reason = Reason.Unusable; continue; }
                string nn = bn + f.Ext;
                if (nn == f.Name) { it.Reason = Reason.NothingToShorten; continue; }
                it.Target = nn; it.Reason = Reason.Renamed;
            }

            // a set with an unusable member keeps all its original names
            foreach (Item it in plan.Items)
                if (it.Reason == Reason.Unusable && it.Set >= 0) RevertSet(setItems[it.Set], Reason.Unusable);

            // ---- clashes: keep the original names until no two files share a name ----
            bool changed = true;
            while (changed)
            {
                changed = false;
                Dictionary<string, List<Item>> byName = new Dictionary<string, List<Item>>();
                foreach (Item it in plan.Items)
                {
                    List<Item> l;
                    string k = Key(it.Target);
                    if (!byName.TryGetValue(k, out l)) { l = new List<Item>(); byName[k] = l; }
                    l.Add(it);
                }
                foreach (List<Item> l in byName.Values)
                {
                    if (l.Count < 2) continue;
                    foreach (Item it in l)
                    {
                        if (it.Reason != Reason.Renamed) continue;
                        it.Would = it.Target; it.Target = it.Src.Name; it.Reason = Reason.Clash;
                        changed = true;
                        if (it.Set >= 0) RevertSet(setItems[it.Set], Reason.Clash);
                    }
                }
            }

            // ---- playlists ----
            HashSet<string> taken = new HashSet<string>();
            foreach (Item it in plan.Items) taken.Add(Key(it.Target));
            Dictionary<string, List<Playlist>> plByName = new Dictionary<string, List<Playlist>>();
            for (int i = 0; i < sets.Count; i++)
            {
                PartSet ps = sets[i];
                if (ps.Kind == Kind.Other) continue;
                Kind k = ps.Kind == Kind.Side ? (o.SidesAreTapes ? Kind.Tape : Kind.Disk) : ps.Kind;
                if (!(k == Kind.Disk ? o.DiskM3u : o.TapeM3u)) continue;
                bool ok = true;
                List<Item> members = new List<Item>(setItems[i]);
                foreach (Item it in members)
                    if (it.Reason != Reason.Renamed && it.Reason != Reason.NothingToShorten) ok = false;
                if (!ok) continue;
                members.Sort(delegate (Item a, Item b) { return ComparePart(a.Src, b.Src); });
                Playlist pl = new Playlist();
                pl.Name = Compose(ps.Lead.Entries, o, "") + ".m3u";
                pl.Items = members;
                plan.Playlists.Add(pl);
                List<Playlist> same;
                if (!plByName.TryGetValue(Key(pl.Name), out same)) { same = new List<Playlist>(); plByName[Key(pl.Name)] = same; }
                same.Add(pl);
            }
            foreach (KeyValuePair<string, List<Playlist>> kv in plByName)
                if (kv.Value.Count > 1 || taken.Contains(kv.Key) || BadBase(kv.Value[0].Name.Substring(0, kv.Value[0].Name.Length - 4), ".m3u"))
                    foreach (Playlist pl in kv.Value) pl.Dropped = true;
            foreach (Playlist pl in plan.Playlists) if (!pl.Dropped) taken.Add(Key(pl.Name));

            // ---- the log name must not collide either ----
            int n = 2;
            while (taken.Contains(Key(plan.LogName))) plan.LogName = "_NOT RENAMED (" + (n++) + ").txt";

            // ---- counts and copy order ----
            foreach (Item it in plan.Items)
            {
                switch (it.Reason)
                {
                    case Reason.Renamed: plan.Renamed++; break;
                    case Reason.Clash: plan.Clashes++; break;
                    case Reason.NotTosec: plan.NotTosec++; break;
                    case Reason.SharedFlags: plan.Shared++; break;
                    case Reason.NothingToShorten: plan.Nothing++; break;
                    case Reason.Unusable: plan.Unusable++; break;
                    case Reason.Hidden: plan.Hidden++; break;
                }
            }
            foreach (Playlist pl in plan.Playlists) { if (pl.Dropped) plan.PlaylistsDropped++; else plan.PlaylistsMade++; }
            plan.CopyOrder = new List<Item>(plan.Items);
            plan.CopyOrder.Sort(delegate (Item a, Item b)
            {
                int c = string.Compare(a.Target, b.Target, StringComparison.OrdinalIgnoreCase);
                return c != 0 ? c : string.CompareOrdinal(a.Target, b.Target);
            });
            return plan;
        }

        static void RevertSet(List<Item> members, Reason why)
        {
            foreach (Item it in members)
            {
                if (it.Reason != Reason.Renamed) continue;
                it.Would = it.Target; it.Target = it.Src.Name; it.Reason = why;
            }
        }

        public static int ComparePart(SrcFile a, SrcFile b)
        {
            int c = a.Part.Start.CompareTo(b.Part.Start);
            if (c == 0) c = a.Part.End.CompareTo(b.Part.End);
            if (c == 0) c = string.CompareOrdinal(a.Part.Side, b.Part.Side);
            if (c == 0) c = string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase);
            if (c == 0) c = string.CompareOrdinal(a.Name, b.Name);
            return c;
        }

        public static string ReasonText(Reason r)
        {
            switch (r)
            {
                case Reason.Clash: return "name clash";
                case Reason.NotTosec: return "not a TOSEC name";
                case Reason.SharedFlags: return "compilation with shared flags";
                case Reason.NothingToShorten: return "nothing to shorten";
                case Reason.Unusable: return "no usable new name";
                default: return "";
            }
        }
    }

    // ------------------------------------------------------------------
    // Files on disk
    // ------------------------------------------------------------------
    public static class FileOps
    {
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        static extern bool GetDiskFreeSpaceEx(string dir, out ulong freeForUser, out ulong total, out ulong totalFree);

        // Free bytes on the drive of the folder, or -1 when it cannot be told.
        public static long FreeSpace(string folder)
        {
            try
            {
                if (Environment.OSVersion.Platform == PlatformID.Win32NT)
                {
                    ulong free, total, tfree;
                    string dir = folder.EndsWith("\\") ? folder : folder + "\\";
                    if (GetDiskFreeSpaceEx(dir, out free, out total, out tfree)) return (long)Math.Min(free, (ulong)long.MaxValue);
                    return -1;
                }
                return new DriveInfo(Path.GetPathRoot(Path.GetFullPath(folder))).AvailableFreeSpace;
            }
            catch (Exception) { return -1; }
        }

        public static bool FolderIsEmpty(string folder)
        {
            return Directory.Exists(folder) && Directory.GetFileSystemEntries(folder).Length == 0;
        }

        // Returns null on success, otherwise the reason. Never overwrites anything.
        public static string Copy(string src, string dstDir, string name)
        {
            try
            {
                string dst = Path.Combine(dstDir, name);
                if (File.Exists(dst) || Directory.Exists(dst)) return "a file with this name already exists in the output folder";
                File.Copy(src, dst, false);
                return null;
            }
            catch (Exception ex) { return ex.Message; }
        }

        // Writes a new text file; fails rather than overwrite.
        public static string WriteNew(string path, string text, bool bom)
        {
            try
            {
                using (FileStream fs = new FileStream(path, FileMode.CreateNew, FileAccess.Write))
                using (StreamWriter w = new StreamWriter(fs, new UTF8Encoding(bom)))
                    w.Write(text);
                return null;
            }
            catch (Exception ex) { return ex.Message; }
        }

        public static string PlaylistText(Playlist pl)
        {
            StringBuilder b = new StringBuilder();
            foreach (Item it in pl.Items) b.Append(it.Target).Append('\n');
            return b.ToString();
        }
    }

    // ------------------------------------------------------------------
    // The list of files that were not renamed
    // ------------------------------------------------------------------
    public static class Report
    {
        // done = how many files of CopyOrder were copied. failed = the file that could not be written (or null).
        public static string Build(Plan plan, int done, bool stopped, string failed, string error, bool playlistsWritten)
        {
            string nl = "\r\n";
            StringBuilder b = new StringBuilder();
            b.Append("TOSEC Short Names - files that were not renamed").Append(nl);
            b.Append(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture)).Append(nl).Append(nl);
            if (failed != null)
                b.Append("THE RUN STOPPED: ").Append(failed).Append(" could not be written: ").Append(error).Append(nl)
                 .Append("  ").Append(done).Append(" of ").Append(plan.CopyOrder.Count).Append(" files were copied. Only those are listed below.").Append(nl).Append(nl);
            else if (stopped)
                b.Append("THE RUN WAS STOPPED by the user after ").Append(done).Append(" of ").Append(plan.CopyOrder.Count)
                 .Append(" files. Only those are listed below.").Append(nl).Append(nl);

            Reason[] order = { Reason.Clash, Reason.NotTosec, Reason.SharedFlags, Reason.Unusable, Reason.NothingToShorten };
            string[] heads = {
                "NAME CLASH - copied with the original name (another file would have had the same new name)",
                "NOT A TOSEC NAME - copied with the original name",
                "COMPILATION WITH SHARED FLAGS - copied with the original name",
                "NO USABLE NEW NAME - copied with the original name",
                "NOTHING TO SHORTEN - the name is already as short as it gets"
            };
            for (int r = 0; r < order.Length; r++)
            {
                List<Item> l = new List<Item>();
                for (int i = 0; i < done && i < plan.CopyOrder.Count; i++)
                    if (plan.CopyOrder[i].Reason == order[r]) l.Add(plan.CopyOrder[i]);
                if (l.Count == 0) continue;
                b.Append(heads[r]).Append("  (").Append(l.Count).Append(")").Append(nl);
                foreach (Item it in l)
                {
                    b.Append("  ").Append(it.Src.Name).Append(nl);
                    if (it.Would.Length > 0) b.Append("      would have been: ").Append(it.Would).Append(nl);
                }
                b.Append(nl);
            }
            if (playlistsWritten)
            {
                bool any = false;
                foreach (Playlist pl in plan.Playlists)
                {
                    if (!pl.Dropped) continue;
                    if (!any) { b.Append("PLAYLISTS NOT CREATED - the name was already taken").Append(nl); any = true; }
                    b.Append("  ").Append(pl.Name).Append(nl);
                }
                if (any) b.Append(nl);
            }
            else if (plan.Playlists.Count > 0)
                b.Append("No playlists were created because the run did not finish.").Append(nl);
            return b.ToString();
        }

        public static bool HasContent(Plan plan, int done, bool incomplete)
        {
            if (incomplete) return true;
            for (int i = 0; i < done && i < plan.CopyOrder.Count; i++)
            {
                Reason r = plan.CopyOrder[i].Reason;
                if (r != Reason.Renamed && r != Reason.Hidden) return true;
            }
            return plan.PlaylistsDropped > 0;
        }
    }
}
